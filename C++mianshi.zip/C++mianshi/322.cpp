//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//
//int coinChange(vector<int>& coins, int amount) {
//	vector<int> dp(amount + 1, amount + 1);
//	dp[0] = 0;
//	for (int i = 1; i<=amount ; i++) {
//		for (int j = 0; j<coins.size(); j++) {
//			if (coins[j] <= i)
//				dp[i] = min(dp[i], dp[i - coins[j]] + 1);
//		}
//	}
//	return dp[amount]>amount ? -1 : dp[amount];
//}
//
//int main()
//{
//	vector<int> aa = { 1,2,5};
//	int ans= coinChange(aa,11);
//	
//
//	getchar();
//	return 0;
//}