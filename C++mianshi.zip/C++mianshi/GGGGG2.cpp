//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//
//int solution(vector<int> &A) {
//	// write your code in C++14 (g++ 6.2.0)
//	unordered_map<int, pair<int,int>> mm;
//	vector<int> type;
//	int ans = 0,tt=0;
//	for (int i = 0; i < A.size(); i++) {
//		if (mm.find(A[i]) != mm.end() ) 
//			mm[A[i]].second = i;
//		else if (mm.size() < 2) {
//			type.push_back(A[i]);
//			mm[A[i]].first = i;
//			mm[A[i]].second = i;
//		}
//		else {//if(type.size()==2)
//			tt = max(mm[type[0]].second ,mm[type[1]].second)- min(mm[type[0]].first, mm[type[1]].first)+1;
//			ans = max(ans, tt);
//			if (mm[type[0]].second < mm[type[1]].second) {
//				i = mm[type[0]].second;
//				mm.erase(type[0]);
//				int e = type[1];
//				type.pop_back();
//				type.pop_back();
//				type.push_back(e);
//			}
//			else {
//				i = mm[type[1]].second;
//				mm.erase(type[1]);
//				type.pop_back();
//			}
//		}
//	}
//	return ans;
//}
//
//int main()
//{
//	vector<int> aa = { 2,1,1,1,1,3,3,4 };
//
//	auto ans = solution(aa);
//
//
//	getchar();
//	return 0;
//}