////285
//TreeNode* inorderSuccessor(TreeNode* root, TreeNode* p) {
//	if (!root)
//		return NULL;
//	if (root->val <= p->val) {
//		return inorderSuccessor(root->right, p);
//	}
//	else {
//		TreeNode *left = inorderSuccessor(root->left, p);
//		return left ? left : root;//*****************find example to think
//	}
//}