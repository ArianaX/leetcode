//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//void dfs(int i, int j, vector<vector<char>>& grid) {
//	if (i < 0 || i >= grid.size() || j < 0 || j >= grid[0].size() || grid[i][j] == '0')
//		return;
//	grid[i][j] = '0';
//	dfs(i + 1, j, grid);
//	dfs(i - 1, j, grid);
//	dfs(i, j - 1, grid);
//	dfs(i, j + 1, grid);
//
//
//}
//bool isValid(string s) {
//	stack<char> parentheses;
//	for (int i = 0; i < s.size(); ++i) {
//		if (s[i] == '(' || s[i] == '[' || s[i] == '{') parentheses.push(s[i]);
//		else {
//			if (parentheses.empty()) 
//				return false;
//			if (s[i] == ')' && parentheses.top() != '(') 
//				return false;
//			if (s[i] == ']' && parentheses.top() != '[') 
//				return false;
//			if (s[i] == '}' && parentheses.top() != '{') 
//				return false;
//			parentheses.pop();
//		}
//	}
//	return parentheses.empty();
//}
////my
//bool isValid(string s) {
//	vector<char> mm;
//	for (int i = 0; i<s.size(); i++) {
//		if (s[i] == '(' || s[i] == '[' || s[i] == '{')
//			mm.push_back(s[i]);
//		else {
//			if (s[i] == ')' && mm.back() != '(')
//				return false;
//			if (s[i] == ']' && mm.back() != '[')
//				return false;
//			if (s[i] == '}' && mm.back() != '{')
//				return false;
//			mm.pop_back();
//		}
//	}
//	return mm.empty();
//}
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	string ss = "2-4A0r7-4k";
//	auto ans = solution(ss, 4);
//
//
//	getchar();
//	return 0;
//}