//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//int repeatedStringMatch(string A, string B) {
//	string t = A;
//	for (int i = 1; i <= B.size() / A.size() + 2; ++i) {
//		if (t.find(B) != string::npos) 
//			return i;
//		t += A;
//	}
//	return -1;
//}
//
//int main()
//{
//	auto ans = repeatedStringMatch("abcd","cdabcdab");
//
//
//	getchar();
//	return 0;
//}