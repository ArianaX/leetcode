//#include <iostream>
//using namespace std;
//#include <vector>
//#include <algorithm>
//#include <string>
//#include <map>
//#include<utility>
//#pragma region string number
//
////void printN(string& num)
////{
////	cout << "num: ";
////	for (int i = 0; i < num.size(); i++)
////	{
////		if (num[i] != '0') {
////			for (int j = i; j < num.size(); j++)
////				cout << num[j];
////			break;
////		}
////	}
////	cout << endl;
////}
////void increaseR(string& num, int index, int n)
////{
////	if (index + 1 == n) {
////		printN(num);
////		return;
////	}
////	for (int i = 0; i < 10; i++) {
////		num[index + 1] = i + '0';
////		increaseR(num, index + 1, n);
////	}
////}
////void increaseN(int n)
////{
////	if (n <= 0) return;
////	string num = new char(n + 1);
////	for (int i = 0; i < 10; i++) {
////		num[0] = i + '0';
////		increaseR(num, 0, n);
////	}
////}
//#pragma endregion
//
//void printN(char* num,int n)
//{
//	cout << "num: ";
//	for (int i = 0; i < n; i++)
//	{
//		if(num[i]!='0'){
//			for (int j = i; j < n; j++) 
//				cout << num[j];
//			break;
//		}
//	}
//	cout << endl;
//}
//void increaseR(char* num,int index,int n)
//{
//	if (index + 1 == n) {
//		printN(num,n);
//		return;
//	}
//	for (int i = 0; i < 10; i++) {
//		num[index + 1] = i + '0';
//		increaseR(num, index + 1, n);
//	}
//}
//void increaseN(int n)
//{
//	if (n <= 0) return;
//	char* num=new char (n+1);
//	for (int i = 0; i < 10; i++) {
//		num[0] = i + '0';
//		increaseR(num,0,n);
//	}
//}
//
//int main()
//{
//	increaseN(3);
//
//	getchar();
//	return 0;
//}