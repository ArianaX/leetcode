//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include <string>
//#include <set>
//#include <unordered_set>
//#include <map>
//
//
////definition for singly-linked list.
//class listnode {
//public:
//     int val;
//     listnode *next;
//     listnode(int x) : val(x), next(nullptr) {}
// };
//
//class timestamp {
//public:
//	timestamp() {}
//	timestamp(string a) { date = a; }
//	string date;
//	//string getdate( timestamp& a) const{
//	//	return a.date;
//	//}
//	bool operator<(timestamp a) const {
//		return stoi(date) < stoi(a.date);
//	}
//};
//
//struct vote {
//	int name;
//	timestamp time;
//};
//
//int functiona(timestamp t) {
//	multimap<timestamp, vote> m;
//	vote v1;
//	v1.name = 2;
//	v1.time.date = "1111";
//	vote v2;
//	v2.name = 2;
//	v2.time.date = "1112";
//	vote v3;
//	v3.name = 0;
//	v3.time.date = "1113";
//	m.insert(make_pair(v2.time,v2));
//	m.insert(make_pair(v1.time, v1));
//	m.insert(make_pair(v3.time, v3));
//	
//	auto it = m.begin();
//	map<int,int> dp;
//	dp[it->second.name]++;
//	
//	return 0;
//
//}
//
//void helper(int left, int right, vector<int>& ans, vector<int> &q) {
//	if (q[left] != q[right] && left < right) {//[5,4,2]
//		if (left + 1 == right)
//			ans.push_back(right);
//		else {
//			int mid = (left + right) / 2;
//			helper(left, mid, ans, q);
//			helper(mid, right, ans, q);
//		}
//	}
//	else
//		return;
//}
//vector<int> functionb(vector<int>q) {//[5,5,5,4,4,2,1,1,1,0,0] 5 10  11ge [5,2]
//	vector<int> ans;
//	if (q.empty() || q.size() == 1)
//		return {};
//	int left = 0, right = q.size()-1;
//	helper(left, right, ans, q);
//	sort(ans.begin(), ans.end());
//	return ans;
//}
//
////������ ���ṹ
//struct TNode {
//	vector<TNode*> child;
//	int time=0;
//};
//void function(TNode* root,int ans) {//the whole tree's time 
//	if (root == nullptr)
//		return;
//	if (root->time != 0)
//		ans += root->time;
//	else {
//		for (int i = 0; i < root->child.size(); i++) {
//			function(root->child[i], ans);
//		}
//	}
//}
////each num must appears 3 times
//bool functionc(vector<int> nums) {
//	sort(nums.begin(), nums.end());
//	for (int i = 0; i < nums.size(); i = i + 3) {
//		if (nums[i] != nums[i + 1] || nums[i + 1] != nums[i + 2])
//			return false;
//	}
//	return true;
//	//this is for map
//	/*unordered_map<int, int> m;
//	if (nums.size() == 0)
//		return false;
//	for (auto a : nums) {
//		m[a]++;
//	}
//	for (auto it=m.begin();it!=m.end();it++)
//		if (it->second != 3)
//			return false;
//	return true;*/
//}
//bool functiond(string s1, string s2) {
//	int cnt = 0;
//	vector<int> temp;
//	for (int i = 0; i < s1.size(); i++) {
//		if (s1[i] != s2[i]) {
//			temp.push_back(s1[i]);
//			temp.push_back(s2[i]);
//			cnt++;
//		}
//		if (cnt > 2)
//			return false;
//	}
//	if (cnt == 2) {
//		if (temp[0] == temp[3] && temp[1] == temp[2])
//			return true;
//	}
//	return false;
//}
////GGGGGGGG
//bool helper(int c, vector<vector<int>> nums, int i, int j) {
//	int m = nums.size(), n = nums[0].size();
//	if (i >= m || j >= n)
//		return true;
//	if (c == nums[i][j])
//		return helper(c, nums, i + 1, j + 1);
//	return false;
//}
//bool functione(vector<vector<int>> nums) {
//	if (nums.empty() || nums[0].empty())
//		return false;
//	int m = nums.size(), n = nums[0].size();
//	for (int i = 0; i < m; i++) {
//		for (int j = 0; j < n; j++) {
//			if (!helper(nums[i][j], nums,i+1,j+1))
//				return false;
//		}
//
//	}
//	return true;
//}
////Pascal's triangle
//int functionf(int i, int j) {
//	if (i >= 0 && j >= 0 && j <= i) {
//		if (j == i || j == 0)
//			return 1;
//		return functionf(i - 1, j) + functionf(i - 1, j - 1);
//	}
//	return 0;
//}
//
//string functiong(string s) {
//	int carry =1;
//	int n = s.size();
//	for (int i = n - 1; i >= 0; i--) {
//		if (s[i]=='9') {//&& cnt = 1
//			int t= s[i]-'0'+carry;
//			s[i] = t % 10 + '0';
//			carry = t/10;
//		}
//		else {
//			s[i] = s[i] + carry;
//			carry = 0;
//		}
//	}
//	return carry == 0 ? s : "1" + s;
//}
////��һ������ ��ƽ�Ĳ��� 0-n ��һ���������������������е���~~~
//int functionh(vector<int>& a,int n) {
//	vector<int>m(n, 0);
//	int cnt = a.size();
//	for (int i = 0; i < a.size(); i++) 
//		m[a[i]]++;
//
//	int q = rand() % (n - cnt)+1;
//	int i = 0;
//	for (int i = 0; i < n&& q>=0; i++) {
//		if (m[i] == 0)
//			q--;
//		if (q == 0)
//			return i;
//	}
//	return 0;
//}
//int main()
//{
//	/*vector<int> name{ 0,1,2,3,4,5 };
//	auto a = functiona(timestamp("1113"));*/
//
//	vector<int> q = { 5,2 };
//	vector <vector<int>>qq = { {1,2,3,4},
//							{5,1,2,3},
//							{6,5,1,2},
//							{7,6,3,1} };
//	auto a = functione(qq);// {//[5,5,5,4,4,2,1,1,1,0,0] 5 10  11ge [5,2]
//	
//	auto b = functionh(q,10);
//
//
//	getchar();
//	return 0;
//}
//
////correct compare function in pair
////class a
////{
////public:
////	a(int a) :a_(a) {}
////	bool operator<(a bobj) const {
////		return a_<bobj.a_;
////	}
////private:
////	int a_;
////};
////int main()
////{
////	std::multimap<a, std::string> maptest;
////	maptest.insert(std::make_pair(a(4), "zsy"));
////	maptest.insert(std::make_pair(a(2), "qwe"));
////	maptest.insert(std::make_pair(a(1), "asd"));
////	maptest.insert(std::make_pair(a(3), "qwe"));
////	auto it = maptest.begin();
////
////	return 0;
////
////}
//
