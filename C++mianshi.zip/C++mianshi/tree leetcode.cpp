//#include<iostream>
//#include<vector>
//#include<string>
//#include<sstream>
//#include<algorithm>
//#include<unordered_map>
//
//using namespace std;
////* Definition for a binary tree node.
//struct TreeNode {
//	int val;
//	TreeNode *left;
//	TreeNode *right;
//	TreeNode(int x) : val(x), left(NULL), right(NULL) {}
//};
//TreeNode* createT(vector<int>& nums) {
//	if (nums.size() == 0)
//		return nullptr;
//	TreeNode* ans=new TreeNode(nums[0]);
//	auto cur = ans;
//	for (int i = 1; i < nums.size(); i++) {
//		cur->left = new TreeNode(nums[i]);
//		cur = cur->left;
//	}
//	return ans;
//}
//TreeNode* helper(vector<int>& nums, int& start) {
//	if (nums[start] == -1||start>=nums.size())
//		return nullptr;
//	TreeNode* ans = new TreeNode(nums[start]);
//	ans->left = helper(nums, ++start);
//	ans->right = helper(nums, ++start);
//	return ans;
//
//}
//TreeNode*  foreCreateT(vector<int>& nums) {
//	if (nums.size() == 0)
//		return nullptr;
//	int start = 0;
//	return helper(nums, start);
//}
//
//
//////105
////TreeNode *buildTree(vector<int> &preorder, int pLeft, int pRight, vector<int> &inorder, int iLeft, int iRight) {
////	if (pLeft > pRight || iLeft > iRight) return NULL;
////	int i = 0;
////	for (i = iLeft; i <= iRight; ++i) {
////		if (preorder[pLeft] == inorder[i]) break;
////	}
////	TreeNode *cur = new TreeNode(preorder[pLeft]);
////	cur->left = buildTree(preorder, pLeft + 1, pLeft + i - iLeft, inorder, iLeft, i - 1);
////	cur->right = buildTree(preorder, pLeft + i - iLeft + 1, pRight, inorder, i + 1, iRight);
////	return cur;
////}
////TreeNode *buildTree(vector<int> &preorder, vector<int> &inorder) {
////	return buildTree(preorder, 0, preorder.size() - 1, inorder, 0, inorder.size() - 1);
////}
//
//
//////236
////TreeNode* lowestCommonAncestor(TreeNode* root, TreeNode* p, TreeNode* q) {
////	if (!root || p == root || q == root) //���root�� �򷵻ؿ�
////		return root;
////	TreeNode *left = lowestCommonAncestor(root->left, p, q);
////	TreeNode *right = lowestCommonAncestor(root->right, p, q);
////	if (left && right) 
////		return root;
////	return left ? left : right;
////}
//////way2:
////TreeNode* lowestCommonAncestor2(TreeNode* root, TreeNode* p, TreeNode* q) {
////	if (!root || p == root || q == root) 
////		return root;
////	TreeNode *left = lowestCommonAncestor2(root->left, p, q);
////	if (left && left != p && left != q) return left;
////	TreeNode *right = lowestCommonAncestor2(root->right, p, q);
////	if (right && right != p && right != q) return right;
////	if (left && right) return root;
////	return left ? left : right;
////}
//
//////98
////bool dfs(TreeNode* root, long min, long max) {
////	if (root == nullptr)
////		return true;
////	if (root->val >= max || root->val <= min)
////		return false;
////	return dfs(root->left, min, root->val) && dfs(root->right, root->val, max);
////}
////bool isValidBST(TreeNode* root) {
////	return dfs(root, LONG_MIN, LONG_MAX);
////
////}
//
////
//////297
////class Codec {
////public:
////	// Encodes a tree to a single string.
////	string serialize(TreeNode* root) {
////		ostringstream out;
////		serialize(root, out);
////		return out.str();
////	}
////	// Decodes your encoded data to tree.
////	TreeNode* deserialize(string data) {
////		istringstream in(data);
////		return deserialize(in);
////	}
////private:
////	void serialize(TreeNode *root, ostringstream &out) {
////		if (root) {
////			out << root->val << ' ';
////			serialize(root->left, out);
////			serialize(root->right, out);
////		}
////		else {
////			out << "# ";
////		}
////	}
////	TreeNode* deserialize(istringstream &in) {
////		string val;
////		in >> val;
////		if (val == "#") 
////			return nullptr;
////		TreeNode *root = new TreeNode(stoi(val));
////		root->left = deserialize(in);
////		root->right = deserialize(in);
////		return root;
////	}
////};
////my
//void toString(TreeNode* root, string& ans) {
//	if (root == nullptr) {
//		ans.push_back('^');
//		return;
//	}
//	ans.push_back(root->val);
//	toString(root->left, ans);
//	toString(root->right, ans);
//}
//
//// Encodes a tree to a single string.
//string serialize(TreeNode* root) {
//	string ans = "";
//	toString(root, ans);
//	return ans;
//
//}
//
//TreeNode* des(istringstream& in) {
//	string tt;
//	in >> tt;
//	if (tt == "^")
//		return nullptr;
//	TreeNode* ans = new TreeNode(stoi(tt));
//	ans->left = des(in);
//	ans->right = des(in);
//	return ans;
//}
//
//// Decodes your encoded data to tree.
//TreeNode* deserialize(string data) {
//	istringstream in(data);
//	return des(in);
//
//}
//
//////124 ·�� �������ڵ� ֻ������д difficult
////int helper(TreeNode* node, int& res) {
////	if (!node) 
////		return 0;
////	int left = max(helper(node->left, res), 0);
////	int right = max(helper(node->right, res), 0);
////	res = max(res, left + right + node->val);
////	return max(left, right) + node->val;
////}
////int maxPathSum(TreeNode* root) {
////	int res = INT_MIN;
////	helper(root, res);
////	return res;
////}
//
//
//////230
//////my
////int helper(TreeNode* root, int k, int &cur) {
////	if (!root)
////		return -1;
////	int val = helper(root->left, k, cur);
////	if (cur == k)
////		return val;
////	cur++;
////	if (k == cur)
////		return root->val;
////	
////	return helper(root->right, k, cur);
////
////}
////int kthSmallest(TreeNode* root, int k) {
////	int cur = 0;
////	return helper(root, k, cur);
////}
////
////int kthSmallestDFS(TreeNode* root, int &k) {
////	if (!root) 
////		return -1;
////	int val = kthSmallestDFS(root->left, k);
////	if (k == 0) 
////		return val;
////	if (--k == 0) 
////		return root->val;
////	return kthSmallestDFS(root->right, k);
////}
////int kthSmallest(TreeNode* root, int k) {
////	return kthSmallestDFS(root, k);
////}
//
//////285
////TreeNode* inorderSuccessor(TreeNode* root, TreeNode* p) {
////	if (!root) 
////		return NULL;
////	if (root->val <= p->val) { 
////		return inorderSuccessor(root->right, p);
////	}
////	else {
////		TreeNode *left = inorderSuccessor(root->left, p);
////		return left ? left : root;//*****************find example to think
////	}
////}
//
//
//////684 union find
////int find(vector<int>& root, int i) {
////	while (root[i] != -1) {
////		i = root[i];
////	}
////	return i;
////}
////vector<int> findRedundantConnection(vector<vector<int>>& edges) {
////	if (edges.empty() || edges[0].empty())
////		return {};
////	vector<int> root(edges.size()*edges[0].size(), -1);
////	for (auto edge : edges) {
////		int x = find(root, edge[0]), y = find(root, edge[1]);
////		if (x == y) 
////			return edge;
////		root[x] = y;
////	}
////	return {};
////}
////my
////int find(vector<int> root, int i) {
////	while (root[i] != -1)
////		i = root[i];
////	return i;
////}
////vector<int> findRedundantConnection(vector<vector<int>>& edges) {
////	if (edges.empty() || edges[0].empty())
////		return {};
////	vector<int> root(edges.size()*edges[0].size(), -1);
////	for (auto a : edges) {
////		int x = find(root, a[0]), y = find(root, a[1]);
////		if (x == y)
////			return a;
////		root[x] = y;
////	}
////	return{};
////}
//
//
////////685
//////int getRoot(vector<int>& root, int i) {
//////	return i == root[i] ? i : getRoot(root, root[i]);
//////}
//////vector<int> findRedundantDirectedConnection(vector<vector<int>>& edges) {
//////	int n = edges.size();
//////	vector<int> root(n + 1, 0), first, second;//root=parent
//////	for (auto& edge : edges) {
//////		if (root[edge[1]] == 0) {//first time
//////			root[edge[1]] = edge[0];
//////		}
//////		else {
//////			first = { root[edge[1]], edge[1] };
//////			second = edge;
//////			edge[1] = 0;
//////		}
//////	}
//////	for (int i = 0; i <= n; ++i) 
//////		root[i] = i;
//////	for (auto& edge : edges) {
//////		if (edge[1] == 0) 
//////			continue;
//////		int x = getRoot(root, edge[0]), y = getRoot(root, edge[1]);
//////		if (x == y) 
//////			return first.empty() ? edge : first;
//////		root[x] = y;
//////	}
//////	return second;
//////}
//////my
////int find(vector<int> root, int i) {
////	while (root[i] != -1)
////		i = root[i];
////	return i;
////}
////
////vector<int> findRedundantDirectedConnection(vector<vector<int>>& edges) {
////	vector<int> parent(edges.size() + 1, -1);
////	vector<int>first, second;
////	for (auto& a : edges) {
////		if (parent[a[1]] == -1)
////			parent[a[1]] = a[0];
////		else {
////			first = { parent[a[1]],a[1] };
////			second = a;
////			a[0] = -1;
////			a[1] = -1;
////		}
////	}
////	vector<int> root(edges.size() + 1, -1);
////	for (auto a : edges) {
////		if (a[1] != -1) {
////			int x = find(root, a[0]), y = find(root, a[1]);
////			if (x == y)
////				return first.empty() ? a : first;
////			root[x] = y;
////		}
////	}
////	return second;
////}
//	
//////270
////int closestValue(TreeNode* root, double target) {
////	int res = root->val;
////	while (root) {
////		if (abs(res - target) >= abs(root->val - target)) {//abs(-12)
////			res = root->val;//renew the minimum
////		}
////		root = target < root->val ? root->left : root->right;
////	}
////	return res;
////}
//////way2:
////int closestValue(TreeNode* root, double target) {
////	int a = root->val;
////	TreeNode *t = target < a ? root->left : root->right;
////	if (t==nullptr) 
////		return a;
////	int b = closestValue(t, target);
////	return abs(a - target) < abs(b - target) ? a : b;
////}
//
////
//////pre in post order traversal tree:
//////144
////void dfs(TreeNode* root, vector<int>& ans) {
////	if (root == nullptr)
////		return;
////	ans.push_back(root->val);
////	dfs(root->left, ans);
////	dfs(root->right, ans);;
////}
////vector<int> preorderTraversal(TreeNode* root) {
////	vector<int>ans;
////	dfs(root, ans);
////	return ans;
////}
////
//////94
////void dfs(TreeNode* root, vector<int>& ans) {
////	if (root == nullptr)
////		return;
////	dfs(root->left, ans);
////	ans.push_back(root->val);
////	dfs(root->right, ans);
////}
////vector<int> inorderTraversal(TreeNode* root) {
////	vector<int>ans;
////	dfs(root, ans);
////	return ans;
////}
////
//////145
////void dfs(TreeNode* root, vector<int>& ans) {
////	if (root == nullptr)
////		return;
////	dfs(root->left, ans);
////	dfs(root->right, ans);
////	ans.push_back(root->val);
////}
////vector<int> postorderTraversal(TreeNode* root) {
////	vector<int>ans;
////	dfs(root, ans);
////	return ans;
////}
//
//
//////102
////void levelorder(TreeNode *root, int level, vector<vector<int> > &res) {
////	if (!root)
////		return;
////	if (res.size() == level)
////		res.push_back({});
////	res[level].push_back(root->val);
////	if (root->left)
////		levelorder(root->left, level + 1, res);
////	if (root->right)
////		levelorder(root->right, level + 1, res);
////}
////vector<vector<int>> levelOrder(TreeNode* root) {
////	vector<vector<int> > res;
////	levelorder(root, 0, res);
////	return res;
////}
//////my
////void dfs(TreeNode* root, vector<vector<int>>& ans, int level) {
////	if (root == nullptr)
////		return;
////	if (ans.size() == level)
////		ans.push_back({});
////	ans[level].push_back(root->val);
////	dfs(root->left, ans, level + 1);
////	dfs(root->right, ans, level + 1);
////}
////vector<vector<int>> levelOrder(TreeNode* root) {
////	vector<vector<int>> ans;
////	if (root == nullptr)
////		return {};
////
////	dfs(root, ans, 0);
////	return ans;
////}
//////107 reverse
////void levelorder(TreeNode *root, int level, vector<vector<int> > &res) {
////	if (!root) 
////		return;
////	if (res.size() == level) 
////		res.push_back({});
////	res[level].push_back(root->val);
////	if (root->left) levelorder(root->left, level + 1, res);
////	if (root->right) levelorder(root->right, level + 1, res);
////}
////vector<vector<int>> levelOrderBottom(TreeNode* root) {
////	vector<vector<int> > res;
////	levelorder(root, 0, res);
////	return vector<vector<int> >(res.rbegin(), res.rend());//end ->begin
////}
//
//////257 ·��
//////my
////void dfs(TreeNode* root, string s, vector<string>& ans) {
////	if (root->left == nullptr&& root->right == nullptr)
////		ans.push_back(s + to_string(root->val));
////	if (root->left != nullptr)
////		dfs(root->left, s + to_string(root->val) + "->", ans);
////	if (root->right != nullptr)
////		dfs(root->right, s + to_string(root->val) + "->", ans);
////}
////vector<string> binaryTreePaths(TreeNode* root) {
////	if (root == nullptr)
////		return {};
////	vector<string> ans;
////	string s = "";
////	dfs(root, s, ans);
////	return ans;
////}
////
//////113 path sum����·��
//////my
////void dfs(TreeNode* root, int sum, vector<int>& temp, vector<vector<int>> & ans) {
////	if (root == nullptr)
////		return;
////	temp.push_back(root->val);
////	if (root->val == sum && root->left == nullptr&&root->right == nullptr)
////		ans.push_back(temp);
////	dfs(root->left, sum - root->val, temp, ans);
////	dfs(root->right, sum - root->val, temp, ans);
////	temp.pop_back();//*********************
////
////}
////vector<vector<int>> pathSum(TreeNode* root, int sum) {
////	vector<vector<int>> ans;
////	if (root == nullptr)
////		return{};
////	vector<int> temp;
////	dfs(root, sum, temp, ans);
////	return ans;
////}
////112
//////my
////void dfs(TreeNode* root, int sum, bool& ans) {
////	if (root == nullptr)
////		return;
////	if (root->val == sum && root->left== nullptr&&root->right == nullptr)
////		ans = true;
////	dfs(root->left, sum - root->val, ans);
////	dfs(root->right, sum - root->val, ans);
////}
////bool hasPathSum(TreeNode* root, int sum) {
////	bool ans = false;
////	dfs(root, sum, ans);
////	return ans == true;
////}
//////GGGGGG
////void dfs(TreeNode* root, int& ans,int current) {
////	if (root == nullptr)
////		return;
////	if ( root->left == nullptr&&root->right == nullptr) {
////		current += root->val;
////		ans = min(current, ans);
////	}
////	dfs(root->left, ans,current+root->val);
////	dfs(root->right, ans, current + root->val);
////	current = current - root->val;
////}
////int hasPathSum(TreeNode* root) {
////	int ans = INT_MAX;
////	dfs(root, ans,0);
////	return ans ;
////}
//
//////129
////// 1
/////// \
//////2   3
//////Return the sum = 12 + 13 = 25.
//////int sumNumbersDFS(TreeNode *root, int sum) {
//////	if (!root) 
//////		return 0;
//////	sum = sum * 10 + root->val;
//////	if (!root->left && !root->right) 
//////		return sum;
//////	return sumNumbersDFS(root->left, sum) + sumNumbersDFS(root->right, sum);
//////}
//////int sumNumbers(TreeNode *root) {
//////	return sumNumbersDFS(root, 0);
//////}
//////my
////void helper(TreeNode* root,int cur, int& ans) {
////	if (root == nullptr)
////		return;
////	else {
////		cur = cur * 10 + root->val;
////		if (root->left == nullptr&& root->right == nullptr)
////			ans += cur;
////		helper(root->left, cur, ans);
////		helper(root->right, cur, ans);
////	}
////
////}
////int sumNumbers(TreeNode* root) {
////	int ans = 0;
////	helper(root,0,ans);
////	return ans;
////}
//
//
//
//int main() {
//
////ariana:
////			  5
////        3       6
////	  2    4
//	vector<int> ttt = { 5,3,2,1,4,6};
//	vector<int >qqq = { 1,2,3,4,5,6 };
//	//auto aaa = buildTree(ttt,qqq);
//
//	vector<int> single = { 5,3,2,-1,-1,4,-1,-1,6,-1,-1 };
//	auto ariana = foreCreateT(single);
//
//	vector<vector<int>> aa = { {1,2},{1,3},{2,3} };//{ {1,2},{2,3},{3,4 },{ 4,1 },{ 1,5 }};
//	auto c= sumNumbers(ariana);
//
//
//	getchar();
//	return 0;
//}