//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//#include<map>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//vector<pair<int, int>> kSmallestPairs(vector<int>& nums1, vector<int>& nums2, int k) {
//	vector<pair<int, int>> res;
//	multimap<int, pair<int, int>> m;
//	for (int i = 0; i < min((int)nums1.size(), k); ++i) {
//		for (int j = 0; j < min((int)nums2.size(), k); ++j) {
//			m.insert({ nums1[i] + nums2[j],{ nums1[i], nums2[j] } });
//		}
//	}
//	for (auto it = m.begin(); it != m.end(); ++it) {
//		res.push_back(it->second);
//		if (--k <= 0) return res;
//	}
//	return res;
//}
////my
//vector<pair<int, int>> kSmallestPairs(vector<int>& nums1, vector<int>& nums2, int k) {
//	multimap<int, pair<int, int>> m;
//	for (int i = 0; i<min(k, (int)nums1.size()); i++) {
//		for (int j = 0; j<min(k, (int)nums2.size()); j++) {
//			m.insert({ nums1[i] + nums2[j],{ nums1[i],nums2[j] } });
//		}
//	}
//	vector<pair<int, int>> ans;
//	auto it = m.begin();
//	int cnt = 1;
//	while (it != m.end() && cnt <= k) {
//		ans.push_back(it->second);
//		it++;
//		cnt++;
//	}
//	return ans;
//}
//int main()
//{
//	multimap<int, int> m;
//	m.insert({ 20, 1 });
//	m.insert({2, 2});
//	
//	unordered_map<int, int> map;
//	map.insert({ 1,2 });
//	map.insert({ 1,2 });
//
//
//
//
//	getchar();
//	return 0;
//}