//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//string licenseKeyFormatting(string S, int K) {
//	string res = "";
//	for (int i = (int)S.size() - 1; i >= 0; --i) {
//		if (S[i] != '-') {
//			((res.size() % (K + 1) - K) ? res : res += '-') += toupper(S[i]);
//		}
//	}
//	return string(res.rbegin(), res.rend());
//}
//int solution(vector<string> &L) {
//	// write your code in C++14 (g++ 6.2.0)
//	vector <string > mm;
//	vector<int> aa2(L.size(), 1);
//	for (auto aa : L) {
//		int found =aa.find("@");
//		string nn = aa.substr(0, found);
//		string home = aa.substr(found + 1);
//		while (nn.find(".") != string::npos) {
//			nn = nn.substr(0, nn.find(".")) + nn.substr(nn.find(".") + 1);
//		}
//		if (nn.find("+") != string::npos) {
//			nn = nn.substr(0, nn.find("+"));
//		}
//		string ans = nn + "@" + home;
//		bool flag = false;
//		for (int i = 0; i < mm.size(); i++) {
//			if (mm[i] == ans) {
//				aa2[i]++;
//				flag = true;
//			}
//		}
//		if (flag == false) 
//			mm.push_back(ans);
//	}
//	int cc = 0;
//	for (int i = 0; i < L.size(); i++)
//		if (aa2[i] > 1)
//			cc++;
//	return cc;
//}
//
//int main()
//{
//	vector<string> aa = { "a.b@example.com", "ab+1@example.com", "y@example.com" };
//
//	auto ans = solution(aa);
//
//
//	getchar();
//	return 0;
//}