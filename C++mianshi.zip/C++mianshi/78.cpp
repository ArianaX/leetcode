//#include<iostream>
//using namespace std;
//#include<vector>
//
//void dfs(vector<int> &nums, int idx, vector<vector<int>> &res, vector<int> &path) {
//	for (int i = idx; i<nums.size(); i++) {
//		path.push_back(nums[i]);
//		res.push_back(path);
//		dfs(nums, i + 1, res, path);
//		path.pop_back();
//	}
//}
//vector<vector<int>> subsets(vector<int>& nums) {
//	vector<vector<int>> res;
//	vector<int> path;
//	res.push_back(path);
//	dfs(nums, 0, res, path);
//	return res;
//}
//
//void subsetsDFS(vector<int>nums, vector<vector<int>> ans, int index, vector<int> path) {
//	for (int i = index; i<nums.size(); i++) {
//		path.push_back(nums[i]);
//		ans.push_back(path);
//		subsetsDFS(nums, ans, i + 1, path);
//		path.pop_back();
//	}
//}
//vector<vector<int>> subsets2(vector<int>& nums) {
//	vector<vector<int>> ans;
//	vector<int> path;
//	ans.push_back(path);
//	subsetsDFS(nums, ans, 0, path);
//	return ans;
//}
//int main()
//{
//	vector<vector<int>> ans;
//	vector<int> nums = { 1,2,3 };
//	ans = subsets2(nums);
//
//	getchar();
//	return 0;
//}