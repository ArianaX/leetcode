//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//int shortestDistance(vector<vector<int>>& grid) {
//	int res = INT_MAX, val = 0, m = grid.size(), n = grid[0].size();
//	vector<vector<int>> sum = grid;
//	vector<vector<int>> dirs{ { 0,-1 },{ -1,0 },{ 0,1 },{ 1,0 } };
//	for (int i = 0; i < grid.size(); ++i) {
//		for (int j = 0; j < grid[i].size(); ++j) {
//			if (grid[i][j] == 1) {
//				res = INT_MAX;
//				vector<vector<int>> dist = grid;
//				queue<pair<int, int>> q;
//				q.push({ i, j });
//				while (!q.empty()) {
//					int a = q.front().first, b = q.front().second; q.pop();
//					for (int k = 0; k < dirs.size(); ++k) {
//						int x = a + dirs[k][0], y = b + dirs[k][1];
//						if (x >= 0 && x < m && y >= 0 && y < n && grid[x][y] == val) {
//							--grid[x][y];
//							dist[x][y] = dist[a][b] + 1;
//							sum[x][y] += dist[x][y] - 1;
//							q.push({ x, y });
//							res = min(res, sum[x][y]);
//						}
//					}
//				}
//				--val;
//			}
//		}
//	}
//	return res == INT_MAX ? -1 : res;
//}
////my
//int shortestDistance2(vector<vector<int>>& grid) {
//	if (grid.empty() || grid[0].empty())
//		return 0;
//	int res = INT_MAX, val = 0, m = grid.size(), n = grid[0].size();
//	vector<vector<int>> sum = grid;
//	vector<vector<int>> dirs{ { 0,-1 },{ -1,0 },{ 0,1 },{ 1,0 } };
//	for (int i = 0; i<grid.size(); i++) {
//		for (int j = 0; j<grid[0].size(); j++) {
//			if (grid[i][j] == 1) {
//				vector<vector<int>> dist = grid;
//				queue<pair<int, int>> q;
//				q.push({ i,j });
//				res = INT_MAX;
//				while (!q.empty()) {
//					int a = q.front().first, b = q.front().second;
//					q.pop();
//					for (int k = 0; k<dirs.size(); k++) {
//						int x = a + dirs[k][0], y = b + dirs[k][1];
//						if (x >= 0 && x < m && y >= 0 && y < n && grid[x][y] == val) {
//							grid[x][y]--;
//							q.push({ x,y });
//							dist[x][y] = dist[a][b] + 1;
//							sum[x][y] += dist[x][y] - 1;
//							res = min(res, sum[x][y]);
//						}
//					}
//				}
//				val--;
//			}
//		}
//	}
//	return res == INT_MAX ? -1 : res;
//}
//int main()
//{
//	vector<vector<int>> aa = { {1,0,2,0,1},
//							   {0,0,0,0,0},
//							   {0,0,1,0,0 } };
//
//	auto ans = shortestDistance2(aa);
//
//
//	getchar();
//	return 0;
//}