//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//
//int fourSumCount(vector<int>& A, vector<int>& B, vector<int>& C, vector<int>& D) {
//	int res = 0;
//	unordered_map<int, int> m;
//	for (int i = 0; i < A.size(); ++i) {
//		for (int j = 0; j < B.size(); ++j) {
//			++m[A[i] + B[j]];
//		}
//	}
//	for (int i = 0; i < C.size(); ++i) {
//		for (int j = 0; j < D.size(); ++j) {
//			int target = -1 * (C[i] + D[j]);
//			res += m[target];
//		}
//	}
//	return res;
//}
//int fourSumCount(vector<int>& A, vector<int>& B, vector<int>& C, vector<int>& D) {
//	int ans = 0;
//	unordered_map<int, int>m;
//	for (int i = 0; i<A.size(); i++) {
//		for (int j = 0; j<B.size(); j++) {
//			m[A[i] + B[j]]++;
//		}
//	}
//	for (int i = 0; i<C.size(); i++) {
//		for (int j = 0; j<D.size(); j++) {
//			int target = -1 * (C[i] + D[j]);
//			ans += m[target];
//		}
//	}
//	return ans;
//}
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	auto ans = fourSumCount(aa);
//
//
//	getchar();
//	return 0;
//}