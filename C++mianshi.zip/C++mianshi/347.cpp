//#include<iostream>
//using namespace std;
//#include<vector>
//#include<map>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//
//int main()
//{
//	vector<int>nums = { 1,2,2,2,2,1,3,3,2 };
//	int k = 2;
//
//
//	unordered_map<int, int> hash;
//	vector<int> result;
//	for (auto val : nums) 
//		hash[val]++;
//	priority_queue<pair<int, int>> que;
//	for (auto val : hash) 
//		que.push(make_pair(val.second, val.first));
//	while (k--)
//	{
//		auto val = que.top();
//		result.push_back(val.second);
//		que.pop();
//	}
//	//return result;
//	getchar();
//	return 0;
//}
