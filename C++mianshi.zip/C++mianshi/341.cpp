//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//
//class NestedIterator {
//private: queue<int> vi;
//		 void make_vector(vector<NestedInteger> &nums) {
//			 for (auto a : nums) {
//				 if (a.isInteger())
//					 vi.push(nums.getInteger());
//				 else
//					 make_vector(a.getList());
//			 }
//
//		 }
//public:
//	NestedIterator(vector<NestedInteger> &nestedList) {
//		make_vector(nestedList);
//	}
//
//	int next() {
//		int t = vi.front();
//		vi.pop();
//		return t;
//
//	}
//
//	bool hasNext() {
//		return !vi.empty();
//	}
//};
//
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	auto ans = longestConsecutive(aa);
//
//
//	getchar();
//	return 0;
//}