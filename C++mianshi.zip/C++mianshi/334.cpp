//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//bool increasingTriplet(vector<int>& nums) {
//	if (nums.size()<3)
//		return false;
//	vector<int> f = vector<int>(nums.size(), nums[0]);
//	vector<int> b = vector<int>(nums.size(), nums[nums.size() - 1]);
//	int  temp;
//	for (int i = 1; i<nums.size(); i++) {
//		f[i] = min(f[i - 1], nums[i]);
//	}
//	for (int i = nums.size() - 1; i >= 0; i--) {
//		b[i] = max(b[i + 1], nums[i]);
//	}
//
//	for (int i = 0; i<nums.size(); i++) {
//		if (f[i]<nums[i] && nums[i]<b[i])
//			return true;
//	}
//	return false;
//}
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	auto ans = longestConsecutive(aa);
//
//
//	getchar();
//	return 0;
//}