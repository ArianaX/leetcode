////129
//// 1
///// \
////2   3
////Return the sum = 12 + 13 = 25.
////int sumNumbersDFS(TreeNode *root, int sum) {
////	if (!root) 
////		return 0;
////	sum = sum * 10 + root->val;
////	if (!root->left && !root->right) 
////		return sum;
////	return sumNumbersDFS(root->left, sum) + sumNumbersDFS(root->right, sum);
////}
////int sumNumbers(TreeNode *root) {
////	return sumNumbersDFS(root, 0);
////}
////my
//void helper(TreeNode* root,int cur, int& ans) {
//	if (root == nullptr)
//		return;
//	else {
//		cur = cur * 10 + root->val;
//		if (root->left == nullptr&& root->right == nullptr)
//			ans += cur;
//		helper(root->left, cur, ans);
//		helper(root->right, cur, ans);
//	}
//
//}
//int sumNumbers(TreeNode* root) {
//	int ans = 0;
//	helper(root,0,ans);
//	return ans;
//}