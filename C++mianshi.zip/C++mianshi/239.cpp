//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//
//vector<int> maxSlidingWindow(vector<int>& nums, int k) {
//	vector<int> res;
//	deque<int> q;
//	for (int i = 0; i < nums.size(); ++i) {
//		if (!q.empty() && q.front() == i - k) 
//			q.pop_front();
//		while (!q.empty() && nums[q.back()] < nums[i]) 
//			q.pop_back();
//		q.push_back(i);
//		if (i >= k - 1) 
//			res.push_back(nums[q.front()]);
//	}
//	return res;
//}
//
//int main()
//{
//	vector<int> aa = { 100,4,201,30,200,2,400 };
//	vector<int> ans = maxSlidingWindow(aa,4);
//
//
//	getchar();
//	return 0;
//}