//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//#include <unordered_set>
//#include <map>
////* Definition for a binary tree node.
//struct TreeNode {
//	int val;
//	TreeNode *left;
//	TreeNode *right;
//	TreeNode(int x) : val(x), left(NULL), right(NULL) {}
//};
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
////best general way:// use iterator
//class ZigzagIterator {
//public:
//	ZigzagIterator(vector<int>& v1, vector<int>& v2) {
//		if (!v1.empty()) 
//			q.push(make_pair(v1.begin(), v1.end()));
//		if (!v2.empty()) 
//			q.push(make_pair(v2.begin(), v2.end()));
//	}
//	int next() {
//		auto it = q.front().first, end = q.front().second;
//		q.pop();
//		if (it + 1 != end) 
//			q.push(make_pair(it + 1, end));
//		return *it;
//	}
//	bool hasNext() {
//		return !q.empty();
//	}
//private:
//	queue<pair<vector<int>::iterator, vector<int>::iterator>> q;
//};
////my
//class ZigzagIterator {
//private:
//	queue<int> q;
//public:
//	ZigzagIterator(vector<int>& v1, vector<int>& v2) {
//		int m = v1.size(), n = v2.size();
//		int temp = max(m, n);
//		for (int i = 0; i<temp; i++) {
//			if (i<m) q.push(v1[i]);
//			if (i<n) q.push(v2[i]);
//		}
//	}
//
//	int next() {
//		if (hasNext()) {
//			int ans = q.front();
//			q.pop();
//			return ans;
//		}
//		return -1;
//	}
//
//	bool hasNext() {
//		return !q.empty();
//	}
//};
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	auto ans = repeatedStringMatch(ss,4);
//
//	getchar();
//	return 0;
//}