//#include<iostream>
//using namespace std;
//#include<vector>
//int main()
//{
//	vector<int> nums = { 9,0,-2 };
//	vector<int > ans(nums.size());
//	/*if (nums.size() <= 0)
//		return ans;*/
//	ans[0] = 1;
//	for (int i = 1; i<nums.size(); i++) {
//		ans[i] = ans[i - 1] * nums[i - 1];
//	}
//	int right = 1;
//	for (int i = nums.size() - 1; i >= 0; i--) {
//		ans[i] = right * ans[i];
//		right = nums[i] * right;
//	}
//
//
//		getchar();
//		return 0;
//}
//
