//#include<iostream>
//using namespace std;
//#include<vector>
//vector<int> countBits(int num) {
//	int count = 0;
//	vector<int> ans = { 0 };
//	for (int i = 1; i <= num; i++) {
//		ans.push_back(oneCount(i));
//
//	}
//	return ans;
//
//}
//
//int oneCount(int num) {
//	int count = 0;
//	while (num > 0) {
//		if (num & 1 == 1)
//			count++;
//		num >>= 1;
//	}
//	return count;
//}
//
//
//int main()
//{
//	int num = 2;
//
//	vector<int> ans(num+1);
//
//	for (int i = 0; i <= num; i++) {
//		int sum = 0;
//		int tt = i;
//		while (tt != 0) {
//			if (tt & 1 == 1)
//				sum++;
//			tt=tt >> 1;
//		}
//		ans[i]=sum;
//
//	}
//
//	getchar();
//	return 0;
//}
