//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
////my
////void dfs(int i, int j, vector<vector<char>>& grid) {
////	if (grid[i][j] == '0')
////		return;
////	grid[i][j] = '0';
////	dfs(i,j+1,grid);
////	dfs(i, j - 1, grid);
////	dfs(i+1, j , grid);
////	dfs(i-1, j, grid);
////
////
////}
////int numIslands(vector<vector<char>>& grid) {
////	int m = grid.size();
////	int n = grid[0].size();
////	int ans = 0;
////	for (int i = 0; i < m; i++) {
////		for (int j = 0; j < n; j++) {
////			if (grid[i][j] == '1') {
////				ans++;
////				dfs(i,j,grid);
////			}
////		}
////	}
////}
//
//
//void dfs(int i, int j, vector<vector<char>>& grid) {
//	if (i < 0 || i >= grid.size() || j < 0 || j >= grid[0].size() || grid[i][j] == '0')
//		return;
//	grid[i][j] = '0';
//	dfs(i + 1, j, grid);
//	dfs(i - 1, j, grid);
//	dfs(i, j - 1, grid);
//	dfs(i, j + 1, grid);
//
//
//}
//int numIslands(vector<vector<char>>& grid) {
//	int ans = 0;
//	for (int i = 0; i<grid.size(); i++)
//		for (int j = 0; j<grid[0].size(); j++) {
//			if (grid[i][j] == '1') {
//				ans++;
//				//grid[i][j] = '0';
//				dfs(i, j, grid);
//			}
//		}
//	return ans;
//}
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	string ss = "2-4A0r7-4k";
//	auto ans = solution(ss, 4);
//
//
//	getchar();
//	return 0;
//}