//#include<iostream>
//using namespace std;
//#include<vector>
////����һ�ֿ���ָ�� ����û������
//int findDuplicate(vector<int>& nums) {
//	int slow = 0, fast = 0, t = 0;
//	while (true) {
//		slow = nums[slow];
//		fast = nums[nums[fast]];
//		if (slow == fast) break;
//	}
//	while (true) {
//		slow = nums[slow];
//		t = nums[t];
//		if (slow == t) break;
//	}
//	return slow;
//}
//int main()
//{
//	vector<int> nums = { 1,3,4,2,2 };
//
//
//	int low = 1, high = nums.size() - 1;
//	int mid;
//	int count = 0;
//	while (low<high) {
//		mid = (low + high) / 2;
//		for (int i = 0; i<nums.size(); i++) {
//			if (nums[i] <= mid) count++;
//		}
//		if (count <= mid)
//			low = mid + 1;
//		else
//			high = mid;
//
//	}
//
//
//		getchar();
//		return 0;
//}
//
//
