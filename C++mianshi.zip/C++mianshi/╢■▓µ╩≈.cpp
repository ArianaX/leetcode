//#include<iostream>
//#include<vector>
//using namespace std;
//struct bitree
//{
//	int data;
//	bitree* left;
//	bitree* right;
//};
//bitree* rconstruction(int* preorder, int* endpreorder, int* inorder, int* endinorder)
//{
//	bitree* root = new bitree();
//	root->data = preorder[0];
//	root->left = root->right = nullptr;
//	int* tempstartinorder = inorder;
//	if (preorder==endpreorder)
//	{
//		if (inorder==endinorder&&*preorder==*inorder)//ֻʣ���һ��
//		{
//			return root;
//		}
//		else
//		{
//			cout << "wrong input!!" << endl;
//		}
//
//	}
//	while (tempstartinorder <= endinorder&& preorder[0] != *tempstartinorder)//�����������в���
//	{
//		tempstartinorder++;
//	}
//	if (tempstartinorder == endinorder&& preorder[0] != *tempstartinorder)
//	{
//		cout << "wrong input!!" << endl;
//		return nullptr;
//	}
//	else
//	{
//		int leftlength = tempstartinorder- inorder;
//		int* rightstartinpreorder = preorder + leftlength + 1;
//		if (leftlength>0)//��������
//		{
//			root->left = rconstruction(preorder + 1, rightstartinpreorder-1, inorder, inorder + leftlength - 1);
//		}
//		if (endpreorder-preorder>1)//������û�е�ʱ��
//		{
//			root->right = rconstruction(rightstartinpreorder, endpreorder, tempstartinorder + 1, endinorder);
//		}
//	}
//	return root;
//}
//bitree* construct(int* preorder, int* inorder, int length)//ͨ��ǰ������ �������е�֪������
//{
//	if (preorder==nullptr||inorder== nullptr ||length<=0)
//	{
//		cout << "wrong input!!" << endl;
//		return nullptr;
//	}
//	else
//	{
//		rconstruction(preorder, preorder+length-1, inorder, inorder + length - 1);
//	}
//}
//
//void printbitree(bitree* b)//�� ����
//{
//	if (b == nullptr)
//	{
//		return;
//	}
//	else
//	{
//		cout << b->data << " " << endl;
//		printbitree(b->left);
//		printbitree(b->right);
//	}
//}
//
//int main()
//{
//	int  preorder[8] = { 1,2,4,7,3,5,6,8 };
//	int inorder[8] = { 4,7,2,1,5,3,8,6 };
//	bitree* result = construct(preorder, inorder, 8);
//	printbitree(result);
//	system("pause");
//}