#include<iostream>
using namespace std;
#include<vector>
#include<algorithm>
#include<unordered_map>
#include<queue>
#include<stack>
#include<string>
#include <set>
#include <unordered_set>
#include <map>
//* Definition for a binary tree node.
struct TreeNode {
	int val;
	TreeNode *left;
	TreeNode *right;
	TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};
//Definition for singly-linked list.
struct ListNode {
     int val;
     ListNode *next;
     ListNode(int x) : val(x), next(NULL) {}
 };



int main()
{
	vector<int> aa = { 100,4,200,1,3,2 };
	auto ans = repeatedStringMatch(ss,4);
	//vector<vector<int>> ans(23, vector<int>());

	getchar();
	return 0;
}