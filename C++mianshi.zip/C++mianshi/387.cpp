//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//int firstUniqChar(string s) {
//	unordered_map<char, int>ans;
//	for (auto aa : s)
//		ans[aa]++;
//	for (int i = 0; i<s.size(); i++) {
//		if (ans[s[0]] == 1)
//			return i;
//	}
//	return -1;
//}
//
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	string ss = "2-4A0r7-4k";
//	auto ans = repeatedStringMatch(ss,4);
//
//
//	getchar();
//	return 0;
//}
//
