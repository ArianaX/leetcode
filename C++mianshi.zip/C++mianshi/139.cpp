//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<unordered_set>
//
//bool dfs(string s, int start, vector<string>& wordDict, vector<bool>& visited) {
//	if (start == s.size()) 
//		return true;
//	if (visited[start]) 
//		return false;
//	visited[start] = true;
//	for (string word : wordDict) {
//		int len = word.size();
//		string w = s.substr(start, len);
//		int end = start + len;
//		if (end>s.size())
//			continue;
//		if (w == word && dfs(s, end, wordDict, visited)) {
//			return true;
//		}
//	}
//	return false;
//}
//bool wordBreak(string s, vector<string>& wordDict) {
//	vector<bool> visited(s.size(), false);
//	return dfs(s, 0, wordDict, visited);
//}
////
//////10.21 dp:
////bool wordBreak(string s, vector<string>& wordDict) {
////	unordered_set<string> wordSet(wordDict.begin(), wordDict.end());
////	vector<bool> dp(s.size() + 1);
////	dp[0] = true;
////	for (int i = 0; i < dp.size(); ++i) {
////		for (int j = 0; j < i; ++j) {
////			if (dp[j] && wordSet.count(s.substr(j, i - j))) {
////				dp[i] = true;
////				break;
////			}
////		}
////	}
////	return dp.back();
////}
//////my
////bool wordBreak(string s, vector<string>& wordDict) {
////	unordered_set<string> dic(wordDict.begin(), wordDict.end());
////	vector<bool> dp(s.size() + 1, false);
////	dp[0] = true;
////	for (int i = 0; i<dp.size(); i++) {
////		for (int j = 0; j<i; j++) {
////			if (dp[j] == true && (dic.count(s.substr(j, i - j)))) {
////				dp[i] = true;
////				break;
////			}
////
////		}
////	}
////	return dp.back();
////}
//int main()
//{
//	vector<string> aa = {"lee","leet","code","tac" };
//	bool ans = wordBreak("leetacodeleet",aa);
//
//	//string aa = "asdeee";
//
//
//	getchar();
//	return 0;
//}