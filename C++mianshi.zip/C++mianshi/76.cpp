//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//
////my
//string minWindow2(string s, string t) {
//	if (t.size()>s.size())
//		return "";
//	int left = 0, count = 0, minL = s.size() + 1;
//	string ans = "";
//	unordered_map<char, int> m;
//	for (char c : t)
//		++m[c];
//	for (int right = 0; right < s.size(); right++) {
//		if (m.find(s[right]) != m.end())//if find it in T
//		{
//			m[s[right]]--;
//			if (m[s[right]] >= 0)
//				count++;
//			while (count == t.size()) {
//				if (right - left + 1<minL) {
//					ans = s.substr(left, right - left + 1);
//					minL = ans.size();
//				}
//				if (m.find(s[left]) != m.end()) {
//					m[s[left]]++;
//					if (m[s[left]]>0)
//						count--;
//				}
//				left++;
//			}
//		}
//			
//	}
//	return ans;
//}
////my
//string minWindow(string s, string t) {
//	unordered_map<char, int> m;
//	for (auto aa : t)
//		m[aa]++;
//	int cnt = 0, left = 0, minL = INT_MAX;
//	string ans;
//	for (int i = 0; i<s.size(); i++) {
//		if (m.find(s[i]) != m.end()) {
//			m[s[i]]--;// if all <=0 then we have the condition
//			if (m[s[i]] >= 0)
//				cnt++;
//			while (cnt == t.size()) {
//				if (minL>i - left + 1) {
//					minL = i - left + 1;
//					ans = s.substr(left, i - left + 1);
//				}
//				if (m.find(s[left]) != m.end()) {
//					m[s[left]]++;
//					if (m[s[left]]>0)
//						cnt--;
//				}
//				left++;
//			}
//
//		}
//	}
//	return ans;
//}
//
////��̫ϲ��
//string minWindow3(string s, string t) {
//	string res = "";
//	unordered_map<char, int> letterCnt;
//	int left = 0, cnt = 0, minLen = INT_MAX;
//	for (char c : t) 
//		++letterCnt[c];
//	for (int i = 0; i < s.size(); ++i) {
//		if (--letterCnt[s[i]] >= 0) 
//			++cnt;
//		while (cnt == t.size()) {
//			if (minLen > i - left + 1) {
//				minLen = i - left + 1;
//				res = s.substr(left, minLen);
//			}
//			if (++letterCnt[s[left]] > 0) 
//				--cnt;
//			++left;
//		}
//	}
//	return res;
//}
//int main()
//{
//	string s = "ADOBECODEBANC", T = "ABC";
//	auto ans = minWindow2(s,T);
//
//
//	getchar();
//	return 0;
//}