//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//string shortestPalindrome(string s) {
//	string t = s;
//	reverse(t.begin(), t.end());
//	int n = s.size(), i = 0;
//	for (i = n; i >= 0; --i) {
//		if (s.substr(0, i) == t.substr(n - i)) {
//			break;
//		}
//	}
//	return t.substr(0, n - i) + s;
//}
////my
//string shortestPalindrome2(string s) {
//	int n = s.size();
//	string t = s;
//	reverse(t.begin(), t.end());
//	int i;
//	for (i = 0; i<n; i++) {
//		if (s.substr(0, n - i) == t.substr(i))
//			break;
//	}
//	return t.substr(0, i) + s;
//}
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	string ss = "abcd";
//	auto ans = shortestPalindrome2(ss);
//
//
//	getchar();
//	return 0;
//}