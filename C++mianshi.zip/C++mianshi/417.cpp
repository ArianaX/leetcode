//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
////Water can only flow in four directions (up, down, left, or right) from a cell to another one with height equal or lower.
//void dfs(vector<vector<int>>& matrix, vector<vector<bool>>& visited, int pre, int i, int j) {
//	int m = matrix.size(), n = matrix[0].size();
//	if (i < 0 || i >= m || j < 0 || j >= n || visited[i][j] || matrix[i][j] < pre) 
//		return;
//	visited[i][j] = true;
//	dfs(matrix, visited, matrix[i][j], i + 1, j);
//	dfs(matrix, visited, matrix[i][j], i - 1, j);
//	dfs(matrix, visited, matrix[i][j], i, j + 1);
//	dfs(matrix, visited, matrix[i][j], i, j - 1);
//}
//vector<pair<int, int>> pacificAtlantic(vector<vector<int>>& matrix) {
//	if (matrix.empty() || matrix[0].empty()) 
//		return {};
//	vector<pair<int, int>> res;
//	int m = matrix.size(), n = matrix[0].size();
//	vector<vector<bool>> pacific(m, vector<bool>(n, false));
//	vector<vector<bool>> atlantic(m, vector<bool>(n, false));
//	for (int i = 0; i < m; ++i) {
//		dfs(matrix, pacific, INT_MIN, i, 0);
//		dfs(matrix, atlantic, INT_MIN, i, n - 1);
//	}
//	for (int i = 0; i < n; ++i) {
//		dfs(matrix, pacific, INT_MIN, 0, i);
//		dfs(matrix, atlantic, INT_MIN, m - 1, i);
//	}
//	for (int i = 0; i < m; ++i) {
//		for (int j = 0; j < n; ++j) {
//			if (pacific[i][j] && atlantic[i][j]) {
//				res.push_back({ i, j });
//			}
//		}
//	}
//	return res;
//}
////my
//void dfs(vector<vector<int>>& matrix, vector<vector<bool>>& visited, int pre, int i, int j) {
//	if (i<matrix.size() || j<matrix[0].size() || visited[i][j] || pre>matrix[i][j])// wrong
//		return;
//	visited[i][j] = true;
//	dfs(matrix, visited, matrix[i][j], i + 1, j);
//	dfs(matrix, visited, matrix[i][j], i - 1, j);
//	dfs(matrix, visited, matrix[i][j], i, j + 1);
//	dfs(matrix, visited, matrix[i][j], i, j - 1);
//
//}
//vector<pair<int, int>> pacificAtlantic(vector<vector<int>>& matrix) {
//	if (matrix.empty() || matrix[0].empty())
//		return{};
//	int m = matrix.size(), n = matrix[0].size();
//	vector<vector<bool>> pp(m, vector<bool>(n, false)), aa(m, vector<bool>(n, false));
//	for (int i = 0; i<m; i++) {
//		dfs(matrix, pp, INT_MIN, i, 0);
//		dfs(matrix, aa, INT_MIN, i, n - 1);
//
//	}
//	for (int j = 0; j<n; j++) {
//		dfs(matrix, pp, INT_MIN, 0, j);
//		dfs(matrix, aa, INT_MIN, m - 1, j);
//
//	}
//
//	vector<pair<int, int>> ans;
//	for (int i = 0; i<m; i++) {
//		for (int j = 0; j<n; j++) {
//			if (pp[i][j] && aa[i][j])
//				ans.push_back({ i,j });
//		}
//	}
//	return ans;
//}
//int main()
//{
//	vector<vector<int>> ss = { { 1, 2,2,3,5 },
//						    	{3,2,3,4,4},
//						    	{2,4,5,3,1} };
//	auto ans = pacificAtlantic(ss);
//
//
//	getchar();
//	return 0;
//}