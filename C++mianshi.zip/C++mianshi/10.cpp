//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//
////bool isMatch(string s, string p) {
////	if (p.empty()) 
////		return s.empty();
////	if (p.size() == 1) {
////		return (s.size() == 1 && (s[0] == p[0] || p[0] == '.'));
////	}
////	if (p[1] != '*') {
////		if (s.empty()) 
////			return false;
////		return (s[0] == p[0] || p[0] == '.') && isMatch(s.substr(1), p.substr(1));
////	}
////	while (!s.empty() && (s[0] == p[0] || p[0] == '.')) {
////		if (isMatch(s, p.substr(2)) ) 
////			return true;
////		s = s.substr(1);
////	}
////	return isMatch(s, p.substr(2));
////}
//
////my
//bool isMatch(string s, string p) {
//	if (p.empty())
//		return s.empty();
//	if (p.size() == 1)
//		return s.size() == 1 && (s[0] == p[0] || p[0] == '.');
//	if (p[1] != '*') {
//		if (s.empty())
//			return false;
//		return (s[0] == p[0] || p[0] == '.') && isMatch(s.substr(1), p.substr(1));
//
//	}
//	while (!s.empty() && (s[0] == p[0] || p[0] == '.')) {
//		if (isMatch(s, p.substr(2)))
//			return true;
//		s = s.substr(1);
//	}
//	return isMatch(s, p.substr(2));
//}
//
//
//int main()
//{
//	//vector<int> aa = { 100,4,200,1,3,2 };
//	string s = "mississippi";
//	string	p = "mis*is*i*p*.";
//	auto ans = isMatch(s,p);
//
//
//	getchar();
//	return 0;
//}