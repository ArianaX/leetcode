//#include<iostream>
//using namespace std;
//#include<vector>
//
//
//int partition(vector<int> & nums, int low, int high) {
//	int temp = nums[low];
//	while (low<high) {
//		while (low<high&& nums[high]>temp)
//			high--;
//		if (low<high) {
//			nums[low] = nums[high];
//			low++;
//		}
//		while (low<high && nums[low]<temp)
//			low++;
//		if (low<high) {
//			nums[high] = nums[low];
//			high--;
//		}
//
//	}
//	nums[low] = temp;
//	return low;
//}
//void QS(vector<int> & nums, int low, int high) {
//	if (low == high)
//		return;
//	int index = partition(nums, low, high);
//	if (index>low)
//		QS(nums, low, index - 1);
//	if (index<high)
//		QS(nums, index + 1, high);
//}
//int findUnsortedSubarray(vector<int>& nums) {
//	vector<int> ss(nums.size());
//	for (int i = 0; i<nums.size(); i++)
//		ss[i] = nums[i];
//	QS(nums, 0, nums.size() - 1);
//	int start, end = -2;
//	for (int i = 0; i<nums.size(); i++) {
//		if (nums[i] != ss[i]) {
//			start = i;
//			break;
//		}
//	}
//	for (int j = nums.size() - 1; j >= 0; j--)
//	{
//		if (nums[j] != ss[j]) {
//			end = j;
//			break;
//		}
//	}
//	if (end == -2)
//		return 0;
//	else
//		return end - start + 1;
//
//}
//
//int main()
//{
//	vector<int> hh = { 1,2,3,4};
//	int c = findUnsortedSubarray(hh);
//}