////169. Majority Element
//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
////fast sort and return the index
//int a=max(12, 3);
//int partition_an(vector <int>& nums, int start, int end)
//{
//	if (start > end || start < 0 || end < 0)
//		return -1;
//	if (start == end)
//		return start;
//	int an = nums[start];
//	while (start < end) {
//		while (start<end&& nums[end]>=an) {
//			end--;
//		}
//		if (nums[end] < an) {
//			swap(nums[start], nums[end]);
//			start++;
//		}
//
//		while (start < end&&nums[start] <= an) {
//			start++;
//		}
//		if (nums[start] > an) {
//			swap(nums[start], nums[end]);
//			end--;
//		}
//	}
//	return start;
//}
//
//// ====================����2====================
//int MoreThanHalfNum_Solution2(vector <int>& numbers, int length)
//{
//
//	int result = numbers[0];
//	int times = 1;
//	for (int i = 1; i < length; ++i)
//	{
//		if (times == 0)
//		{
//			result = numbers[i];
//			times = 1;
//		}
//		else if (numbers[i] == result)
//			times++;
//		else
//			times--;
//	}
//
//
//	return result;
//}
//int main()
//{
//	////first solution:
//	//vector<int> nums = { 87,78,78 };
//	//int start = 0;
//	//int end = nums.size() - 1;
//	//int middle = nums.size() / 2;
//	//int index = partition_an(nums, start, end);
//	//while (index != middle) {
//	//	if (index > middle) {
//	//		end = index - 1;
//	//		index = partition_an(nums, start, end);
//
//	//	}
//
//	//	if (index < middle) {
//	//		start = index + 1;
//	//		index = partition_an(nums, start, end);
//
//	//	}
//	//}
//
//
//	//second
//	vector<int> nums = { 2,1,2,4,2,2,3 };
//	int c=MoreThanHalfNum_Solution2(nums, 7);
//
//	vector<int> nums1 = { 2,1,2,4,2,2,3 };
//	vector<int> nums2 = { 2,1,2,9,2,2,3 };
//	bool q=nums1 == nums2;
//	nums1.insert(nums1.end(), nums2.begin(), nums2.end());
//
//
//	vector<int> nums3(20) ;
//	nums3[0] = 12;
//	getchar();
//
//	return 0;
//}