//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//#include <unordered_set>
//
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//int minPathSum(vector<vector<int> > &grid) {
//	int m = grid.size(), n = grid[0].size();
//	vector<vector<int>> dp(m,vector<int>(n));
//	dp[0][0] = grid[0][0];
//	for (int i = 1; i < m; ++i) 
//		dp[i][0] = grid[i][0] + dp[i - 1][0];
//	for (int i = 1; i < n; ++i) 
//		dp[0][i] = grid[0][i] + dp[0][i - 1];
//
//	for (int i = 1; i < m; ++i) {
//		for (int j = 1; j < n; ++j) {
//			dp[i][j] = grid[i][j] + min(dp[i - 1][j], dp[i][j - 1]);
//		}
//	}
//	return dp[m - 1][n - 1];
//}
////my
//int minPathSum(vector<vector<int>>& grid) {
//	int m = grid.size(), n = grid[0].size();
//	vector<vector<int>> dp(m, vector<int>(n));
//	dp[0][0] = grid[0][0];
//	for (int i = 1; i<m; i++)
//		dp[i][0] = dp[i - 1][0] + grid[i][0];
//	for (int i = 1; i<n; i++)
//		dp[0][i] = dp[0][i - 1] + grid[0][i];
//
//	for (int i = 1; i<m; i++) {
//		for (int j = 1; j<n; j++) {
//			dp[i][j] = grid[i][j] + min(dp[i - 1][j], dp[i][j - 1]);
//		}
//	}
//	return dp.back().back();
//}
//
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	auto ans = repeatedStringMatch(ss,4);
//
//	getchar();
//	return 0;
//}