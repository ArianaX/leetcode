//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//void moveZeroes(vector<int>& nums) {
//	for (int i = 0, j = 0; i < nums.size(); ++i) {
//		if (nums[i]!=0) {
//			swap(nums[i], nums[j++]);
//		}
//	}
//}
////my
//void moveZeroes2(vector<int>& nums) {
//	int end = 0;
//	for (int i = 0; i<nums.size(); i++) {
//		if (nums[i] != 0) {
//			nums[end++] = nums[i];
//		}
//	}
//	for (int i = end; i<nums.size(); i++) {
//		nums[i] = 0;
//	}
//}
//
//int main()
//{
//	vector<int> aa = { 100,1,0,4,0,200,1,3,2 };
//	moveZeroes2(aa);
//
//
//	getchar();
//	return 0;
//}