//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//bool canJump(vector<int>& nums) {
//	vector<int> dp(nums.size(), 0);
//	for (int i = 1; i < nums.size(); ++i) {
//		dp[i] = max(dp[i - 1], nums[i - 1]) - 1;
//		if (dp[i] < 0) return false;
//	}
//	return dp.back() >= 0;
//}
//
//
//int main()
//{
//	vector<int> aa = { 2,2,1,0 };
//	bool ans = canJump(aa);
//
//
//	getchar();
//	return 0;
//}