//#include<iostream>
//using namespace std;
//#include<vector>
//#include<stack>
//int main()
//{
//
//	string s = "cbaebabacd";
//	string p = "abc";
//	int n = s.length();
//	int l = p.length();
//	vector<int> ans;
//	vector<int> vp(26, 0);
//	vector<int> vs(26, 0);
//	for (char c : p) ++vp[c - 'a'];
//	for (int i = 0; i < n; ++i) {
//		if (i >= l) 
//			--vs[s[i - l] - 'a'];
//		++vs[s[i] - 'a'];
//		if (vs == vp) 
//			ans.push_back(i + 1 - l);
//	}
//
//
//
//
//	vector<int> &mm = {1,1,1,1,1};
//	vector<int> num;
//	num = mm;
//	num[0] = 222;
//
//
//
//	getchar();
//	return 0;
//}