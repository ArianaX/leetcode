//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//int evalRPN(vector<string> &tokens) {
//	if (tokens.size() == 1) 
//		return atoi(tokens[0].c_str());
//	stack<int> s;
//	for (int i = 0; i < tokens.size(); ++i) {
//		if (tokens[i] != "+" && tokens[i] != "-" && tokens[i] != "*" && tokens[i] != "/")
//		{
//			s.push(atoi(tokens[i].c_str()));
//		}
//		else {
//			int m = s.top();
//			s.pop();
//			int n = s.top();
//			s.pop();
//			if (tokens[i] == "+") s.push(n + m);
//			if (tokens[i] == "-") s.push(n - m);
//			if (tokens[i] == "*") s.push(n * m);
//			if (tokens[i] == "/") s.push(n / m);
//		}
//	}
//	return s.top();
//}
////my
//int evalRPN(vector<string>& tokens) {
//	stack<int> ans;
//	for (auto a : tokens) {
//		if (a != "+"&&a != "-"&&a != "*"&&a != "/")
//			ans.push(atoi(a.c_str()));
//		else {
//			int m = ans.top();
//			ans.pop();
//			int n = ans.top();
//			ans.pop();
//			if (a == "+")
//				ans.push(m + n);
//			if (a == "-")
//				ans.push(n - m);
//			if (a == "*")
//				ans.push(m*n);
//			if (a == "/")
//				ans.push(n / m);
//		}
//	}
//	return ans.top();
//}
//int main()
//{
//	vector<string> aa = { "10", "6", "9", "3", "+", "-11", "*", "/", "*", "17", "+", "5", "+" };
//	auto ans = evalRPN(aa);
//
//
//	getchar();
//	return 0;
//}