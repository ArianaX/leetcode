//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//
//
//
//class Node {
//public:
//	int val;
//	Node* next;
//
//	Node() {}
//
//	Node(int _val, Node* _next) {
//		val = _val;
//		next = _next;
//	}
//};
//////correct
////Node* insert(Node* head, int insertVal) {
////	Node* ans=new Node();
////	if (head == nullptr) {
////		ans->val = insertVal;
////		ans->next = ans;
////		return ans;
////	}
////	Node* prev = head;
////	Node* next = head->next;
////	bool inserted = false;
////	while (true) {
////		// insert when:
////		// 1. prev <= insertVal <= next
////		// 2. insertVal < min (insert at the tail)
////		// 3. insertVal > max (insert at the tail)
////		if ((prev->val <= insertVal && insertVal <= next->val) ||
////			(prev->val > next->val && insertVal < next->val) ||
////			(prev->val > next->val && insertVal > prev->val)) {
////			prev->next = new Node(insertVal, next);
////			inserted = true;
////			break;
////		}
////
////		prev = prev->next;
////		next = next->next;
////		if (prev == head)//nulllptrr 
////			break;
////	}
////
////	if (!inserted) {
////		// The only reason why `value` was not inserted is that
////		// all values in the list are the same and are not equal to `value`.
////		// So, we could insert `value` anywhere.
////		prev->next = new Node(insertVal, next);
////	}
////
////	return head;
////
////
////}
//////my  time limited problem
//Node* insert(Node* head, int insertVal) {
//	Node* ans = new Node();
//	if (head == nullptr) {
//		ans->val = insertVal;
//		ans->next = ans;
//		return ans;
//	}
//	Node* pre = head;
//	Node* next = head->next;
//	while (true) {// because the true you need to find the final end.
//		if ((pre->val <= insertVal && insertVal <= next->val) ||
//			(pre->val>next->val &&insertVal<next->val) ||
//			(pre->val>next->val &&insertVal>pre->val)) {
//			pre->next = new Node(insertVal, next);
//			break;
//		}
//		pre = pre->next;
//		next = next->next;
//		if (pre == head) {// put it here.
//			pre->next = new Node(insertVal, next);
//			break;
//		}
//	}
//	return head;
//}
//
//
//int main()
//{
//	Node* s3 = new Node();
//	Node* s4 = new Node();
//	Node* s1 = new Node();
//	s3->val = 3;
//	s4->val = 4;
//	s1->val = 1;
//	s3->next = s4;
//	s4->next = s1;
//	s1->next = s3;
//	
//	Node* s0 = new Node();
//	s0->val = 10; s0->next = s0;
//
//	auto ans = insert(s3,2);
//
//
//	getchar();
//	return 0;
//}