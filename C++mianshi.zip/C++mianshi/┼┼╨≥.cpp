//#include<iostream>
//#include<vector>
//using namespace std;//��С����
//int* b = new int();
//void printArray(int a[], int length)
//{
//	for (int i = 0; i < length; i++)
//	{
//		cout << a[i] << " ";
//	}
//}
//int* insertSort(int a[], int length)
//{
//	if (length <= 0 ||a==NULL)
//	{
//		cout << "wrong input" << endl;
//		return NULL;
//	}
//	else if (length == 1)
//	{
//		return a;
//	}
//	else
//	{
//		int j,i,temp;
//		for (i = 1; i < length; i++)
//		{
//			temp = a[i];
//			
//			for (j = i-1; j >=0&&a[j]>temp; j--)
//			{
//				a[j+1] = a[j];
//			}
//			a[j + 1] = temp;
//
//		}
//	}
//	return a;
//}
//int* bubbleSort(int a[], int length)
//{
//	int temp;
//	for (int i = 0; i < length-1; i++)
//	{
//		for (int j = 0; j < length-i-1; j++)
//		{
//			if (a[j]>a[j+1])
//			{
//				temp = a[j + 1];
//				a[j + 1] = a[j];
//				a[j] = temp;
//			}
//		}
//	}
//	return a;
//}
//
////��������
//int partition(vector<int>& nums, int low, int high) {
//	int start = nums[low];
//	while (low < high) {
//		while (low<high&& nums[high]>start)
//			high--;
//		if (low < high) {
//			swap(nums[low], nums[high]);
//			low++;
//		}
//		while (low < high&&nums[low] < start)
//			low++;
//		if (low < high) {
//			swap(nums[low], nums[high]);
//			high--;
//		}
//	}
//	nums[low] = start;
//	return low;
//}
//void Quick(vector<int>& nums, int low, int high) {
//	if (low >= high)
//		return;
//	int idx = partition(nums,low,high);
//	Quick(nums, low, idx - 1);
//	Quick(nums, idx + 1, high);
//}
//vector<int> QS(vector<int>& nums, int low, int high) {
//	if (nums.size() == 0)
//		return {};
//	Quick(nums, low, high);
//	return nums;
//}
////
////int partition(int a[], int low, int high)
////{
////	int temp = a[low];
////	while (low<high)
////	{
////		while (low<high&&a[high]>temp)
////		{
////			high--;
////		}
////		if (low<high)
////		{
////			a[low] = a[high];
////			low++;
////		}
////		
////		while (low<high&&a[low]<temp)
////		{
////			low++;
////		}
////		if (low<high)
////		{
////			a[high] = a[low];
////			high--;
////		}
////	}
////	a[low] = temp;
////	return low;
////}
////void QuickSort(int a[], int low, int high)//����pivot�±�
////{
////	if (low==high)
////	{
////		return;
////	}
////	else
////	{
////		int index = partition(a, low, high);
////		if (index>low)
////		{
////			QuickSort(a, low, index - 1);
////		}
////		if (index<high)
////		{
////			QuickSort(a, index + 1, high);
////		}
////	}
////}
////
////
////int* QS(int a[], int low, int high)
////{
////	QuickSort(a, low, high);
////	return a;
////
////}
//
////mergeSort
//void Merge(vector<int>& nums, int low, int high) {
//	int mid = (low + high) / 2;
//	vector<int> left(mid+1), right(high+1);
//	for (int i = low; i <= mid; i++)
//		left[i]=nums[i];
//	for (int i = mid + 1; i <= high; i++)
//		right[i]=nums[i];
//
//	int i = low, j = mid+1, idx = low;
//	while (i <= mid && j<=high) {//right-->j
//		if (right[j]<left[i]) {
//			nums[idx++] = right[j++];
//		}
//		else {
//			nums[idx++] = left[i++];
//		}
//	}
//	while (i <= mid) {
//		nums[idx++] = left[i++];
//	}
//	while (j<=high) {
//		nums[idx++] = right[j++];
//	}
//}
//void MergeS(vector<int>& nums, int low, int high) {
//	if (low >= high)
//		return;
//	int mid = (low + high) / 2;
//
//	MergeS(nums, low, mid);
//	MergeS(nums, mid + 1, high);
//	Merge(nums, low, high);
//}
//vector<int> MS(vector<int>& nums, int low, int high) {
//	if (nums.size() == 0)
//		return {};
//	MergeS(nums, low, high);
//	return nums;
//}
////
////void CoppyArray(int des[], int source[], int start, int end)//��B���Ƶ�A��
////{
////	for (int i = start; i <= end; i++)
////	{
////		des[i] = source[i];
////	}
////}
////void Merge(int a[], int left, int right)
////{
////	int k = left;
////	int mid = (left + right) / 2;
////	int i = left, j = mid + 1;
////	while (i<=mid&&j<=right)
////	{
////		if (a[i] < a[j])
////		{
////			b[k] = a[i];
////			k++;
////			i++;
////		}
////		else
////		{
////			b[k] = a[j];
////			k++;
////			j++;
////		}
////	}
////	while (i<=mid)
////	{
////		b[k] = a[i];
////		k++;
////		i++;
////	}
////	while (j<=right)
////	{
////		b[k] = a[j];
////		k++;
////		j++;
////	}
////	CoppyArray(a, b, left, right);
////}
////void MergeSort(int a[], int left, int right)
////{
////	int mid = (left + right) / 2;
////	if (left<right)
////	{
////		MergeSort(a, left, mid);
////		MergeSort(a, mid + 1, right);
////		Merge(a, left, right);
////	}
////	
////}
////int* MS(int a[], int left, int right)
////{
////	MergeSort(a, left, right);
////	return a;
////}
//
////���ֲ���
//bool BinarySearch(int* input, int value,int length)
//{
//	int low = 0;
//	int high = length - 1;
//	int mid = high / 2;
//	while (input[mid]!=value&&high>=low)
//	{
//		mid = low+(high-low) / 2;
//		if (value>input[mid])
//		{
//			low = mid + 1;
//		}
//		else
//		{
//			high = mid - 1;
//		}
//		
//	}
//	if (input[mid]==value)
//	{
//		return true;
//	}
//	if (high<low)
//	{
//		return false;
//	}
//
//}
//int main()
//{
//	/*int a[] = { 17,46,32,87,58,9,50,38 };
//	int* result;
//	result = MS(a, 0,7);
//	printArray(result,8);
//	bool q=BinarySearch(result, 66,8);
//	cout << q << endl;*/
//
//	vector<int> vv = { 58,9,50,38,46,32,87,17 };
//	vector<int> ans = MS(vv, 0, 7);
//
//
//
//
//	getchar();
//	return 0;
//
//}