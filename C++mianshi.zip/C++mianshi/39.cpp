//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//
//void DFS(vector<int>& nums, vector<vector<int>>& ans, vector<int>& temp, int target, int current, int index) {
//	if (current>target) 
//		return;
//	if (current == target) {
//		ans.push_back(temp);
//		return;
//	}
//
//	for (int i = 0; i<nums.size(); i++) {
//		if (temp.size()==0 || nums[i] >= temp.back()) {
//			current += nums[i];
//			temp.push_back(nums[i]);
//			DFS(nums, ans, temp, target, current, index + 1);
//			temp.pop_back();
//			current -= nums[i];
//		}		
//	}
//}
//vector<vector<int>> combinationSum(vector<int>& candidates, int target) {
//	vector<vector<int>> ans;
//	vector<int> temp;
//	DFS(candidates, ans, temp, target, 0, 0);
//	return ans;
//}
//
//int main()
//{
//	vector<int> nums = { 2,3,5 };
//	vector<vector<int>> qq = combinationSum(nums, 8);
//	getchar();
//	return 0;
//}