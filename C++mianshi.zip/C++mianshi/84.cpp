//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//
//int largestRectangleArea(vector<int>& heights) {
//	int res = 0;
//	stack<int> st;
//	heights.push_back(0);
//	for (int i = 0; i < heights.size(); ++i) {
//		while (!st.empty() && heights[st.top()] >= heights[i]) {
//			int cur = st.top(); 
//			st.pop();
//			res = max(res, heights[cur] * (st.empty() ? i : (i - st.top() - 1)));
//		}
//		st.push(i);
//	}
//	return res;
//}
//
//int main()
//{
//	vector<int> aa = {2,3,5,4,1,1 };
//	int ans = largestRectangleArea(aa);
//
//
//	getchar();
//	return 0;
//}