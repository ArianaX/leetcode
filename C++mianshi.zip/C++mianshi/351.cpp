//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
////answer1:
//
////int helper(int num, int len, int res, int m, int n, vector<vector<int>> &jumps, vector<bool> &visited) {
////	if (len >= m) 
////		++res;
////	++len;
////	if (len > n) 
////		return res;
////	visited[num] = true;
////	for (int next = 1; next <= 9; ++next) {
////		int jump = jumps[num][next];
////		if (!visited[next] && (jump == 0 || visited[jump])) {
////			res = helper(next, len, res, m, n, jumps, visited);
////		}
////	}
////	visited[num] = false;
////	return res;
////}
////int numberOfPatterns(int m, int n) {
////	int res = 0;
////	vector<bool> visited(10, false);
////	vector<vector<int>> jumps(10, vector<int>(10, 0));
////	jumps[1][3] = jumps[3][1] = 2;
////	jumps[4][6] = jumps[6][4] = 5;
////	jumps[7][9] = jumps[9][7] = 8;
////	jumps[1][7] = jumps[7][1] = 4;
////	jumps[2][8] = jumps[8][2] = 5;
////	jumps[3][9] = jumps[9][3] = 6;
////	jumps[1][9] = jumps[9][1] = jumps[3][7] = jumps[7][3] = 5;
////	res += helper(1, 1, 0, m, n, jumps, visited) * 4;
////	res += helper(2, 1, 0, m, n, jumps, visited) * 4;
////	res += helper(5, 1, 0, m, n, jumps, visited);
////	return res;
////}
////my
//int helper(int i, int j, int cur, vector<vector<int>>&jumps, vector<vector<bool>>&visit, int m, int n, int ans) {
//	if (cur >= m ) 
//		ans++;
//
//	if (cur>=n)
//		return ans;
//
//	visit[i][j] = true;
//
//	for (int k = 0; k<3; k++)
//		for (int l = 0; l<3; l++) {
//			int jj = jumps[i * 3 + j + 1][k * 3 + l + 1];
//			if (!visit[k][l] && (jj == 0 || visit[(jj - 1) / 3][(jj - 1) % 3])) {
//				ans = helper(k, l, cur + 1, jumps, visit, m, n, ans);
//			}
//		}
//	visit[i][j] = false;
//	return ans;
//}
//int numberOfPatterns(int m, int n) {
//	vector<vector<bool>> visit(3, vector<bool>(3, false));
//	vector<vector<int>> jumps(10, vector<int>(10, 0));
//	jumps[1][3] = jumps[3][1] = 2;
//	jumps[4][6] = jumps[6][4] = 5;
//	jumps[7][9] = jumps[9][7] = 8;
//	jumps[1][7] = jumps[7][1] = 4;
//	jumps[2][8] = jumps[8][2] = 5;
//	jumps[3][9] = jumps[9][3] = 6;
//	jumps[1][9] = jumps[9][1] = jumps[3][7] = jumps[7][3] = 5;
//	int ans = 0;
//	ans += helper(0, 0, 1, jumps, visit, m, n, 0) * 4;
//	ans += helper(0, 1, 1, jumps, visit, m, n, 0) * 4;
//	ans += helper(1, 1, 1, jumps, visit, m, n, 0);
//	return ans;
//}
//
//
//////hard one i don't get it**************
////int count(int m, int n, int used, int i1, int j1) {
////	int res = m <= 0;
////	if (!n) 
////		return 1;
////	for (int i = 0; i < 3; ++i) {
////		for (int j = 0; j < 3; ++j) {
////			int I = i1 + i, J = j1 + j, used2 = used | (1 << (i * 3 + j));
////			if (used2 > used && (I % 2 || J % 2 || used2 & (1 << (I / 2 * 3 + J / 2)))) {
////				res += count(m - 1, n - 1, used2, i, j);
////			}
////		}
////	}
////	return res;
////}
////int numberOfPatterns(int m, int n) {
////	return count(m, n, 0, 1, 1);
////}
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	string ss = "2-4A0r7-4k";
//	auto ans = numberOfPatterns(3,3);
//
//
//	getchar();
//	return 0;
//}