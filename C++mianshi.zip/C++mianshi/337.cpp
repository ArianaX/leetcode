//#include<iostream>
//using namespace std;
//#include<vector>
//
//
//
//int rob(TreeNode* root) {
//	if (root == NULL)
//		return 0;
//	else if (root->left == NULL && root->right == NULL)
//		return root->val;
//	else if (root->left == NULL)
//		return max((root->val) + rob(root->right->left) + rob(root->right->right), rob(root->right));
//	else if (root->right == NULL)
//		return max((root->val) + rob(root->left->left) + rob(root->left->right), rob(root->left));
//	else 
//		return max((root->val) + rob(root->right->left) + rob(root->right->right) + rob(root->left->left) + rob(root->left->right), rob(root->right) + rob(root->left));
//}