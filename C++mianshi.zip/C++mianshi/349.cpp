//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
////vector<int> intersection(vector<int>& nums1, vector<int>& nums2) {
////	set<int> s(nums1.begin(), nums1.end()), res;
////	for (auto a : nums2) {
////		if (s.count(a)) 
////			res.insert(a);
////	}
////	return vector<int>(res.begin(), res.end());
////}
//////my
////vector<int> intersection(vector<int>& nums1, vector<int>& nums2) {
////	set<int> temp(nums1.begin(), nums1.end());
////	set<int> ans;
////	for (auto a : nums2) {
////		if (temp.count(a))
////			ans.insert(a);
////	}
////	return vector<int>(ans.begin(), ans.end());
////}
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	string ss = "2-4A0r7-4k";
//	//auto ans = repeatedStringMatch(ss,4);
//	set<int> temp;
//	temp.insert(10);
//	temp.insert(10);
//	temp.size();
//
//
//	getchar();
//	return 0;
//}