//#include<iostream>
//using namespace std;
////seperate the array by odd  and even
//bool isEven(int i) 
//{
//	if (i % 2 == 1) return false;
//	else
//		return true;
//}
//void reorder(int* arr,int length)
//{
//	if (arr == nullptr || length == 0) return;
//
//	int* pBegin, *pEnd;
//	pBegin = arr;
//	pEnd = arr+length-1;
//	while (pBegin < pEnd) {
//		while (pBegin < pEnd && (!isEven(*pBegin))) {
//			pBegin++;
//		}
//		while (pBegin < pEnd && isEven(*pEnd)) {
//			pEnd--;
//		}
//		if (pBegin < pEnd) {
//			int temp = *pBegin;
//			*pBegin = *pEnd;
//			*pEnd = temp;
//		}
//		
//	}
//}
//void printArray(int * arr, int length) {
//	for (int i = 0; i < length; i++) {
//		cout << *arr << " ";
//		arr++;
//	}
//
//}
//int main()
//{
//	int arrA[10] = { 1, 2, 3, 4, 5, 6, 7, 8, 9,0 };
//	reorder(arrA,10);
//	printArray(arrA,10);
//
//	getchar();
//	return 0;
//}