//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//
//#include<unordered_set>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//enum ExceptionType {
//	NoException,           // Everything ok!
//	SyscallException,      // A program executed a system call.
//	PageFaultException,    // No valid translation found
//	ReadOnlyException,     // Write attempted to page marked 
//						   // "read-only"
//						   BusErrorException,     // Translation resulted in an 
//												  // invalid physical address
//												  AddressErrorException, // Unaligned reference or one that
//																		 // was beyond the end of the
//																		 // address space
//																		 OverflowException,     // Integer overflow in add or sub.
//																		 IllegalInstrException, // Unimplemented or reserved instr.
//
//																		 NumExceptionTypes
//};
//
//bool isValid(string t) {
//	int cnt = 0;
//	for (int i = 0; i < t.size(); ++i) {
//		if (t[i] == '(') 
//			++cnt;
//		else if (t[i] == ')' && --cnt < 0) 
//			return false;
//	}
//	return cnt == 0;
//}
//vector<string> removeInvalidParentheses(string s) {
//	vector<string> res;
//	unordered_set<string> visited{ { s } };
//	queue<string> q{ { s } };
//	bool found = false;
//	while (!q.empty()) {
//		string t = q.front(); 
//		q.pop();
//		if (isValid(t)) {
//			res.push_back(t);
//			found = true;
//		}
//		if (found) 
//			continue;
//		for (int i = 0; i < t.size(); ++i) {
//			if (t[i] != '(' && t[i] != ')') 
//				continue;
//			string str = t.substr(0, i) + t.substr(i + 1);
//			if (!visited.count(str)) {
//				q.push(str);
//				visited.insert(str);
//			}
//		}
//	}
//	return res;
//}
//
//
//int main()
//{
//	string aa = "(a)())()";
//	auto ans = removeInvalidParentheses(aa);
//
//
//
//	getchar();
//	return 0;
//}