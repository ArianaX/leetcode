//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<set>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//
//vector<pair<int, int>> getSkyline(vector<vector<int>>& buildings) {
//	vector<pair<int, int>> h, res;
//	multiset<int> m;
//	int pre = 0, cur = 0;
//	for (auto &a : buildings) {
//		h.push_back({ a[0], -a[2] });
//		h.push_back({ a[1], a[2] });
//	}
//	sort(h.begin(), h.end());
//	m.insert(0);
//	for (auto &a : h) {
//		if (a.second < 0) 
//			m.insert(-a.second);
//		else 
//			m.erase(m.find(a.second));
//		cur = *m.rbegin();
//		if (cur != pre) {
//			res.push_back({ a.first, cur });
//			pre = cur;
//		}
//	}
//	return res;
//}vector<pair<int, int>> getSkyline2(vector<vector<int>>& buildings) {
//	vector<pair<int, int>> ans, h;
//	multiset<int> m;
//	int pre = 0, cur = 0;
//	for (auto a : buildings) {
//		h.push_back({ a[0],-a[2] });
//		h.push_back({ a[1],a[2] });
//	}
//	sort(h.begin(), h.end());
//	m.insert(0);
//
//	for (auto a : h) {
//		if (a.second <= 0)
//			m.insert(-a.second);
//		else
//			m.erase(m.find(a.second));
//		cur = *m.rbegin();
//		if (cur != pre) {
//			ans.push_back({ a.first,cur });
//			pre = cur;
//		}
//	}
//	return ans;
//
//}
//int main()
//{
//	vector<vector<int>> aa = { {2, 9, 10},{3, 7, 15},{5, 12, 12},{15, 20, 10},{19, 24, 8} };
//	auto ans = getSkyline2(aa);
//
//
//	getchar();
//	return 0;
//}