//#include<iostream>
//using namespace std;
//bool Increment(char* number)
//{
//	bool isOverflow = false;
//	int nTakeOver = 0;
//	int nLength = sizeof(number)-1;
//	for (int i = nLength - 1; i >= 0; i--)
//	{
//		int nSum = number[i] - '0' + nTakeOver;
//		if (i==nLength-1)
//		{
//			nSum++;
//		}
//		if (nSum>=10)
//		{
//			if (i == 0)
//			{
//				isOverflow = true;
//			}
//			else
//			{
//				nSum = nSum - 10;
//				nTakeOver = 1;
//				number[i] = '0' + nSum;
//			}			
//		}
//		else
//		{
//			number[i] = '0' + nSum;
//			break;
//		}
//	}
//
//	return isOverflow;
//}
//void PrintNumber(char* number)
//{
//	for (int i = 0; i < sizeof(number)-1; i++)
//	{
//		cout << number[i];
//	}
//	cout << endl;
//}
//void PrintToMaxNDigits(int n)
//{
//	if (n <= 0)
//	{
//		return;
//	}
//	char* number = new char[n + 1]{'0','0', '0'};
//	number[n] = '\0';
//	while (!Increment(number))
//	{
//		PrintNumber(number);
//	}
//	delete[] number;
//}
//int main()
//{
//	PrintToMaxNDigits(3);
//	system("pause");
//}