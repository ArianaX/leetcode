//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//string licenseKeyFormatting(string S, int K) {
//	string res = "";
//	for (int i = (int)S.size() - 1; i >= 0; --i) {
//		if (S[i] != '-') {
//			((res.size() % (K + 1) - K) ? res : res += '-') += toupper(S[i]);
//		}
//	}
//	return string(res.rbegin(), res.rend());
//}
//
////my
//string solution(string &S, int K) {
//	// write your code in C++14 (g++ 6.2.0)
//	int cnt = 0;
//	string ans;
//	for (int i = 0; i < S.size(); i++) {
//		if (S[i] != '-') {
//			cnt++;
//			if (S[i] >= 'a' &&S[i] <= 'z')
//				ans += S[i] - 32;
//			else
//				ans += S[i];
//		}
//	}
//	if (cnt <= K)
//		return ans;
//
//	int first = ans.size() % K;
//	int mm = ans.size() / K;
//	int c = first;
//	string temp = ans.substr(0, first);
//	for (int i = 0; i < mm; i++) {
//		if (first == 0 && i == 0)
//			temp = ans.substr(c, K);
//		else
//			temp += '-' + ans.substr(c, K);
//		c = c + K;
//	}
//
//	return temp;
//}
//
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	string ss = "2-4A0r7-4k";
//	auto ans = solution(ss, 4);
//
//
//	getchar();
//	return 0;
//}