//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//#include <unordered_set>
//
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//
////int rob(vector<int> &nums, int left, int right) {
////	int a = 0, b = 0;
////	for (int i = left; i < right; ++i) {
////		int m = a, n = b;
////		a = n + nums[i];
////		b = max(m, n);
////	}
////	return max(a, b);
////}
////int rob(vector<int>& nums) {
////	if (nums.size() <= 1) 
////		return nums.empty() ? 0 : nums[0];
////	return max(rob(nums, 0, nums.size() - 1), rob(nums, 1, nums.size()));
////}
//////way 2
////int rob(vector<int> &nums, int left, int right) {
////	if (right - left <= 1) 
////		return nums[left];
////	vector<int> dp(right, 0);
////	dp[left] = nums[left];
////	dp[left + 1] = max(nums[left], nums[left + 1]);
////	for (int i = left + 2; i < right; ++i) {
////		dp[i] = max(nums[i] + dp[i - 2], dp[i - 1]);
////	}
////	return dp.back();
////}
////
////int rob(vector<int>& nums) {
////	if (nums.size() <= 1) 
////		return nums.empty() ? 0 : nums[0];
////	return max(rob(nums, 0, nums.size() - 1), rob(nums, 1, nums.size()));
////}
////my
//int helper(vector<int>& nums, int start, int end) {
//	if (end - start<1)
//		return nums[start];
//	vector<int> dp(end+1);
//	dp[start] = nums[start];
//	dp[start + 1] = max(nums[start], nums[start + 1]);
//	for (int i = start + 2; i<=end; i++) {
//		dp[i] = max(dp[i - 2] + nums[i], dp[i - 1]);
//	}
//	return dp.back();
//}
//int rob(vector<int>& nums) {
//	if (nums.size() <= 1)
//		return nums.empty() ? 0 : nums[0];
//	return max(helper(nums, 0, nums.size() - 2), helper(nums, 1, nums.size() - 1));
//}
//int main()
//{
//	vector<int> aa = { 1,2,3,1 };
//	auto ans = rob(aa);
//
//	getchar();
//	return 0;
//}