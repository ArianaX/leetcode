//#include<iostream>
//using namespace std;
//int main()
//{
//	int x = 11, y = 5;
//	unsigned int r = x ^ y;
//
//	getchar();
//	return 0;
//}