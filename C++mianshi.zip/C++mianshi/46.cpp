//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//
//void permuteDFS(vector<int> &num, int start, vector<vector<int> > &res) {
//	if (start >= num.size()) 
//		res.push_back(num);
//	for (int i = start; i < num.size(); ++i) {
//		swap(num[start], num[i]);
//		permuteDFS(num, start + 1, res);
//		swap(num[start], num[i]);
//	}
//}
//
//vector<vector<int> > permute(vector<int> &num) {
//	vector<vector<int> > res;
//	permuteDFS(num, 0, res);
//	return res;
//}
//int main()
//{
//	vector<int> nums = { 1,6,3,4 };
//	//second:
//	vector<vector<int>> ans= permute(nums);
//
//
//
//
//
//	//first:
//	/*vector<vector<int>> ans;
//	sort(nums.begin(), nums.end());
//	ans.push_back(nums);
//	for (;;) {
//		int id = -1;
//		for (int i = nums.size() - 1; i > 0; --i) {
//			if (nums[i] > nums[i - 1]) {
//				id = i - 1;
//				break;
//			}
//		}
//		if (id == -1) {
//			break;
//		}
//		for (int i = nums.size() - 1;; --i) {
//			if (nums[i] > nums[id]) {
//				swap(nums[i], nums[id]);
//				reverse(nums.begin() + id + 1, nums.end());
//				break;
//			}
//		}
//		ans.push_back(nums);
//	}*/
//
//	getchar();
//	return 0;
//}
