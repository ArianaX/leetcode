//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//int smallestDistancePair(vector<int>& nums, int k) {
//	sort(nums.begin(), nums.end());
//	int n = nums.size(), left = 0, right = nums.back() - nums[0];
//	while (left < right) {
//		int mid = left + (right - left) / 2, cnt = 0, start = 0;
//		for (int i = 0; i < n; ++i) {
//			while (start < n && nums[i] - nums[start] > mid) 
//				++start;
//			cnt += i - start;
//		}
//		if (cnt < k) 
//			left = mid + 1;
//		else 
//			right = mid;
//	}
//	return right;
//}
////my
//int smallestDistancePair2(vector<int>& nums, int k) {
//	sort(nums.begin(), nums.end());
//	int n = nums.size();
//	if (n == 0)
//		return 0;
//	int left = 0, right = nums[n - 1] - nums[0];
//	while (left<right) {
//		int mid = (right + left) / 2;
//		int start = 0, cnt = 0;
//		for (int i = 0; i<n; i++) {
//			while (start <= i && nums[i] - nums[start]>mid)
//				start++;
//			cnt += i - start;
//		}
//		if (cnt<k)
//			left = mid + 1;
//		else
//			right = mid;
//	}
//	return right;
//}
//int main()
//{
//	vector<int> aa = { 1,20,30,3,50 };
//	auto ans = smallestDistancePair(aa,2);
//
//
//	getchar();
//	return 0;
//}