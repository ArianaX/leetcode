////230
////my
//int helper(TreeNode* root, int k, int &cur) {
//	if (!root)
//		return -1;
//	int val = helper(root->left, k, cur);
//	if (cur == k)
//		return val;
//	cur++;
//	if (k == cur)
//		return root->val;
//
//	return helper(root->right, k, cur);
//
//}
//int kthSmallest(TreeNode* root, int k) {
//	int cur = 0;
//	return helper(root, k, cur);
//}
//
//int kthSmallestDFS(TreeNode* root, int &k) {
//	if (!root)
//		return -1;
//	int val = kthSmallestDFS(root->left, k);
//	if (k == 0)
//		return val;
//	if (--k == 0)
//		return root->val;
//	return kthSmallestDFS(root->right, k);
//}
//int kthSmallest(TreeNode* root, int k) {
//	return kthSmallestDFS(root, k);
//}