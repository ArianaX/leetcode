//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//#include <unordered_set>
//#include <map>
////* Definition for a binary tree node.
//struct TreeNode {
//	int val;
//	TreeNode *left;
//	TreeNode *right;
//	TreeNode(int x) : val(x), left(NULL), right(NULL) {}
//};
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//// Encodes a list of strings to a single string.
//string encode(vector<string>& strs) {
//	string res = "";
//	for (auto a : strs) {
//		res.append(to_string(a.size())).append("/").append(a);
//	}
//	return res;
//}
//// Decodes a single string to a list of strings.
//vector<string> decode(string s) {
//	vector<string> res;
//	while (!s.empty()) {
//		int found = s.find("/");
//		int len = atoi(s.substr(0, found).c_str());
//		s = s.substr(found + 1);
//		res.push_back(s.substr(0, len));
//		s = s.substr(len);
//	}
//	return res;
//}
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	auto ans = repeatedStringMatch(ss, 4);
//	//vector<vector<int>> ans(23, vector<int>());
//
//	getchar();
//	return 0;
//}