//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//
//int numSquares(int n) {
//	vector<int> dp(n + 1, INT_MAX);
//	dp[0]=0;
//	for (int i=0; i<n; i++)
//		for (int j = 1; i + j * j <= n; j++)
//			dp[i + j * j] = min(dp[i + j * j], dp[i] + 1);
//	return dp[n];
//
//}
//int main()
//{
//
//	int ans = numSquares(12);
//
//
//	getchar();
//	return 0;
//}