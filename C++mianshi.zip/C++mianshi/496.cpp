//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//vector<int> nextGreaterElement(vector<int>& findNums, vector<int>& nums) {
//	vector<int> res(findNums.size());
//	unordered_map<int, int> m;
//	for (int i = 0; i < nums.size(); ++i) {
//		m[nums[i]] = i;
//	}
//	for (int i = 0; i < findNums.size(); ++i) {
//		res[i] = -1;
//		int start = m[findNums[i]];
//		for (int j = start + 1; j < nums.size(); ++j) {
//			if (nums[j] > findNums[i]) {
//				res[i] = nums[j];
//				break;
//			}
//		}
//	}
//	return res;
//}
////my
//vector<int> nextGreaterElement(vector<int>& findNums, vector<int>& nums) {
//	unordered_map<int,int> mm;
//	for (int i = 0; i<nums.size(); i++)
//		mm[nums[i]] = i;
//	vector<int> ans(findNums.size());
//	for (int i = 0; i<findNums.size(); i++) {
//		int start = mm[findNums[i]];
//		ans[i] = -1;
//		for (int j = start; j<findNums.size(); j++) {
//			if (nums[j]>findNums[i]) {
//				ans[i] = nums[j];
//				break;
//			}
//
//		}
//	}
//	return ans;
//}
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	string ss = "2-4A0r7-4k";
//	auto ans = repeatedStringMatch(ss,4);
//
//
//	getchar();
//	return 0;
//}