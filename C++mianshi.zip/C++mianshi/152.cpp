//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//
//int maxProduct(vector<int>& nums) {
//	if (nums.empty()) return 0;
//	int res = nums[0], mn = nums[0], mx = nums[0];
//	for (int i = 1; i < nums.size(); ++i) {
//		int tmax = mx, tmin = mn;
//		mx = max(max(nums[i], tmax * nums[i]), tmin * nums[i]);
//		mn = min(min(nums[i], tmax * nums[i]), tmin * nums[i]);
//		/*mx = max(nums[i], max(mx*nums[i], mn*nums[i]));
//		mn = min(nums[i], min(mx*nums[i], mn*nums[i]));*/
//		res = max(res, mx);
//	}
//	return res;
//}
//
//int main()
//{
//	vector<int> aa = { 2,3,-2,-4 };
//	int ans= maxProduct(aa);
//
//
//	getchar();
//	return 0;
//}