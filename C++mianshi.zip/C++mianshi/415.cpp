//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//#include <unordered_set>
//#include <map>
////string to int
//
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//string addStrings(string num1, string num2) {
//	string res = "";
//	int m = num1.size(), n = num2.size(), i = m - 1, j = n - 1, carry = 0;
//	while (i >= 0 || j >= 0) {
//		int a = i >= 0 ? num1[i--] - '0' : 0;
//		int b = j >= 0 ? num2[j--] - '0' : 0;
//		int sum = a + b + carry;
//		res.insert(res.begin(), sum % 10 + '0');
//		carry = sum / 10;
//	}
//	return carry ? "1" + res : res;//smart***********
//}
//
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	auto ans = repeatedStringMatch(ss,4);
//
//	getchar();
//	return 0;
//}