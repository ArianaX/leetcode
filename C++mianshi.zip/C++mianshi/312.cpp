//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
////Definition for singly - linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//int dpdp(vector<int>& nums, vector<vector<int>>& dp, int l, int r) {
//	if (l>r)
//		return 0;
//	if (dp[l][r]>0)
//		return dp[l][r];
//	int res = 0;
//	for (int i = l; i <= r; i++) {
//		res = max(res, nums[l - 1] * nums[i] * nums[r + 1] + dpdp(nums, dp, l, i - 1) + dpdp(nums, dp, i + 1, r));
//	}        
//	dp[l][r] = res;
//
//	return res;
//}
//int maxCoins(vector<int>& nums) {
//	int n = nums.size();
//	nums.insert(nums.begin(), 1);
//	nums.push_back(1);
//
//	vector<vector<int>> dp(n + 2, vector<int>(n + 2, 0));
//	return dpdp(nums, dp, 1, n);
//}
//
//
//int main()
//{
//	vector<int> aa = {3,1,5,8};
//	int ans= maxCoins(aa);
//	
//
//	getchar();
//	return 0;
//}