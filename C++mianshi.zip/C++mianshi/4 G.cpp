//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//
//
//double findMedianSortedArrays(vector<int>& nums1, vector<int>& nums2) {
//	int m = nums1.size();
//	int n = nums2.size();
//	if (m > n)
//		return findMedianSortedArrays(nums2, nums1);
//	if (m == 0 && n == 0)
//		return 0;
//	if (m == 0)
//		return (nums2[(n-1) / 2 ]+nums2[n/2])/2.0;
//
//
//	int cnt = m + n;
//	int cut1 = m/2;
//	int cut2;
//
//	int cutl = 0, cutr = m;
//	while (cut1 <= m) {
//		cut1 = (cutr - cutl) / 2 + cutl;
//		cut2 = cnt / 2 - cut1;
//		int l1 = (cut1==0)? INT_MIN:nums1[cut1 - 1];
//		int l2 = (cut2 == 0) ? INT_MIN : nums2[cut2 - 1];
//		int r1 = (cut1==m)? INT_MAX:nums1[cut1];
//		int r2 = (cut2==n)? INT_MAX:nums2[cut2];
//		if (l1 > r2)//zuozuozuo
//			cutr=cut1-1;
//		else if (l2 > r1)//youyouyou
//			cutl=cut1+1;
//		else {
//			if (cnt % 2 == 1)
//				return min(r1, r2);
//			else
//				return (max(l1, l2) + min(r1, r2)) / 2.0;
//		}
//	}
//	return -1;
//}
//int main()
//{
//	vector<int> num1 = {1,2 };
//	vector<int> num2 = { 22,44,66,88,99};
//	auto ans = findMedianSortedArrays(num1,num2);
//
//
//	getchar();
//	return 0;
//}