//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//#include <unordered_set>
//#include <map>
////* Definition for a binary tree node.
//struct TreeNode {
//	int val;
//	TreeNode *left;
//	TreeNode *right;
//	TreeNode(int x) : val(x), left(NULL), right(NULL) {}
//};
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
////vector<int> plusOne(vector<int> &digits) {
////	int n = digits.size();
////	for (int i = n - 1; i >= 0; --i) {
////		if (digits[i] == 9) digits[i] = 0;
////		else {
////			digits[i] += 1;
////			return digits;
////		}
////	}
////	if (digits.front() == 0) 
////		digits.insert(digits.begin(), 1);
////	return digits;
////}
////my
//vector<int> plusOne(vector<int>& digits) {
//	for (int i = digits.size() - 1; i >= 0; i--) {
//		if (digits[i] == 9) 
//			digits[i] = 0;
//		else {
//			digits[i] += 1;
//			return digits;
//		}
//	}
//	if (digits.front() == 0 )
//		digits.insert(digits.begin(), 1);
//	return digits;
//}
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	//auto ans = repeatedStringMatch(ss,4);
//
//	getchar();
//	return 0;
//}