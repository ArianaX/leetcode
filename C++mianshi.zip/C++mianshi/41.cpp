//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//int firstMissingPositive(vector<int>& nums) {
//	int n = nums.size();
//	for (int i = 0; i < n; ++i) {
//		while (nums[i] > 0 && nums[i] <= n && nums[nums[i] - 1] != nums[i]) {
//			swap(nums[i], nums[nums[i] - 1]);
//		}
//	}
//	for (int i = 0; i < n; ++i) {
//		if (nums[i] != i + 1) 
//			return i + 1;
//	}
//	return n + 1;
//}
////my
//int firstMissingPositive(vector<int>& nums) {
//	int n = nums.size();
//	for (int i = 0; i<n; i++) {
//		while (nums[i]>0 && nums[i] <= n && nums[nums[i] - 1] != nums[i]) {
//			swap(nums[i], nums[nums[i] - 1]);
//		}
//	}
//	for (int i = 0; i<n; i++) {
//		if (nums[i] != i + 1)
//			return i + 1;
//	}
//	return n+1;//forget plus one
//}
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	string ss = "2-4A0r7-4k";
//	auto ans = firstMissingPositive(aa);
//
//
//	getchar();
//	return 0;
//}
//
