//#include<iostream>
//#include<vector>
//#include<string>
//#include<sstream>
//#include<algorithm>
//
//using namespace std;
////* Definition for a binary tree node.
//struct TreeNode {
//	int val;
//	TreeNode *left;
//	TreeNode *right;
//	TreeNode(int x) : val(x), left(NULL), right(NULL) {}
//};
//TreeNode* createT(vector<int>& nums) {
//	if (nums.size() == 0)
//		return nullptr;
//	TreeNode* ans = new TreeNode(nums[0]);
//	auto cur = ans;
//	for (int i = 1; i < nums.size(); i++) {
//		cur->left = new TreeNode(nums[i]);
//		cur = cur->left;
//	}
//	return ans;
//}
//
//
//
//int helper(TreeNode* node, int parent) {
//	if (!node || node->val != parent) 
//		return 0;
//	return 1 + max(helper(node->left, node->val), helper(node->right, node->val));
//}
//int longestUnivaluePath(TreeNode* root) {
//	if (!root) 
//		return 0;
//	int sub = max(longestUnivaluePath(root->left), longestUnivaluePath(root->right));
//	return max(sub, helper(root->left, root->val) + helper(root->right, root->val));
//}
//
////my
//int helper(TreeNode* root, int val) {
//	if (!root || root->val != val)
//		return 0;
//	return 1 + max(helper(root->left, root->val), helper(root->right, root->val));
//}
//int longestUnivaluePath(TreeNode* root) {
//	if (!root)
//		return 0;
//	int ans = max(longestUnivaluePath(root->left), longestUnivaluePath(root->right));
//	return max(ans, helper(root->left, root->val) + helper(root->right, root->val));
//
//}
//
//
//int main() {
//	vector<int> ttt = { 5,3,2,1,4,6 };
//	vector<int >qqq = { 1,2,3,4,5,6 };
//	auto aaa = buildTree(ttt, qqq);
//	auto c = kthSmallest2(aaa, 3);
//
//
//	getchar();
//	return 0;
//}