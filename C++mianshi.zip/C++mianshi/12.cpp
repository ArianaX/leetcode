//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//#include <unordered_set>
//#include <map>
////* Definition for a binary tree node.
//struct TreeNode {
//	int val;
//	TreeNode *left;
//	TreeNode *right;
//	TreeNode(int x) : val(x), left(NULL), right(NULL) {}
//};
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//string intToRoman(int num) {
//	char roman[] = { 'M', 'D', 'C', 'L', 'X', 'V', 'I' };
//	int value[] = { 1000, 500, 100, 50, 10, 5, 1 };
//	string ans = "";
//	for (int i = 0; i < 7; i = i + 2) {
//		int temp = num / value[i];
//		if (temp < 4) {
//			for (int j = 1; j <= temp; j++)
//				ans = ans + roman[i];
//		}
//		else if (temp == 4) {
//			ans = ans + roman[i] + roman[i - 1];
//		}
//		else if (temp > 4 && temp < 9) {
//			ans = ans + roman[i - 1];
//			for (int j = 1; j <= temp - 5; j++)
//				ans += roman[i];
//		}
//		else if (temp == 9) {
//			ans = ans + roman[i] + roman[i - 2];
//		}
//		num = num % value[i];
//	}
//	return ans;
//}
//
//
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	auto ans = repeatedStringMatch(ss, 4);
//	//vector<vector<int>> ans(23, vector<int>());
//
//	getchar();
//	return 0;
//}