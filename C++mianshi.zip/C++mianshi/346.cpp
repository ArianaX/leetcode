//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//#include <unordered_set>
//#include <map>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//
//class MovingAverage {
//private:
//	int size_ = 0;
//	queue<int> q;
//	double sum = 0;
//public:
//	/** Initialize your data structure here. */
//	MovingAverage(int size) {
//		size_ = size;
//		sum = 0;
//	}
//
//	double next(int val) {
//		if (q.size()<size_) {
//			q.push(val);
//
//		}
//		else if (q.size() == size_) {
//			sum = sum - q.front();
//			q.pop();
//			q.push(val);
//		}
//		sum += val;
//		return sum / (q.size() + 0.0);
//	}
//};
//
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	auto ans = repeatedStringMatch(ss,4);
//
//	getchar();
//	return 0;
//}
//
