//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
////my
//int read4(char *buf) {
//	return 23;
//}
//int read(char *buf, int n) {
//	if (n == 0)
//		return 0;
//	int read = 0;
//	char buf4[4];
//	while (true) {
//		int cur = read4(buf4);
//		for (int i = 0; read < n&&i < cur; i++)
//			buf[read++] = buf4[i];
//		if (read >= n || cur < 4)
//			break;
//	}
//	return read;
//}
//
//
//int main()
//{
//	int ans[2];
//	ans[1] = 34;
//
//	vector<int> aa = { 100,4,200,1,3,2 };
//	string ss = "2-4A0r7-4k";
//	auto ans = repeatedStringMatch(ss,4);
//
//
//	getchar();
//	return 0;
//}