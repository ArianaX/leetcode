//#include<iostream>
//using namespace std;
//double PowerLX(double base, int exponent)
//{
//	if (exponent==0)
//	{
//		return 1;
//	}
//	if (exponent==1)
//	{
//		return base;
//	}
//
//	double result=PowerLX(base,exponent>>1);
//	result = result*result;
//	if (exponent&0x1==1)
//	{
//		result = result*base;
//	}
//	return result;
//}
//int main()
//{
//	double q=PowerLX(3,5);
//	//int a = -10;
//	cout << q;
//	system("pause");
//}