////297
//class Codec {
//public:
//	// Encodes a tree to a single string.
//	string serialize(TreeNode* root) {
//		ostringstream out;
//		serialize(root, out);
//		return out.str();
//	}
//	// Decodes your encoded data to tree.
//	TreeNode* deserialize(string data) {
//		istringstream in(data);
//		return deserialize(in);
//	}
//private:
//	void serialize(TreeNode *root, ostringstream &out) {
//		if (root) {
//			out << root->val << ' ';
//			serialize(root->left, out);
//			serialize(root->right, out);
//		}
//		else {
//			out << "# ";
//		}
//	}
//	TreeNode* deserialize(istringstream &in) {
//		string val;
//		in >> val;
//		if (val == "#")
//			return nullptr;
//		TreeNode *root = new TreeNode(stoi(val));
//		root->left = deserialize(in);
//		root->right = deserialize(in);
//		return root;
//	}
//};
////my
//void toString(TreeNode* root, string& ans) {
//	if (root == nullptr) {
//		ans.push_back('^');
//		return;
//	}
//	ans.push_back(root->val);
//	toString(root->left, ans);
//	toString(root->right, ans);
//}
//
//// Encodes a tree to a single string.
//string serialize(TreeNode* root) {
//	string ans = "";
//	toString(root, ans);
//	return ans;
//
//}
//
//TreeNode* des(istringstream& in) {
//	string tt;
//	in >> tt;
//	if (tt == "^")
//		return nullptr;
//	TreeNode* ans = new TreeNode(stoi(tt));
//	ans->left = des(in);
//	ans->right = des(in);
//	return ans;
//}
//
//// Decodes your encoded data to tree.
//TreeNode* deserialize(string data) {
//	istringstream in(data);
//	return des(in);
//
//}