//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//int main()
//{
//	vector <pair <int, int>> people = { {7,0},{4, 4},{7, 1},{5, 0},{6, 1},{5, 2} };//{ ()7, 0> };
//	sort(people.begin(), people.end(), [](const pair<int, int> &a, const pair<int, int> &b) {
//		return a.first>b.first || (a.first == b.first&& a.second<b.second);
//	});
//
//	int ans, next;
//	if (people.size()>1)
//		ans = people[1].second;
//	for (int i = 1; i<people.size(); i++) {
//		if (i != people.size() - 1)
//			next = people[i + 1].second;
//		int temp = 0;
//		for (int j = 0; j<i; j++) {
//			temp++;
//			if (temp == ans) {
//				auto aa = people[i];
//				for (int k = i - 1; k>j; k--)
//					people[k + 1] = people[k];
//				people[j + 1] = aa;
//				break;
//			}
//			if (temp>ans) {
//				auto aa = people[i];
//				for (int k = i - 1; k >= 0; k--)
//					people[k + 1] = people[k];
//				people[0] = aa;
//				break;
//			}
//
//		}
//		ans = next;
//	}
//
//}