//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//#include <unordered_set>
//#include <map>
////LLLLLLLLLLLLLLLLLate
////ֵ���⣨value semantics�����������⣨reference semantics��
////* Definition for a binary tree node.
//struct TreeNode {
//	int val;
//	TreeNode *left;
//	TreeNode *right;
//	TreeNode(int x) : val(x), left(NULL), right(NULL) {}
//};
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//
//struct RandomListNode {
//	int label;
//	RandomListNode *next, *random;
//	RandomListNode(int x) : label(x), next(NULL), random(NULL) {}
//	
//};
//RandomListNode *copyRandomList(RandomListNode *head) {
//	if (!head) 
//		return NULL;
//	RandomListNode *res = new RandomListNode(head->label);
//	RandomListNode *node = res;
//	RandomListNode *cur = head->next;
//	map<RandomListNode*, RandomListNode*> m;
//	m[head] = res;
//	while (cur) {
//		RandomListNode *tmp = new RandomListNode(cur->label);
//		node->next = tmp;
//		m[cur] = tmp;
//		node = node->next;
//		cur = cur->next;
//	}
//	node = res;
//	cur = head;
//	while (node) {
//		node->random = m[cur->random];
//		node = node->next;
//		cur = cur->next;
//	}
//	return res;
//}
//
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	auto ans = repeatedStringMatch(ss,4);
//
//	getchar();
//	return 0;
//}