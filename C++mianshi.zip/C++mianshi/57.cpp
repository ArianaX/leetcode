//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
////Definition for an interval.
//struct Interval {
//int start;
//int end;
//Interval() : start(0), end(0) {}
//Interval(int s, int e) : start(s), end(e) {}
//
//};
//vector<Interval> insert(vector<Interval>& intervals, Interval newInterval) {
//	vector<Interval> res;
//	int n = intervals.size(), cur = 0;
//	for (int i = 0; i < n; ++i) {
//		if (intervals[i].end < newInterval.start) {
//			res.push_back(intervals[i]);
//			++cur;
//		}
//		else if (intervals[i].start > newInterval.end) {
//			res.push_back(intervals[i]);
//		}
//		else {
//			newInterval.start = min(newInterval.start, intervals[i].start);
//			newInterval.end = max(newInterval.end, intervals[i].end);
//		}
//	}
//	res.insert(res.begin() + cur, newInterval);
//	return res;
//}
//vector<Interval> insert2(vector<Interval>& intervals, Interval newInterval) {
//	vector<Interval> ans;
//	int n = intervals.size();
//	int cur = 0;
//	for (int i = 0; i<n; i++) {
//		if (intervals[i].end<newInterval.start) {
//			cur++;
//			ans.push_back(intervals[i]);
//		}
//		else if (intervals[i].start>newInterval.end) {
//			ans.push_back(intervals[i]);
//		}
//		else {
//			newInterval.start = min(newInterval.start, intervals[i].start);
//			newInterval.end = max(newInterval.end, intervals[i].end);
//		}
//	}
//	ans.insert(ans.begin() + cur, newInterval);
//	return ans;
//}
//int main()
//{
//	Interval(1, 2);
//	vector<Interval> ss = { Interval(1, 2),Interval(3, 5),Interval(6, 7),Interval(8, 10),Interval(12, 16)};
//	auto ans = insert2(ss, Interval(4, 8));
//
//
//	getchar();
//	return 0;
//}