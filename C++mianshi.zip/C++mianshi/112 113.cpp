
//
////113 path sum����·��
////my
//void dfs(TreeNode* root, int sum, vector<int>& temp, vector<vector<int>> & ans) {
//	if (root == nullptr)
//		return;
//	temp.push_back(root->val);
//	if (root->val == sum && root->left == nullptr&&root->right == nullptr)
//		ans.push_back(temp);
//	dfs(root->left, sum - root->val, temp, ans);
//	dfs(root->right, sum - root->val, temp, ans);
//	temp.pop_back();//*********************
//
//}
//vector<vector<int>> pathSum(TreeNode* root, int sum) {
//	vector<vector<int>> ans;
//	if (root == nullptr)
//		return{};
//	vector<int> temp;
//	dfs(root, sum, temp, ans);
//	return ans;
//}
//112
////my
//void dfs(TreeNode* root, int sum, bool& ans) {
//	if (root == nullptr)
//		return;
//	if (root->val == sum && root->left== nullptr&&root->right == nullptr)
//		ans = true;
//	dfs(root->left, sum - root->val, ans);
//	dfs(root->right, sum - root->val, ans);
//}
//bool hasPathSum(TreeNode* root, int sum) {
//	bool ans = false;
//	dfs(root, sum, ans);
//	return ans == true;
//}