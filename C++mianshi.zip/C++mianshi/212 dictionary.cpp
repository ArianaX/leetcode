//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//
////my 10/17/2018
//struct TrieNode {
//	vector<TrieNode*> child = vector<TrieNode*>(26, nullptr);//you cannot initialize here: (26, nullptr);****************
//	string name="";
//};
//struct Trie {
//	TrieNode* root=new TrieNode();//***************
//	void insert(string a) {
//		auto p = root;
//		for (auto aa : a) {
//			if (p->child[aa - 'a'] == nullptr)
//				p->child[aa - 'a'] = new TrieNode();
//			p = p->child[aa - 'a'];
//		}
//		p->name = a;
//	}
//};
//
//void helper(vector<vector<char>>&board, vector<vector<bool>>visit, TrieNode* p, int i, int j, vector<string> &ans) {
//	if (!p->name.empty()) {
//		ans.push_back(p->name);
//		p->name.clear();
//		return;
//	}
//	int m = board.size(), n = board[0].size();
//	if (i >= 0 && j >= 0 && i<m&&j<n && !visit[i][j] && p->child[board[i][j] - 'a']) {
//		visit[i][j] = true;
//		helper(board, visit, p->child[board[i][j] - 'a'], i + 1, j, ans);
//		helper(board, visit, p->child[board[i][j] - 'a'], i - 1, j, ans);
//		helper(board, visit, p->child[board[i][j] - 'a'], i, j + 1, ans);
//		helper(board, visit, p->child[board[i][j] - 'a'], i, j - 1, ans);
//
//		visit[i][j] = false;
//	}
//}
//vector<string> findWords(vector<vector<char>>& board, vector<string>& words) {
//	vector<string> ans;
//	if (words.empty() || board.empty() || board[0].empty())
//		return {  };
//	Trie dic;
//	for (auto a : words)
//		dic.insert(a);
//
//	int m = board.size(), n = board[0].size();
//	TrieNode* p = dic.root;
//	vector<vector<bool>> visit(m, vector<bool>(n, false));
//	for (int i = 0; i<m; i++) {
//		for (int j = 0; j<n; j++)
//			helper(board, visit, p, i, j, ans);
//	}
//	return ans;
//}
////
//////10/12/2018 normal way
////// this is slow and cannot go through the oj
////void search(vector<vector<char> > &board, string w, int i, int j,int idx, vector<vector<bool> > &visit, vector<string> &ans) {
////	if (idx == w.size()-1&& w[idx] == board[i][j]) {
////		ans.push_back(w);
////		return;
////	}
////
////	int m = board.size(), n = board[0].size();
////	if (i >= 0 && j >= 0 && i < m && j < n && !visit[i][j] && w[idx] == board[i][j]) {
////		visit[i][j] = true;
////		idx++;
////		search(board, w, i - 1, j,idx, visit, ans);
////		search(board, w, i + 1, j, idx , visit, ans);
////		search(board,w, i, j - 1,idx, visit, ans);
////		search(board, w, i, j + 1, idx, visit, ans);
////		visit[i][j] = false;
////
////	}
////}
////vector<string> findWords(vector<vector<char>>& board, vector<string>& words) {
////	vector<string> ans;
////	if (words.empty() || board.empty() || board[0].empty())
////		return ans;
////	vector<vector<bool> > visit(board.size(), vector<bool>(board[0].size(), false));
////	
////	int m = board.size(), n = board[0].size();
////	for (auto w : words) {
////		for (int i = 0; i<m; i++) {
////			for (int j = 0; j<n; j++) {
////				//if (w[idx]==board[i][j])
////					search(board, w, i, j,0, visit, ans);
////			}
////		}
////	}
////	
////	return ans;
////}
//
//int main()
//{
//
//
//	vector<string> words = { "oath","pea","eat","rain" };
//	vector<vector<char>> board = { {'o','a','a','n'},
//									{'e','t','a','e'},
//									{'i','h','k','r' },
//									{'i', 'f', 'l', 'v'} };
//	vector<string> aa = findWords(board, words);
//
//	getchar();
//	return 0;
//}