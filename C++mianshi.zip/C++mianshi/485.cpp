//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//int findMaxConsecutiveOnes(vector<int>& nums) {
//	int res = 0, cnt = 0;
//	for (int num : nums) {
//		cnt = (num == 0) ? 0 : cnt + 1;
//		res = max(res, cnt);
//	}
//	return res;
//}
//
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	string ss = "2-4A0r7-4k";
//	auto ans = repeatedStringMatch(ss,4);
//
//
//	getchar();
//	return 0;
//}