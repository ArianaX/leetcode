//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//
//class LRUCache {
//public:
//	LRUCache(int capacity) :size(capacity) {}
//
//	int get(int key) {
//		auto it = hash.find(key);
//		if (it == hash.end()) return -1;
//		cache.splice(cache.begin(), cache, it->second);
//		return it->second->second;
//	}
//
//	void put(int key, int value) {
//		auto it = hash.find(key);
//		if (it != hash.end())//has
//		{
//			it->second->second = value;
//			return cache.splice(cache.begin(), cache, it->second);
//		}
//		cache.insert(cache.begin(), make_pair(key, value));
//		hash[key] = cache.begin();
//		if (cache.size() > size)
//		{
//			hash.erase(cache.back().first);
//			cache.pop_back();
//		}
//	}
//private:
//	unordered_map<int, list<pair<int, int>>::iterator> hash;
//	list<pair<int, int>> cache;
//	int size;
//};
//
////my
//class LRUCache {
//private:
//	unordered_map<int, list<pair<int, int>>::iterator> mm;
//	int cap = 0;
//	list<pair<int, int>> cache;
//public:
//	LRUCache(int capacity) {
//		cap = capacity;
//	}
//
//	int get(int key) {
//		auto it = mm.find(key);
//		if (it == mm.end()) {//no
//			return -1;
//		}
//		cache.splice(cache.begin(), cache, it->second);
//		return it->second->second;
//	}
//
//	void put(int key, int value) {
//		auto it = mm.find(key);
//		if (it != mm.end()) {//has
//			it->second->second = value;
//			//
//			cache.splice(cache.begin(), cache, it->second);
//			return;
//		}
//		cache.push_back(make_pair(key, value));
//		cache.splice(cache.begin(), cache, it->second);
//		mm[key] = cache.begin();
//		if (mm.size()>cap) {
//			mm.erase(cache.back().first);
//			cache.pop_back();
//		}
//
//	}
//};
//
//int main()
//{
//	LRUCache aa(2);
//
//	aa.get(1);
//
//	aa.put(1,111);       // returns -1 (not found)
//	aa.put(2,222);    // evicts key 1
//	aa.put(1,333);       // returns -1 (not found)
//	aa.get(1);       // returns 3
//	aa.get(2);       // returns 4
//	aa.put(3, 333);
//
//
//
//
//	getchar();
//	return 0;
//}