//#include<iostream>
//using namespace std;
//class MyString
//{
//public:
//	MyString() {};
//	MyString(char * str) 
//	{
//		m_pData = str;
//	};
//	MyString (const MyString &str) {};
//	MyString& MyString::operator =(const MyString &str)
//	{
//
//		if (this==&str)
//		{
//			return *this;
//		}
//		/*delete []m_pData;
//		m_pData = NULL;
//		
//		m_pData = new char[strlen(str.m_pData)+1];
//		strcpy_s(m_pData, strlen(str.m_pData) + 1,str.m_pData);*/
//		MyString Q(str);
//		char* data = Q.m_pData;
//		Q.m_pData = m_pData;
//		m_pData = data;
//		return *this;
//	}
//private:
//	char* m_pData;
//
//};
//int main()
//{
//	MyString st1, st2, st3;
//	
//	st1 = "qwef";
//	st2 = st1;
//	st1 = st2 = st3;
//	system("pause");
//
//}
//
//
