//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//
//int kthSmallest2(vector<vector<int>>& matrix, int k) {
//	priority_queue<int> q;
//	for (int i = 0; i < matrix.size(); ++i) {
//		for (int j = 0; j < matrix[i].size(); ++j) {
//			q.emplace(matrix[i][j]);
//			if (q.size() > k) 
//				q.pop();
//		}
//	}
//	return q.top();
//}
//int kthSmallest(vector<vector<int>>& matrix, int k) {
//	int left = matrix[0][0], right = matrix.back().back();
//	while (left < right) {
//		int mid = left + (right - left) / 2, cnt = 0;
//		for (int i = 0; i < matrix.size(); ++i) {
//			cnt += upper_bound(matrix[i].begin(), matrix[i].end(), mid) - matrix[i].begin();
//		}
//		if (cnt < k) 
//			left = mid + 1;
//		else 
//			right = mid;
//	}
//	return left;
//}
//
//
//
//int main()
//{
//	vector<vector<int>> aa = {  {1,5,8},
//								{7,11,13},
//								{10,13,15} };
//	auto ans = kthSmallest(aa,5);
//
//
//	getchar();
//	return 0;
//}