//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//bool isOneEditDistance(string s, string t) {
//	for (int i = 0; i < min(s.size(), t.size()); ++i) {
//		if (s[i] != t[i]) {
//			if (s.size() == t.size()) 
//				return s.substr(i + 1) == t.substr(i + 1);
//			else if (s.size() < t.size()) 
//				return s.substr(i) == t.substr(i + 1);
//			else 
//				return s.substr(i + 1) == t.substr(i);
//		}
//	}
//	return abs((int)s.size() - (int)t.size()) == 1;
//}
////my
//bool isOneEditDistance(string s, string t) {
//	for (int i = 0; i<min(s.size(), t.size()); i++) {
//		if (s[i] != t[i]) {
//			if (s.size() == t.size())
//				return s.substr(i + 1) == t.substr(i + 1);
//			if (s.size()<t.size())
//				return s.substr(i) == t.substr(i + 1);
//			else
//				return t.substr(i) == s.substr(i + 1);
//		}
//	}
//	return abs((int)s.size() - (int)t.size()) == 1;
//}
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	string ss = "2-4A0r7-4k";
//	auto ans = repeatedStringMatch(ss,4);
//
//
//	getchar();
//	return 0;
//}