//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//
//string longestPalindrome(string s) {//�ֳ�ż��������
//	int s_len = s.length();
//	int max_start = 0;
//	int max_size = 1;
//	for (int i = 0; i < s_len; i++) {
//		int lower = i;
//		int upper = i + 1;
//		while (lower >= 0 && upper < s_len && s[lower] == s[upper]) {
//			lower--;
//			upper++;
//		}
//		if (upper - lower - 1 > max_size) {// ��ʱ u l ���ǲ��������Ǹ�index
//			max_start = lower + 1;
//			max_size = upper - lower - 1;
//		}
//
//		lower = i - 1;//bab ��b��ʼ
//		upper = i + 1;
//		while (lower >= 0 && upper < s_len && s[lower] == s[upper]) {
//			lower--;
//			upper++;
//		}
//		if (upper - lower - 1 > max_size) {
//			max_start = lower + 1;
//			max_size = upper - lower - 1;
//		}
//	}
//
//	return s.substr(max_start, max_size);
//}
////my
//string longestPalindrome(string s) {
//	int n = s.size();
//	int max_start = 0;
//	int max_size = 1;
//	for (int i = 0; i<n; i++) {
//		int lower = i;
//		int upper = i + 1;
//		while (lower >= 0 && upper<n&&s[lower] == s[upper]) {
//			lower--;
//			upper++;
//		}
//		if (upper - lower - 1>max_size) {
//			max_start = lower + 1;
//			max_size = upper - lower - 1;
//		}
//		lower = i - 1;
//		upper = i + 1;
//		while (lower >= 0 && upper<n&&s[lower] == s[upper]) {
//			lower--;
//			upper++;
//		}
//		if (upper - lower - 1>max_size) {
//			max_start = lower + 1;
//			max_size = upper - lower - 1;
//		}
//	}
//	return s.substr(max_start, max_size);
//}
//int main()
//{
//	string ss = "babad";
//	auto ans = longestPalindrome(ss);
//
//
//	getchar();
//	return 0;
//}