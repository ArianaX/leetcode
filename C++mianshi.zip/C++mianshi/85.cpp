//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include <stack>
//int maximalRectangle(vector<vector<char>>& matrix) {
//	if (matrix.empty() || matrix[0].empty()) 
//		return 0;
//	int res = 0, m = matrix.size(), n = matrix[0].size();
//	vector<int> height(n + 1, 0);
//	for (int i = 0; i < m; ++i) {
//		stack<int> s;
//		for (int j = 0; j < n + 1; ++j) {
//			if (j < n) {
//				height[j] = matrix[i][j] == '1' ? height[j] + 1 : 0;
//			}
//			while (!s.empty() && height[s.top()] >= height[j]) {
//				int cur = s.top(); 
//				s.pop();
//				res = max(res, height[cur] * (s.empty() ? j : (j - s.top() - 1)));
//			}
//			s.push(j);
//		}
//	}
//	return res;
//}
//int maximalRectangle2(vector<vector<char>>& matrix) {
//	int ans = 0;
//	int m = matrix.size();
//	int n = matrix[0].size();
//	vector<int> heights(n + 1, 0);
//	for (int i = 0; i<m; i++) {
//		vector<int> s;
//		for (int j = 0; j <= n; j++) {
//			if (j<n)
//				heights[j] = matrix[i][j] == '1' ? heights[j] + 1 : 0;
//			while (!s.empty() && heights[s.back()] >= heights[j]) {
//				int cur = s.back();
//				s.pop_back();
//				ans = max(ans, heights[cur] * (s.empty() ? j : (j - s.back() - 1)));
//			}
//			s.push_back(j);
//		}
//	}
//	return ans;
//}
//
//
//int main()
//{
//	vector<vector<char>> aa = { { '1','0','1','0','0' },
//								{ '0','0','1','0','0' },
//								{ '0','0','1','0','0' },
//								{ '0','0','0','1','1' } };
//	int ans = maximalRectangle2(aa);
//
//
//
//	getchar();
//	return 0;
//}