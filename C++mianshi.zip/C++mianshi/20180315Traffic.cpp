///////////////////////////////////////////////////////////////////////
//// Traffic.cpp - Implements T - Intersection                       //
//// ver 1.0                                                         //
//// Ariana Li, March 15th 2018                                      //
///////////////////////////////////////////////////////////////////////
//
////Write either C++ or C# code for a controller for a stop light at a T - Intersection 
////according to the following rules.The straight part of the intersection runs East - West 
////and receives the heaviest traffic and should be green most often.The intersecting road 
////runs North and only receives light traffic and therefore contains a single sensor to 
////inform the light of the presence of a car.If the sensor is activated for more than 10 
////seconds the light for the East / Westbound commuters should turn yellow for 3 seconds, 
////then red. 2 seconds later the light for Northbound commuters should turn green.If the
////sensor goes inactive for more than 5 seconds the light will then cycle back to be green
////for East / West bound commuters.Additionally, the Northbound light will never be green
////for longer than 40 seconds and the East / Westbound lights will never be green for less
////than 30s.Your controller should contain an UpdateController() function that will be called
////once per second.Please comment your code to explain any additional assumptions made.
////Please upload your solution as a file.
//#include<iostream>
//#include <thread>         // std::this_thread::sleep_for
//#include <chrono>         // std::chrono::seconds
//#include <iomanip>
//
////This class to manage the traffic light.
////G: green light
////Y: yellow light
////R: red light
//
////both N and W-E road have the traffic light
//class TrafficLight
//{
//public:
//	TrafficLight() { light_ = NULL; };
//	~TrafficLight() {  };
//
//	void setLight(char a);
//	char getLight();
//	void setY(int a) { Y_ = a; G_ = 0; R_ = 0; light_ = 'Y'; }
//	void setR(int a) { Y_ = 0; G_ = 0; R_ = a; light_ = 'R';}
//	void setG(int a) { Y_ = 0; G_ = a; R_ = 0; light_ = 'G';}
//	int getTime() {
//		if (Y_ != 0) {return Y_;}
//		if (R_ != 0) { return R_; }
//		if (G_ != 0) { return G_; }
//	}
//private:
//	char light_;
//	int Y_=0;
//	int G_=0;
//	int R_=0;
//};
//void TrafficLight::setLight(char a)
//{
//	light_ = a;
//}
//char TrafficLight::getLight()
//{
//	return light_;
//}
//
////the sensor recrds the cars' number in the North road
//class sensor
//{
//public:
//	void setInactive(int s)
//	{
//		inactive_ = s;
//		active_ = 0;
//	}
//	void setActive(int s)
//	{
//		active_ = s;
//		inactive_ = 0;
//	}
//
//	int getInactive()
//	{
//		return inactive_;
//	}
//	int getActive()
//	{
//		return active_;
//	}
//private:
//	int inactive_=0;
//	int active_=0;
//};
//
////show functions
//void showHeader(std::ostream& out = std::cout)
//{
//	out << "\n  ";
//	out << std::setw(5) << std::left << "num";
//	out << std::setw(15) << std::left << "W-E road";
//	out << std::setw(10) << std::left << "North road";
//
//	out << "\n  ";
//	out << std::setw(5) << std::left << "-----";
//	out << std::setw(15) << std::left << "---------";
//	out << std::setw(10) << std::left << "------";
//}
//void showLight(int &i, TrafficLight &Nroad, TrafficLight &WEroad, std::ostream& out = std::cout)
//{
//	out << "\n  ";
//	out << std::setw(5) << std::left << i;
//	out << std::setw(15) << std::left << WEroad.getLight();
//	out << std::setw(10) << std::left << Nroad.getLight();
//}
//
////the function to control the T - Intersection 
//void turnNRed(TrafficLight &Nroad, TrafficLight& WEroad)
//{
//	Nroad.setLight('R');
//	Nroad.setR(1);
//	WEroad.setG(1);
//	WEroad.setLight('G');
//}
//void turnNGreen(TrafficLight &Nroad, TrafficLight &WEroad)
//{
//	Nroad.setLight('G');
//	Nroad.setG(1);
//	WEroad.setR(1);
//	WEroad.setLight('R');
//}
//void turnNYellow(TrafficLight &Nroad, TrafficLight &WEroad)
//{
//	Nroad.setLight('Y');
//	Nroad.setY(1);
//	WEroad.setR( WEroad.getTime()+ 1);
//	WEroad.setLight('R');
//}
//void WEYellow_NRed(TrafficLight &Nroad, TrafficLight &WEroad)
//{
//	WEroad.setY(1);
//	WEroad.setLight('Y');
//	Nroad.setLight('R');
//	Nroad.setR(Nroad.getTime() +1);
//}
//
////assume:  For North road, it only have red and Green light.
////when WE road is Y , North road is Red
////when WE road is R, North road is Green or Yellow
////when WE road is G, North road is Red
//void UpdateController (int i,TrafficLight &Nroad, TrafficLight &WEroad,sensor NSensor)
//{
//		if (Nroad.getLight() == 'R')
//		{
//			if (NSensor.getActive() > 10) {
//				if(WEroad.getLight()=='G')//if the first
//					WEYellow_NRed(Nroad, WEroad);
//				else if(WEroad.getTime()==3)
//					turnNGreen(Nroad, WEroad);
//				else
//					WEroad.setY(WEroad.getTime() + 1);
//
//			}
//			else
//			{
//				if (Nroad.getTime() >= 33)
//					turnNGreen(Nroad, WEroad);
//				else if (Nroad.getTime() >= 30)
//					WEYellow_NRed(Nroad, WEroad);
//				else
//					Nroad.setR(Nroad.getTime() + 1);
//			}
//						
//		}
//		else if (Nroad.getLight()=='Y')
//		{
//			if (Nroad.getTime() == 3) turnNRed(Nroad, WEroad);
//			else {
//				Nroad.setY(Nroad.getTime() + 1);
//			}
//		}
//		else//already Green
//		{
//			if (NSensor.getInactive() > 5)//N road will turn red
//			{
//				turnNYellow(Nroad, WEroad);
//			}
//			else if(Nroad.getTime()>40)   turnNYellow(Nroad, WEroad);
//			else 
//				Nroad.setG(Nroad.getTime() + 1);
//		}
//		showLight(i,Nroad,WEroad);
//		return;
//
//}
//
//
//int main()
//{
//	TrafficLight Nroad, WEroad;
//	int i = 1;
//	//set the default light:
//	turnNRed(Nroad, WEroad);
//	sensor NSensor;
//	std::cout << "Current light is";
//	showHeader();
//	showLight(i,Nroad, WEroad);
//	NSensor.setActive(11);
//
//	std::cout << "\n\n (1) in north road the sensor is active for 11 second (Program will stop after 50 seconds):";
//	std::cout << "\n\n Although, we need to wait the WE road to be green for at least 30s, because of the sensor, we need to keep this Green";
//	while (i <= 80)
//	{
//		i++;
//		UpdateController(i,Nroad, WEroad, NSensor);
//		std::this_thread::sleep_for(std::chrono::milliseconds(10));
//		
//	}
//	std::cout << "\n ********************************";
//	std::cout << "\n\n (2) in north road the sensor is inactive for 6 second (Program will stop after 50 seconds):";
//	std::cout << "\n\n Although, we need to wait the N road to be green, because of the sensor, we need to keep this Red";
//	NSensor.setInactive(6);
//	i = 1;
//	while (i <= 50)
//	{
//		i++;
//		UpdateController(i,Nroad, WEroad, NSensor);
//		std::this_thread::sleep_for(std::chrono::milliseconds(10));
//		
//	}
//
//	//sgetchar();
//	return 0;
//
//}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
