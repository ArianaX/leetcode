//#include<iostream>
//using namespace std;
//#include<vector>
//
//int combination(int top, int bottom) {
//	int sum = 1;
//	int temp = bottom;
//	for (int i = 0; i<top; i++) {
//		sum = sum * temp;
//		temp--;
//	}
//	int tt = top;
//	for (int i = 0; i<top; i++) {
//		sum = sum / tt;
//		tt--;
//	}
//	return sum;
//}
//
//int main()
//{
//	int qq = combination(2, 6);
//	getchar();
//	return 0;
//}