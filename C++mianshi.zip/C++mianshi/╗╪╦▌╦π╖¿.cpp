//#include<iostream>
//using namespace std;
//bool hasPathCore(char * input, int row, int col, int i, int j, char * str, int pathLength, bool* visit)
//{
//	//pathLength �Ѿ�������str���ַ�����
//	if (pathLength>= sizeof(str))//�Ѿ�
//	{
//		return true;
//	}
//	bool haspath = false;
//	if (i >= 0 && i < row&&j >= 0 && j < col&&input[i*col + j] == str[pathLength] && !visit[i*col + j])//input��һά����
//	{
//		pathLength++;
//		visit[i*col + j] = true;
//		haspath = hasPathCore(input, row, col, i - 1, j, str, pathLength, visit) ||
//			hasPathCore(input, row, col, i + 1, j, str, pathLength, visit) ||
//			hasPathCore(input, row, col, i, j - 1, str, pathLength, visit) ||
//			hasPathCore(input, row, col, i, j + 1, str, pathLength, visit);
//		if (!haspath)
//		{
//			pathLength--;
//			visit[i*col + j]=false;
//		}
//
//	}
//	return haspath;
//}
//
//bool hasPath(char* input, int row, int col, char* str)//strҪ�������ַ���
//{
//	if (input==NULL||str==NULL||row<1||col<1)
//	{
//		cout << "wrong input!!" << endl;
//		return false;
//	}
//	else
//	{
//		bool* visit = new bool[row*col]{0};//���Ե�
//		int pathLength = 0;
//		for (int i = 0; i < row; i++)
//		{
//			for (int j = 0; j < col; j++)
//			{
//				if (hasPathCore(input,row,col,i,j,str,pathLength,visit))
//				{
//					return true;
//				}
//			}
//		}
//		delete[] visit;
//	}
//}
//
////�����˵��˶���Χ���� threshold Լ��ֵ
//int getDigitSum(int integer)
//{
//	int sum = 0;
//	while (integer>0)
//	{
//		sum += integer % 10;
//		integer = integer / 10;
//	}
//	return sum;
//}
//bool check(int threshold, int rows, int cols, int i, int j, bool* visit)
//{
//	if (i >= 0 && i < rows&&j >= 0 && j < cols&&
//		getDigitSum(i) + getDigitSum(j) <= threshold &&
//		!visit[i*cols + j])
//	{
//		return true;
//	}
//	else
//	{
//		return false;
//	}
//}
//int movingCountCore(int threshold, int rows, int cols, int i, int j, bool* visit)
//{
//	int count = 0;
//	if (check(threshold,rows, cols,i,j,visit))
//	{
//		visit[i*cols + j] = true;
//		count = 1 + movingCountCore(threshold, rows, cols, i - 1, j, visit) +
//			movingCountCore(threshold, rows, cols, i + 1, j, visit) +
//			movingCountCore(threshold, rows, cols, i, j - 1, visit) +
//			movingCountCore(threshold, rows, cols, i, j + 1, visit);
//	}
//	return count;
//}
//int movingCount(int threshold, int rows, int cols)
//{
//	if (threshold <= 0 || rows <= 0 || cols <= 0)
//	{
//		return 0;
//	}
//	bool* visit = new bool[rows*cols]{ 0 };
//	int count = movingCountCore(threshold, rows, cols, 0, 0, visit);
//	delete[]visit;
//	return count;
//}
//
//int main()
//{
//	/*char input[16] = { 'a','b', 't', 'g',
//					'c', 'f', 'c', 's',
//					'j', 'd', 'e', 'h' };
//	char target[4] = { 'b', 'f', 'c', 'e' };
//	bool result=hasPath(input, 3, 4, target);
//	cout << result << endl;*/
//	
//	//������
//	int countResult = movingCount(18, 40, 40);
//	cout << countResult << endl;
//	system("pause");
//}