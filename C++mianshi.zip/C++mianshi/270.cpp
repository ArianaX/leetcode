////270
//int closestValue(TreeNode* root, double target) {
//	int res = root->val;
//	while (root) {
//		if (abs(res - target) >= abs(root->val - target)) {//abs(-12)
//			res = root->val;//renew the minimum
//		}
//		root = target < root->val ? root->left : root->right;
//	}
//	return res;
//}
////way2:
//int closestValue(TreeNode* root, double target) {
//	int a = root->val;
//	TreeNode *t = target < a ? root->left : root->right;
//	if (t==nullptr) 
//		return a;
//	int b = closestValue(t, target);
//	return abs(a - target) < abs(b - target) ? a : b;
//}