////684 union find
//int find(vector<int>& root, int i) {
//	while (root[i] != -1) {
//		i = root[i];
//	}
//	return i;
//}
//vector<int> findRedundantConnection(vector<vector<int>>& edges) {
//	if (edges.empty() || edges[0].empty())
//		return {};
//	vector<int> root(edges.size()*edges[0].size(), -1);
//	for (auto edge : edges) {
//		int x = find(root, edge[0]), y = find(root, edge[1]);
//		if (x == y) 
//			return edge;
//		root[x] = y;
//	}
//	return {};
//}
//my
//int find(vector<int> root, int i) {
//	while (root[i] != -1)
//		i = root[i];
//	return i;
//}
//vector<int> findRedundantConnection(vector<vector<int>>& edges) {
//	if (edges.empty() || edges[0].empty())
//		return {};
//	vector<int> root(edges.size()*edges[0].size(), -1);
//	for (auto a : edges) {
//		int x = find(root, a[0]), y = find(root, a[1]);
//		if (x == y)
//			return a;
//		root[x] = y;
//	}
//	return{};
//}