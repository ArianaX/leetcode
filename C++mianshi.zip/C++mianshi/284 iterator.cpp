//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//#include <unordered_set>
//#include <map>
//
//
////iterator��next��iterator����һ�� ������Ҫ��һ��flag�ж��Ƿ���Ҫ ����iterator��next 
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//// Below is the interface for Iterator, which is already defined for you.
//// **DO NOT** modify the interface for Iterator.
//template <class T>
//class Iterator {
//	struct Data;
//	Data* data;
//public:
//	Iterator(const vector<T>& nums);
//	Iterator(const Iterator<T>& iter); //???????????
//	virtual ~Iterator();
//	// Returns the next element in the iteration.
//	T next();
//	// Returns true if the iteration has more elements.
//	bool hasNext() const;
//};
////my
//template <class T>
//class PeekingIterator : public Iterator<T> {
//private:
//	bool flag_ = false;
//	T value_;
//public:
//	PeekingIterator(const vector<T>& nums) : Iterator<T>(nums) {
//		// Initialize any member here.
//		// **DO NOT** save a copy of nums and manipulate it directly.
//		// You should only use the Iterator interface methods.
//		flag_ = false;
//	}
//
//	// Returns the next element in the iteration without advancing the iterator.
//	int peek() {
//		if (flag_ == false)
//			value_ = Iterator<T>::next();
//		flag_ = true;
//		return value_;
//	}
//
//	// hasNext() and next() should behave the same as in the Iterator interface.
//	// Override them if needed.
//	T next() {
//		if (flag_ == false)
//			value_ = Iterator<T>::next();
//		flag_ = false;
//		return value_;
//	}
//
//	bool hasNext() const {
//		if (flag_ == false)
//			return Iterator<T>::hasNext();
//		return true;
//	}
//};
//
//
//
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	auto ans = repeatedStringMatch(ss,4);
//
//	getchar();
//	return 0;
//}