//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//bool isNumber(string s) {
//	bool num = false, numAfterE = true, dot = false, exp = false, sign = false;
//	int n = s.size();
//	for (int i = 0; i < n; ++i) {
//		if (s[i] == ' ') {
//			if (i < n - 1 && s[i + 1] != ' ' && (num || dot || exp || sign)) 
//				return false;
//		}
//		else if (s[i] == '+' || s[i] == '-') {
//			if (i > 0 && s[i - 1] != 'e' && s[i - 1] != ' ') 
//				return false;
//			sign = true;
//		}
//		else if (s[i] >= '0' && s[i] <= '9') {
//			num = true;
//			numAfterE = true;
//		}
//		else if (s[i] == '.') {
//			if (dot || exp) 
//				return false;
//			dot = true;
//		}
//		else if (s[i] == 'e') {
//			if (exp || !num) return false;
//			exp = true;
//			numAfterE = false;
//		}
//		else return false;
//	}
//	return num && numAfterE;
//}
////my
//bool isNumber(string s) {
//	bool num = false, numAfterE = false, dot = false, exp = false, sign = false;
//	for (int i = 0; i<s.size(); i++) {
//		if (s[i] == ' ') {
//			if (i<s.size() - 1 && s[i + 1] != ' ' && (num || numAfterE || dot || exp || sign))
//				return false;
//		}
//		else if (s[i] == '+' || s[i] == '-') {
//			if (i >= 1 && s[i - 1] != 'e'&&s[i - 1] != ' ')
//				return false;
//			sign = true;
//		}
//		else if (s[i] == '.') {
//			if (dot || exp)
//				return false;
//			dot = true;
//		}
//		else if (s[i] >= '0'&&s[i] <= '9') {
//			num = true;
//			numAfterE = true;
//		}
//		else if (s[i] == 'e' || s[i] == 'E') {
//			if (exp || !num)
//				return false;
//			exp = true;
//		}
//		else
//			return false;
//	}
//	return true;
//}
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	string ss = "2-4A0r7-4k";
//	auto ans = repeatedStringMatch(ss,4);
//
//
//	getchar();
//	return 0;
//}