//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//#include <unordered_set>
//#include <map>
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
////GGGG more parents and children
////double parents:
//struct TNode {
//	char data;
//	int parentIdx;
//};
//struct TreeDP {
//	vector<TNode> map;
//	int num;
//	TreeDP(int nums,vector<char> n) {
//		num = nums;
//	}
//};
////child linked list
//struct TNode {
//	char data;
//	ListNode* child;
//};
//struct Tree {
//	vector<TNode> map;
//	int nums;
//};
////child siblings
//struct TNode {
//	char data;
//	ListNode* firstChild;
//	ListNode* nextSibling;
//};
//struct Tree {
//	TNode* root;
//	int nums;
//};
//
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	auto ans = repeatedStringMatch(ss,4);
//
//	getchar();
//	return 0;
//}