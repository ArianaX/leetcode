//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//
//
//
////ListNode *mergeTwoLists(ListNode *l1, ListNode *l2) {
////	ListNode *head = new ListNode(-1);
////	ListNode *cur = head;
////	while (l1 && l2) {
////		if (l1->val < l2->val) {
////			cur->next = l1;
////			l1 = l1->next;
////		}
////		else {
////			cur->next = l2;
////			l2 = l2->next;
////		}
////		cur = cur->next;
////	}
////	if (l1) 
////		cur->next = l1;
////	if (l2) 
////		cur->next = l2;
////	return head->next;
////}
////ListNode *mergeKLists(vector<ListNode *> &lists) {
////	if (lists.size() == 0) 
////		return NULL;
////	int n = lists.size();
////	while (n > 1) {
////		int k = (n + 1) / 2;
////		for (int i = 0; i < n / 2; ++i) {
////			lists[i] = mergeTwoLists(lists[i], lists[i + k]);
////		}
////		n = k;
////	}
////	return lists[0];
////}
////
////
//////my
////
////ListNode* mergeKLists2(vector<ListNode*>& lists) {
////	int n = lists.size();
////	if (n == 0)
////		return nullptr;
////	while (n>1) {
////		int i;
////		for ( i = 0; i< n / 2; i++) {
////			lists[i] = mergeTwoLists(lists[2 * i], lists[2 * i + 1]);
////		}
////		if (n % 2 == 1) {
////			lists[i] = lists[2 * i];
////			n = n / 2 + 1;
////		}
////		else
////			n = n / 2;
////	}
////	return lists[0];
////}
////my 10/16/2018
////ListNode* merge(ListNode* l1, ListNode* l2) {// wrong answer ���Ҫ����һ��list ������Ҫ
////	ListNode* ans=new ListNode(-1);//***
////	auto it = ans->next;
////	while (l1 != nullptr&&l2 != nullptr) {
////		if (l1->val<l2->val) {
////			it = l1;
////			l1 = l1->next;
////		}
////		else {
////			it = l2;
////			l2 = l2->next;
////		}
////		it = it->next;
////	}
////	if (l1 != nullptr)
////		it = l1;
////	if (l2 != nullptr)
////		it = l2;
////	return ans->next;
////}
//ListNode* merge(ListNode* l1, ListNode* l2) {
//	ListNode* ans = new ListNode(-1);//***********************************************
//	auto it = ans;
//	while (l1 != nullptr && l2 != nullptr) {
//		if (l1->val<l2->val) {
//			it->next = l1;
//			l1 = l1->next;
//		}
//		else {
//			it->next = l2;
//			l2 = l2->next;
//		}
//		it = it->next;
//	}
//	if (l1 != nullptr)
//		it->next = l1;
//	if (l2 != nullptr)
//		it->next = l2;
//	return ans->next;
//}
//ListNode* mergeKLists(vector<ListNode*>& lists) {
//	int n = lists.size();
//	if (n == 0)//      ***********************************************
//		return nullptr;
//	while (n > 1)
//	{
//		int i;
//		for (i = 0; i<n / 2; i++)//important
//			lists[i] = merge(lists[2 * i], lists[2 * i + 1]);
//		if (n % 2 == 1)
//		{
//			lists[i] = lists[2 * i];
//			n = n / 2 + 1;
//		}
//		else
//			n = n / 2;
//	}
//	return lists[0];
//}
//int main()
//{
//	ListNode* l1 = new ListNode(12);
//	l1->next = new ListNode(24);
//	ListNode* l2 = new ListNode(2);
//	l2->next = new ListNode(4);
//	auto ans = merge(l1,l2);
//
//
//	getchar();
//	return 0;
//}