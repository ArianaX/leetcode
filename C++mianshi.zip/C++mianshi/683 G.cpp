//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//int kEmptySlots(vector<int>& flowers, int k) {
//	int res = INT_MAX, left = 0, right = k + 1, n = flowers.size();
//	vector<int> days(n, 0);
//	for (int i = 0; i < n; ++i) 
//		days[flowers[i] - 1] = i + 1;
//	for (int i = 0; right < n; ++i) {
//		if (days[i] < days[left] || days[i] <= days[right]) {
//			if (i == right) 
//				res = min(res, max(days[left], days[right]));
//			left = i;
//			right = k + 1 + i;
//		}
//	}
//	return (res == INT_MAX) ? -1 : res;
//}
////my
//int kEmptySlots2(vector<int>& flowers, int k) {
//	int n = flowers.size();
//	vector<int >  days(n, 0);
//	for (int i = 0; i<n; i++) {
//		days[flowers[i] - 1] = i + 1;
//	}
//
//	int left = 0, right = k + 1;
//	int ans = INT_MAX;
//	for (int i = left + 1; right < n; i++) {
//		if (days[i]<days[left] || days[i]<=days[right]) {
//			if (i == right)
//				ans = min(ans, max(days[left], days[right]));
//			left = i;
//			right = i + k + 1;
//		}
//	}
//	return (ans == INT_MAX) ? -1: ans;
//}
////my ���� ����k�����ʱ�� �����һ�� ��
//int kEmptySlots3(vector<int>& flowers, int k) {
//	int n = flowers.size();
//	vector<int >  days(n, 0);
//	for (int i = 0; i<n; i++) {
//		days[flowers[i] - 1] = i + 1;
//	}
//
//	int left = 0, right = k + 1;
//	int ans = 0;
//	for (int i = left + 1; right < n; i++) {
//		if (days[i]<days[left] || days[i] <= days[right]) {
//			if (i == right)
//				ans = max(ans, max(days[left], days[right]));
//			left = i;
//			right = i + k + 1;
//		}
//	}
//	return (ans == 0) ? -1 : ans;
//}
//
//
////�����澭oa K�������Ļ�
//int kEmptySlots4(vector<int>& flowers, int k) {
//	int n = flowers.size();
//	vector<int>  days(n, 0);
//	for (int i = 0; i<n; i++) {
//		days[flowers[i] - 1] = i + 1;
//	}
//
//	int left = 0, right = k + 1;
//	int ans = INT_MAX;
//	for (int i = left + 1; right < n; i++) {
//		if (days[i]>days[left] || days[i] >= days[right]) {
//			if (i == right)
//				ans = min(ans, max(days[left], days[right]));
//			left = i;
//			right = i + k + 1;
//		}
//	}
//	return (ans == INT_MAX) ? -1 : ans;
//}
//int main()
//{
//	vector<int> aa = {3,1,4,2,7,5,6 };
//	string ss = "2-4A0r7-4k";
//	auto ans = kEmptySlots4(aa,2);
//
//
//	getchar();
//	return 0;
//}