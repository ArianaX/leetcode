//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//int findKthLargest(vector<int>& nums, int k) {
//	priority_queue<int> ans(nums.begin(), nums.end());
//	for (int i = 0; i<k-1; i++)
//		ans.pop();
//	return ans.top();
//}
//
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	string ss = "2-4A0r7-4k";
//	auto ans = repeatedStringMatch(ss,4);
//
//	
//	getchar();
//	return 0;
//}