//#include<iostream>
//using namespace std;
//bool matchZZ(char* str, char* pattern)
//{
//	if (str == nullptr || pattern == nullptr) return false;
//
//	if (*str == '\0'&& *pattern == '\0') return true;
//	if (*str != '\0'&& *pattern == '\0') return false;
//	if (*str == *pattern||*pattern=='.')
//		return matchZZ(str+1, pattern+1);
//	if (*(pattern+1) == '*') {
//		if (*str != *pattern) return matchZZ(str, pattern + 2);
//		if (*str == *pattern || (*pattern == '.' &&*str != '\0'))
//			return matchZZ(str + 1, pattern) || matchZZ(str + 1, pattern + 2) || matchZZ(str, pattern + 2);
//	}
//	return false;
//}
//int main()
//{
//	char * aa = "293810";
//	int q = *aa - '0';
//}