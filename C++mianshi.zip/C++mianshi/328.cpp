//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//ListNode* createL(vector<int> a) {
//	ListNode* ans=new ListNode(-1);
//	auto cur = ans;
//	for (int i = 0; i < a.size(); i++) {
//		ListNode* t = new ListNode(a[i]);
//		cur->next = t;
//		cur = cur->next;
//	}
//	return ans->next;
//}
//
//ListNode* oddEvenList(ListNode* head) {
//	if (!head || !head->next) 
//		return head;
//	ListNode *odd = head, *even = head->next, *even_head = even;
//	while (even && even->next) {
//		odd = odd->next = even->next;
//		even = even->next = odd->next;
//	}
//	odd->next = even_head;
//	return head;
//}
//int main()
//{
//	vector<int> aa = { 2,1,3,5,6,4,7 };
//	auto ans = createL(aa);
//	//auto sss = oddEvenList(ans);
//
//	getchar();
//	return 0;
//}