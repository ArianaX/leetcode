//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//bool isValidSudoku(vector<vector<char> > &board) {
//	if (board.empty() || board[0].empty()) 
//		return false;
//	int m = board.size(), n = board[0].size();
//	vector<vector<bool> > rowFlag(m, vector<bool>(n, false));
//	vector<vector<bool> > colFlag(m, vector<bool>(n, false));
//	vector<vector<bool> > cellFlag(m, vector<bool>(n, false));
//	for (int i = 0; i < m; ++i) {
//		for (int j = 0; j < n; ++j) {
//			if (board[i][j] >= '1' && board[i][j] <= '9') {
//				int c = board[i][j] - '1';
//				if (rowFlag[i][c] || colFlag[c][j] || cellFlag[3 * (i / 3) + j / 3][c]) 
//					return false;
//				rowFlag[i][c] = true;
//				colFlag[c][j] = true;
//				cellFlag[3 * (i / 3) + j / 3][c] = true;
//			}
//		}
//	}
//	return true;
//}
////my
//bool isValidSudoku(vector<vector<char>>& board) {
//	if (board.size() == 0 || board[0].size() == 0)
//		return false;
//	int m = board.size();
//	int n = board[0].size();
//	vector<vector<bool>> rowF(m, vector<bool>(n, false));
//	vector<vector<bool>> colF(m, vector<bool>(n, false));
//	vector<vector<bool>> cellF(m, vector<bool>(n, false));
//	for (int i = m; i<board.size(); i++) {
//		for (int j = 0; j<board[0].size(); j++) {
//			if (board[i][j] >= '1'&&board[i][j] <= '9') {
//				int c = board[i][j] - '1';
//				if (rowF[i][c] || colF[c][j] || cellF[(j / 3) + ((i / 3) * 3)][c]) {
//					return false;
//				}
//				rowF[i][c] = true;
//				colF[c][j] = true;
//				cellF[(j / 3) + (i / 3) * 3][c] = true;
//			}
//
//		}
//	}
//	return true;
//
//}
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	auto ans = longestConsecutive(aa);
//
//
//	getchar();
//	return 0;
//}