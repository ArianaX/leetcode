//#include<iostream>
//#include<stack>
//using namespace std;
//struct ListNode
//{
//	int data;
//	ListNode* next;
//};
//void addtoTail(ListNode* list, int data)
//{
//	ListNode* newlist = new ListNode();
//	newlist->data = data;
//	newlist->next = NULL;
//
//	if (list==NULL)
//	{
//		list = newlist;
//	}
//	else
//	{
//		ListNode* temp = new ListNode();
//		temp = list;
//		while (temp->next!=NULL)
//		{
//			temp = temp->next;
//		}
//		temp->next = newlist;
//	}
//
//}
//void PrintListReverse(ListNode* list)
//{
//	stack<ListNode*> stackList;
//	ListNode* temp = list;
//	while (temp!=NULL)
//	{
//		stackList.push(temp);
//		temp = temp->next;
//	}
//	while (!stackList.empty())
//	{
//		cout << stackList.top()->data << " " << endl;
//		stackList.pop();
//	}
//}
//int main()
//{
//	ListNode* LX = new ListNode();
//	addtoTail(LX, 2);
//	addtoTail(LX, 3);
//	addtoTail(LX, 4);
//	addtoTail(LX, 5);
//	addtoTail(LX, 6);
//	addtoTail(LX, 7);
//	addtoTail(LX, 8);
//
//	PrintListReverse(LX);
//	system("pause");
//}