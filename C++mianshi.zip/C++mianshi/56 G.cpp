//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
////*
////* Definition for an interval.
//struct Interval {
//     int start;
//    int end;
//     Interval() : start(0), end(0) {}
//    Interval(int s, int e) : start(s), end(e) {}
//};
//
//vector<Interval> merge(vector<Interval>& intervals) {
//	if (intervals.empty()) 
//		return {};
//	sort(intervals.begin(), intervals.end(), [](Interval &a, Interval &b) {return a.start < b.start; });
//
//	vector<Interval> res{ intervals[0] };//���������� *******************
//	for (int i = 1; i < intervals.size(); ++i) {
//		if (res.back().end < intervals[i].start) {
//			res.push_back(intervals[i]);
//		}
//		else {
//			res.back().end = max(res.back().end, intervals[i].end);
//		}
//	}
//	return res;
//}
////my
//vector<Interval> merge(vector<Interval>& intervals) {
//	vector<Interval> ans;
//	sort(intervals.begin(), intervals.end(), [](Interval &a, Interval &b) {return a.start<b.start; });
//	ans.push_back(intervals[0]);// add it.
//	for (int i = 0; i<intervals.size(); i++) {
//		if (ans.back().end>=intervals[i].start) { // ******************wrong 
//			ans.back().end = max(ans.back().end, intervals[i].end);
//		}
//		else
//			ans.push_back(intervals[i]);
//
//	}
//	return ans;
//}
//
//
//int main()
//{
//	Interval
//	auto ans = solution(ss, 4);
//
//
//	getchar();
//	return 0;
//}