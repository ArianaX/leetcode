//257 ·��
////my
//void dfs(TreeNode* root, string s, vector<string>& ans) {
//	if (root->left == nullptr&& root->right == nullptr)
//		ans.push_back(s + to_string(root->val));
//	if (root->left != nullptr)
//		dfs(root->left, s + to_string(root->val) + "->", ans);
//	if (root->right != nullptr)
//		dfs(root->right, s + to_string(root->val) + "->", ans);
//}
//vector<string> binaryTreePaths(TreeNode* root) {
//	if (root == nullptr)
//		return {};
//	vector<string> ans;
//	string s = "";
//	dfs(root, s, ans);
//	return ans;
//}