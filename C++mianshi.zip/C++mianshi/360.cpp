//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//int cal(int x, int a, int b, int c) {
//	return a * x * x + b * x + c;
//}
//vector<int> sortTransformedArray(vector<int>& nums, int a, int b, int c) {
//	int n = nums.size(), i = 0, j = n - 1;
//	vector<int> res(n);
//	int idx = a >= 0 ? n - 1 : 0;
//	while (i <= j) {
//		if (a >= 0) {
//			res[idx--] = cal(nums[i], a, b, c) >= cal(nums[j], a, b, c) ? cal(nums[i++], a, b, c) : cal(nums[j--], a, b, c);
//		}
//		else {
//			res[idx++] = cal(nums[i], a, b, c) >= cal(nums[j], a, b, c) ? cal(nums[j--], a, b, c) : cal(nums[i++], a, b, c);
//		}
//	}
//	return res;
//}
//
//int cal(int x,int a,int b,int c){
//        return a*x*x + b*x + c;
//    }
//    vector<int> sortTransformedArray(vector<int>& nums, int a, int b, int c) {
//        int n=nums.size();
//        vector<int> ans(n);
//        int i=0,j=n-1,idx=a>=0?n-1:0;
//        while(i<=j){
//            if(a>=0)
//                ans[idx--]=cal(nums[i],a,b,c)>=cal(nums[j],a,b,c)? cal(nums[i++],a,b,c):cal(nums[j--],a,b,c);
//            else
//                ans[idx++]=cal(nums[i],a,b,c)<=cal(nums[j],a,b,c)? cal(nums[i++],a,b,c):cal(nums[j--],a,b,c);
//                
//        }
//        return ans;
//    }
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	string ss = "2-4A0r7-4k";
//	auto ans = repeatedStringMatch(ss,4);
//
//
//	getchar();
//	return 0;
//}