//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//
//vector<int> searchRange(vector<int>& nums, int target) {
//	int l = 0;
//	int r = nums.size() - 1;
//	vector<int> ans(2, -1);
//	while (l<=r) {
//		int mid = (l + r) >> 1;
//		if (nums[mid]>target)
//			r = mid - 1;
//		else if (nums[mid]<target)
//			l = mid + 1;
//		else {
//			ans[0] = mid;
//			ans[1] = mid;
//			for (int i = mid; i >= 0; i--)
//				if (nums[i] != target) {
//					ans[0] = ++i;
//					break;
//				}
//				else if (i == 0)
//					ans[0] = 0;
//			for (int i = mid; i < nums.size(); i++)
//				if (nums[i] != target) {
//					ans[1] = --i;
//					break;
//				}
//				else if (i == nums.size() - 1)
//					ans[1] = nums.size() - 1;
//			break;
//		}
//	}
//	return ans;
//
//}
//
//
//int main()
//{
//
//	vector<int> aa = {1,1,2};
//	auto ans = searchRange(aa,1);
//	aa = {};
//
//	//string aa = "asdeee";
//
//
//	getchar();
//	return 0;
//}