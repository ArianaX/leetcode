//#include<iostream>
//using namespace std;
//#define n 5
//int * Chongfushuzi(int* num)
//{
//	int result[n];
//	int j = 0;
//	for (int i = 0; i < n; i++)
//	{
//		if (num[i]<n-1)
//		{
//			while (num[i] != i)
//			{
//				if (num[i] == num[num[i]])
//				{
//					result[j] = num[i];
//					j++;
//					break;
//				}
//				int temp = num[i];
//				num[i] = num[num[i]];
//				num[temp] = temp;
//
//			}
//		}
//		else
//		{
//			cout << "��������"<<endl;
//			return result;
//		}
//		
//	}
//	return result;
//}
//bool Find(int * matrix,int rows,int colums,int number)//��ά�����Ѿ���С�����ź���ȷ���������Ƿ������������
//{
//	if (matrix==NULL||rows<0||colums<0)
//	{
//		cout << "wrong" << endl;
//		return false;
//	}
//	int r = 0;
//	int c = colums - 1;
//	while (r<rows&&c>=0)
//	{
//		if (matrix[r*c+c]==number)
//		{
//			return true;
//			break;
//		}
//		else if (matrix[r*c + c] < number)
//		{
//			c--;
//		}
//		else
//		{
//			r++;
//		}
//	}
//}
//int main()
//{
//	int num[5] = {4,24,1,1,2};
//	int *result=Chongfushuzi(num);
//	int k = 0;
//	while (result[k]!=NULL)
//	{
//		cout << result[k] << endl;
//		k++;
//	}
//	system("pause");
//}