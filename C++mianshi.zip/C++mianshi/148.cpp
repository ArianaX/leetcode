//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
////Definition for singly - linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//
//};
//
//
//
//ListNode* merge(ListNode* t1, ListNode* t2) {
//	auto ans = new ListNode(-1);
//	auto tt = ans;
//	while (t1 &&t2) {
//		if (t1->val< t2->val) {
//			tt->next = t1;
//			t1 = t1->next;
//		}
//		else {
//			tt->next = t2;
//			t2 = t2->next;
//		}
//		tt = tt->next;
//	}
//	if (t1)
//		tt->next = t1;
//	if (t2)
//		tt->next = t2;
//	return ans->next;
//}
//ListNode* sortList(ListNode* head) {
//	if (!head || !head->next)
//		return head;
//	auto slow = head;
//	auto fast = head;
//	ListNode* pre = slow;
//	while (fast&&fast->next) {
//		pre = slow;
//		slow = slow->next;
//		fast = fast->next->next;
//	}
//	pre->next = nullptr;
//	return merge(sortList(head), sortList(slow));
//}
//
//
//int main()
//{
//	vector<vector<char>> aa = { { '1','1','0','0','0' },
//	{ '1','1','0','0','0' },
//	{ '0','0','1','0','0' },
//	{ '0','0','0','1','1' } };
//	int ans = numIslands(aa);
//	aa = {};
//
//	//string aa = "asdeee";
//
//
//	getchar();
//	return 0;
//}