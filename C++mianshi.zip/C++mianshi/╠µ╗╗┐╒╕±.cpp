//#include<iostream>
//using namespace std;
//void ReplaceString(char s[], int length)//�滻��%20
//{
//	if (s==NULL)
//	{
//		return;
//	}
//	int string_length = 0;
//	int space_number = 0;
//	for (int i = 0; s[i]!=NULL; i++)
//	{
//		if (s[i]==' ')
//		{
//			space_number++;
//		}
//		string_length++;
//	}
//	int p2 = string_length + space_number * 2-1;
//	int p1 = string_length - 1;
//	if (length<p2+1)
//	{
//		return;
//	}
//	while (p2!=p1)
//	{
//		if (s[p1]!=' ')
//		{
//			s[p2] = s[p1];
//			p2--;
//			p1--;
//		}
//		else
//		{
//			s[p2] = '0';
//			p2--;
//			s[p2] = '2';
//			p2--;
//			s[p2] = '%';
//			p2--;
//			p1--;
//		}
//	}
//}
//int main()
//{
//	char myString[100] = "we are happy";
//	ReplaceString(myString, 100);
//	cout << myString << endl;
//	system("pause");
//}