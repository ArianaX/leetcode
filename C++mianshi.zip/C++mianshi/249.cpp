//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//#include <unordered_set>
//#include <map>
////* Definition for a binary tree node.
//struct TreeNode {
//	int val;
//	TreeNode *left;
//	TreeNode *right;
//	TreeNode(int x) : val(x), left(NULL), right(NULL) {}
//};
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
////["a","a"]
////[["a","a"]]
//vector<vector<string>> groupStrings(vector<string>& strings) {
//	vector<vector<string> > res;
//	unordered_map<string, multiset<string>> m;
//	for (auto a : strings) {
//		string t = "";
//		for (char c : a) {
//			t += to_string((c + 26 - a[0]) % 26) + ",";
//		}
//		m[t].insert(a);	
//	}
//	for (auto it = m.begin(); it != m.end(); ++it) {
//		res.push_back(vector<string>(it->second.begin(), it->second.end()));
//	}
//	return res;
//}
////my
//vector<vector<string>> groupStrings(vector<string>& strings) {
//	vector<vector<string>> ans;
//	unordered_map<string, multiset<string>>m;
//	for (auto a : strings) {
//		string t = "";
//		for (char cc : a) {
//			t = t + to_string((cc - a[0] + 26) % 26) + ",";
//		}
//		m[t].insert(a);
//	}
//
//	for (auto it = m.begin(); it != m.end(); it++) {
//		ans.push_back(vector<string>(it->second.begin(), it->second.end()));
//	}
//	return ans;
//}
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	auto ans = repeatedStringMatch(ss, 4);
//	//vector<vector<int>> ans(23, vector<int>());
//
//	getchar();
//	return 0;
//}