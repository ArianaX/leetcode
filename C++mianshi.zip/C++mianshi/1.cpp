//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//
//vector<int> twoSum(vector<int>& nums, int target) {
//	vector<int> ans;
//	unordered_map<int, int> m;
//	for (int i = 0; i < nums.size(); ++i) {
//		if (m.count(target - nums[i])) {
//			ans.push_back(i);
//			ans.push_back( m[target - nums[i]]);
//		}
//		m[nums[i]] = i;
//	}
//	return ans;
//}
//vector<int> twoSum2(vector<int>& nums, int target) {
//	unordered_map<int, int> m;
//	for (int i = 0; i<nums.size(); i++) {
//		if (m.count(target - nums[i]))
//			return { i,m[target - nums[i]] };
//		m[nums[i]] = i;
//	}
//	return{};
//}
//int main()
//{
//	vector<int> aa = { 2,7,-1,10,23};
//	auto ans = twoSum2(aa,9);
//
//
//	getchar();
//	return 0;
//}