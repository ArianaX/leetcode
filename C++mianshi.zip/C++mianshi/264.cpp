//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//
//int nthUglyNumber(int n) {
//	vector<int> res(1, 1);
//	int i2 = 0, i3 = 0, i5 = 0;
//	while (res.size() < n) {
//		int m2 = res[i2] * 2, m3 = res[i3] * 3, m5 = res[i5] * 5;
//		int mn = min(m2, min(m3, m5));
//		if (mn == m2) 
//			++i2;
//		if (mn == m3) 
//			++i3;
//		if (mn == m5) 
//			++i5;
//		res.push_back(mn);
//	}
//	return res.back();
//}
////my
//int nthUglyNumber(int n) {
//	int ans = 1;
//	vector<int> nums(1, 1);
//	int p2 = 0, p3 = 0, p5 = 0;
//	while (ans<n) {
//		int temp = min(nums[p2]*2, min(nums[p3]*3, nums[p5]*5));
//		ans++;
//		nums.push_back(temp);
//		if (temp == nums[p2])
//			p2++;
//		if (temp == nums[p3])
//			p3++;
//		if (temp == nums[p5])
//			p5++;
//	}
//	return nums.back();
//}
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	int ans = nthUglyNumber(12);
//
//
//	getchar();
//	return 0;
//}