//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//
//int trap(vector<int>& height) {
//	int idx = 0;
//	int left = 0;
//	int right = 0;
//	int area = 0;
//	for (int i = 0; i<height.size(); i++) {
//		idx = height[i] >= height[idx] ? i : idx;
//	}
//
//	for (int i = 0; i<idx; i++) {
//		if (height[i]<left)
//			area += left - height[i];
//		else
//			left = height[i];
//	}
//	for (int i = height.size() - 1; i>idx; i--) {
//		if (height[i]<right)
//			area += right - height[i];
//		else
//			right = height[i];
//	}
//	return area;
//}
////09302018
//int trap2(vector<int>& height) {
//	int idx = 0;
//	int hh = 0;
//	for (int i = 0; i<height.size(); i++) {
//		idx = (height[i] >= height[idx]) ? i : idx;
//	}
//	int left = 0;
//	int area = 0;
//	for (int i = 0; i<idx; i++) {
//		if (height[i]<left) {
//			area += left - height[i];
//		}
//		else
//			left = height[i];
//	}
//	int right = 0;
//	for (int i = height.size() - 1; i>idx; i--) {
//		if (height[i]<right)
//			area += right - height[i];
//		else
//			right = height[i];
//	}
//	return area;
//}
//int main()
//{
//	vector<int> aa = {4,2,3};
//	int ans = trap2(aa);
//
//
//	getchar();
//	return 0;
//}