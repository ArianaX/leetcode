//#include<iostream>
//using namespace std;
//void getSize(char var[]) {
//	cout << sizeof(var) << endl;
//}
//
//int main() {
//	char* str1 = "0123456789";
//	cout << sizeof(str1) << endl;
//
//	int str2[] = {1,2,3,4,5};
//	cout << sizeof(str2) << endl;
//
//	char str3[100] = "0123456789";
//	cout << sizeof(str3) << endl;
//
//	getSize(str3);
//
//
//	system("pause");
//}