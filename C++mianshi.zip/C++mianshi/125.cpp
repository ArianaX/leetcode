//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//bool isPalindrome(string s) {
//	int left = 0, right = s.size() - 1;
//	while (left < right) {
//		if (!isalnum(s[left])) 
//			++left;
//		else if (!isalnum(s[right])) 
//			--right;
//		else if ((s[left] + 32 - 'a') % 32 != (s[right] + 32 - 'a') % 32) 
//			return false;
//		else {
//			++left; --right;
//		}
//	}
//	return true;
//}
////my
//bool isPalindrome(string s) {
//	if (s.size() == 0)
//		return true;
//	int i = 0, j = s.size() - 1;
//	while (i<j) {
//		if (!isalnum(s[i]))
//			i++;
//		else if (!isalnum(s[j]))
//			j--;
//		else if ((s[i] + 32 - 'a') % 32 != (s[j] + 32 - 'a') % 32)
//			return false;
//		else {
//			i++; j--;
//		}
//	}
//	return true;
//
//}
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	string ss = "2-4A0r7-4k";
//	auto ans = repeatedStringMatch(ss,4);
//
//
//	getchar();
//	return 0;
//}