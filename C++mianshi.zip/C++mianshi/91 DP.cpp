//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//#include <unordered_set>
//
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
////int numDecodings(string s) {
////	if (s.empty() || (s.size() > 1 && s[0] == '0')) 
////		return 0;
////	vector<int> dp(s.size() + 1, 0);
////	dp[0] = 1;
////	for (int i = 1; i < dp.size(); ++i) {
////		dp[i] = (s[i - 1] == '0') ? 0 : dp[i - 1];
////		if (i > 1 && (s[i - 2] == '1' || (s[i - 2] == '2' && s[i - 1] <= '6'))) {
////			dp[i] += dp[i - 2];
////		}
////	}
////	return dp.back();
////}
////my
//int numDecodings(string s) {
//	if (s.empty() || s[0] == '0')
//		return 0;
//	vector<int>dp(s.size() + 1, 0);
//	dp[0] = 1;
//	for (int i = 1; i<dp.size(); i++) {
//		dp[i] = s[i - 1] == '0' ? 0 : dp[i - 1];
//		if (i>1 && (s[i - 2] == '1' || (s[i - 2] == '2'&&s[i - 1] <= '6')))
//			dp[i] += dp[i - 2];
//	}
//	return dp.back();
//}
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	auto ans = numDecodings("14207");
//
//	getchar();
//	return 0;
//}