//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
////this method only for one aero inside of queue
//int findMaxConsecutiveOnes(vector<int>& nums) {
//	int res = 0, cur = 0, cnt = 0;
//	for (int num : nums) {
//		++cnt;
//		if (num == 0) {
//			cur = cnt;
//			cnt = 0;
//		}
//		res = max(res, cnt + cur);
//	}
//	return res;
//}
//
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	string ss = "2-4A0r7-4k";
//	auto ans = repeatedStringMatch(ss,4);
//
//
//	getchar();
//	return 0;
//}