//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
////��һ�������
//string nextClosestTime(string time) {
//	string res = "0000";
//	vector<int> v{ 600, 60, 10, 1 };//**************
//	int found = time.find(":");
//	int cur = stoi(time.substr(0, found)) * 60 + stoi(time.substr(found + 1));
//
//	for (int i = 1, d = 0; i <= 1440; ++i) {
//		int next = (cur + i) % 1440;
//		for (d = 0; d < 4; ++d) {
//			res[d] = '0' + next / v[d];
//			next %= v[d];
//			if (time.find(res[d]) == string::npos) 
//				break;
//		}
//		if (d >= 4) 
//			break;
//	}
//	return res.substr(0, 2) + ":" + res.substr(2);
//}
//
////my �������Ҫ��digit�����ظ��� DFS
//int timeDiff(int t1, int t2) {
//	if (t1 == t2) 
//		return INT_MAX;
//	return ((t2 - t1) + 24 * 60) % (24 * 60);
//}
//void dfs(int dep, string & digits, string& curr, int time, string& best, vector<pair<char, bool>>& visit) {
//	if (dep == 4) {
//		if (stoi(curr.substr(0, 2)) > 23 || stoi(curr.substr(2)) > 59)
//			return;
//		int curr_time = stoi(curr.substr(0, 2)) *60+ stoi(curr.substr(2));
//		int bestInt= stoi(best.substr(0, 2)) * 60 + stoi(best.substr(2));
//		if (timeDiff(time, curr_time) < timeDiff(time, bestInt))
//			best = curr;
//
//		//for (int i = 0; i < 4; i++) {
//		//	if(visit[i].first == curr[3])
//		//		visit[i].second = false;
//		//}
//		return;
//	}
//	for (auto digit : digits) {
//		for (int i = 0; i < 4; i++) {
//			if (visit[i].first == digit && visit[i].second == false) {
//				curr[dep] = digit;
//				visit[i].second = true;
//				dfs(dep + 1, digits, curr, time, best, visit);
//				visit[i].second = false;
//			}
//		}		
//	}
//}
//string nextClosestTime2(string time) {
//	string d = time.substr(0, 2) + time.substr(3);
//	int now= stoi(time.substr(0, 2)) * 60 + stoi(time.substr(3));
//	string curr = "0000";
//	string bb = d;
//	vector<pair<char,bool>> visit(4);
//	for (int i = 0; i < 4; i++) {
//		char cc = d[i];
//		visit[i] = make_pair(cc,false);
//	}
//
//	dfs(0, d, curr, now, bb,visit);
//	return bb.substr(0, 2) + ":" +bb.substr(2);
//}
//
//
//////answer DFS:
////int toTime(int h, int m) {
////	return h * 60 + m;
////}
////
////int timeDiff(int t1, int t2) {
////	if (t1 == t2) return INT_MAX;
////	return ((t2 - t1) + 24 * 60) % (24 * 60);
////}
////void dfs(int dep, const vector<int>& digits, vector<int>& curr, int time, int& best) {
////	if (dep == 4) {
////		int curr_h = curr[0] * 10 + curr[1];
////		int curr_m = curr[2] * 10 + curr[3];
////		if (curr_h > 23 || curr_m > 59) return;
////		int curr_time = toTime(curr_h, curr_m);
////		if (timeDiff(time, curr_time) < timeDiff(time, best))
////			best = curr_time;
////		return;
////	}
////
////	for (int digit : digits) {
////		curr[dep] = digit;
////		dfs(dep + 1, digits, curr, time, best);
////	}
////}
////string nextClosestTime3(string time) {
////	vector<int> d = {
////		time[0] - '0', time[1] - '0', time[3] - '0', time[4] - '0' };
////
////	int h = d[0] * 10 + d[1];
////	int m = d[2] * 10 + d[3];
////	vector<int> curr(4, 0);
////	int now = toTime(h, m);
////	int best = now;
////
////	dfs(0, d, curr, now, best);
////	return to_string(best / 60) + ":" + to_string(best % 60);
////}
//
//
//int main()
//{
//
//	auto ans = nextClosestTime("12:31");
//
//
//	getchar();
//	return 0;
//}