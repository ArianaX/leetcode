//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
////my
//int read4(char *buf) {
//	return 23;
//}
//class Solution {
//public:
//	int read(char *buf, int n) {
//		int idx = 0;//�˴ε��ý�����±�
//		while (idx < n) {
//			if(pointer == 0)
//				count = read4(bb);
//			if (count == 0)
//				break;
//			while (idx < n && pointer < count) {
//				buf[idx++] = bb[pointer++];
//			}
//			if (pointer == count)
//				pointer = 0;
//		}
//		return idx;
//	}
//private:
//	int count = 0;
//	int pointer = 0;
//	char bb[4];
//};
//
//answer
//class Solution {
//public:
//	int read(char *buf, int n) {
//		for (int i = 0; i < n; ++i) {
//			if (readPos == idxR4) {
//				idxR4 = read4(buff);
//				readPos = 0;
//				if (idxR4 == 0)
//					return i;
//			}
//			buf[i] = buff[readPos++];
//		}
//		return n;
//	}
//private:
//	int readPos = 0, idxR4 = 0;
//	char buff[4];
//};
//
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	string ss = "2-4A0r7-4k";
//	auto ans = repeatedStringMatch(ss,4);
//
//
//	getchar();
//	return 0;
//}