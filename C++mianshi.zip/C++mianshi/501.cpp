//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//struct TreeNode {
//	int val;
//	TreeNode *left;
//	TreeNode *right;
//	TreeNode(int x) : val(x), left(NULL), right(NULL) {}
//};
//
//
//vector<int> findMode(TreeNode* root) {
//	vector<int> res;
//	int mx = 0;
//	unordered_map<int, int> m;
//	inorder(root, m, mx);
//	for (auto a : m) {
//		if (a.second == mx) {
//			res.push_back(a.first);
//		}
//	}
//	return res;
//}
//void inorder(TreeNode* node, unordered_map<int, int>& m, int& mx) {
//	if (!node) return;
//	inorder(node->left, m, mx);
//	mx = max(mx, ++m[node->val]);
//	inorder(node->right, m, mx);
//}
//
//int main()
//{
//	vector<string> words = { "aaa","cdcdc","aaa" };
//	/*int ans= numIslands(aa);
//	aa = {};*/
//
//	//string aa = "asdeee";
//	sort(words.begin(), words.end());
//	vector<string> res(0);
//	for (int i = 0; i<words.size(); i++) {
//		if (res.size() != 0 && res.back() == words[i])
//			continue;
//		else
//			res.push_back(words[i]);
//	}
//
//	getchar();
//	return 0;
//}