//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//vector<int> findDiagonalOrder(vector<vector<int>>& matrix) {
//	if (matrix.empty() || matrix[0].empty()) 
//		return {};
//	int m = matrix.size(), n = matrix[0].size(), r = 0, c = 0, k = 0;
//	vector<int> res(m * n);
//	vector<vector<int>> dirs{ { -1,1 },{ 1,-1 } };
//	for (int i = 0; i < m * n; ++i) {
//		res[i] = matrix[r][c];
//		r += dirs[k][0];
//		c += dirs[k][1];
//		if (r >= m) { 
//			r = m - 1; 
//			c += 2; 
//			k = 1 - k; }
//		if (c >= n) { 
//			c = n - 1; 
//			r += 2; 
//			k = 1 - k; }
//		if (r < 0) { 
//			r = 0; 
//			k = 1 - k; }
//		if (c < 0) { 
//			c = 0; 
//			k = 1 - k; }
//	}
//	return res;
//}
////my
//vector<int> findDiagonalOrder2(vector<vector<int>>& matrix) {
//	if (matrix.empty() || matrix[0].empty())
//		return {};
//	int m = matrix.size(), n = matrix[0].size();
//	int x = 0, y = 0, k = 0;
//	vector<vector<int>>dirs = { { -1,1 },{ 1,-1 } };
//	vector<int>ans(m*n);
//	for (int i = 0; i<m*n; i++) {
//		ans[i] = matrix[x][y];
//		x += dirs[k][0];
//		y += dirs[k][1];
//		if (x == m) {
//			y = y + 2;
//			x = x - 1;
//			k = 1 - k;
//		}
//		if (y == n) {
//			x = x + 2;
//			y = y - 1;
//			k = 1 - k;
//		}
//		if (x<0) {
//			x = 0;
//			k = 1 - k;
//		}
//		if (y<0) {
//			y = 0;
//			k = 1 - k;
//		}
//
//	}
//	return ans;
//}
//int main()
//{
//	vector<vector<int>> ss = { {1, 2, 3,0},
//								{4, 5, 6,0},
//								{7, 8, 9,0} };
//
//	auto ans = findDiagonalOrder2(ss);
//
//
//	getchar();
//	return 0;
//}