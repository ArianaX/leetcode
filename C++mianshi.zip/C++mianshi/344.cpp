//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//string reverseString(string s) {
//	string ans(s);
//	for (int i = 0; i<s.size(); i++) {
//		int j = s.size() - 1 - i;
//		ans[i]= s[j];
//	}
//	return ans;
//}
//string reverseString2(string s) {
//	int left = 0, right = s.size() - 1;
//	while (left < right) {
//		char t = s[left];
//		s[left] = s[right];
//		s[right] = t;
//		left++;
//		right--;
//	}
//	return s;
//}
//int main()
//{
//	string aa = "hello world!!";
//	auto ans = reverseString(aa);
//
//
//	getchar();
//	return 0;
//}