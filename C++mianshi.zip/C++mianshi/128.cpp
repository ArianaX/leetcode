//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<map>
////Definition for singly-linked list.
//struct ListNode {
//	int val;
//	ListNode *next;
//	ListNode(int x) : val(x), next(NULL) {}
//};
//
//
//int longestConsecutive(vector<int>& nums) {
//	map<int, int> m;
//	int ans = 0;
//	for (auto num : nums) {
//		if (!m.count(num)) {
//			int left = m.count(num - 1) ? m[num - 1] : 0;
//			int right = m.count(num + 1) ? m[num + 1] : 0;
//			int sum = left + right + 1;
//			ans = max(ans, sum);
//			m[num] = sum;
//			m[num - left] = sum;
//			m[num + right] = sum;
//		}
//	}
//	return ans;
//
//}
//
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 ,5};
//	int ans= longestConsecutive(aa);
//	
//
//	getchar();
//	return 0;
//}