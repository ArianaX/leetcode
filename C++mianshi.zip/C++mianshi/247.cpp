//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//
//
//vector<string> find(int m, int n) {// the result is symmetrical nummber --> add between the target number a _ a
//	if (m == 0) //���input is even number
//		return { "" };
//	if (m == 1) //if the odd number sigle symmetrical number
//		return { "0", "1", "8" };
//	vector<string> t = find(m - 2, n), res;//empty is available too.
//	for (auto a : t) {
//		if (m != n) 
//			res.push_back("0" + a + "0");
//		res.push_back("1" + a + "1");
//		res.push_back("6" + a + "9");
//		res.push_back("8" + a + "8");
//		res.push_back("9" + a + "6");
//	}
//	return res;
//}
//vector<string> findStrobogrammatic(int n) {
//	return find(n, n);
//}
////my
//vector<string> find(int inner, int n) {
//	if (inner == 0)
//		return { "" };
//	if (inner == 1)
//		return { "1","8","0" };
//	vector<string> ans;
//	vector<string> last = find(inner - 2, n);
//	for (auto a : last) {
//		if (inner != n)
//			ans.push_back("0" + a + "0");
//		ans.push_back("6" + a + "9");
//		ans.push_back("1" + a + "1");
//		ans.push_back("9" + a + "6");
//		ans.push_back("8" + a + "8");
//	}
//	return ans;
//}
//vector<string> findStrobogrammatic(int n) {
//	return find(n, n);
//}
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	string ss = "2-4A0r7-4k";
//	auto ans = findStrobogrammatic(4);
//
//
//	getchar();
//	return 0;
//}