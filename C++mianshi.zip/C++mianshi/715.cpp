//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//#include <map>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//class RangeModule {
//public:
//	RangeModule() {}
//
//	void addRange(int left, int right) {
//		auto x = find(left, right);
//		m[x.first] = x.second;
//	}
//
//	bool queryRange(int left, int right) {
//		auto it = m.upper_bound(left);
//		return it != m.begin() && (--it)->second >= right;
//	}
//
//	void removeRange(int left, int right) {
//		auto x = find(left, right);
//		if (left > x.first) 
//			m[x.first] = left;
//		if (x.second > right) 
//			m[right] = x.second;
//	}
//
//private:
//	map<int, int> m;
//
//	pair<int, int> find(int left, int right) {
//		auto l = m.upper_bound(left), r = m.upper_bound(right);
//		if (l != m.begin() &&(--l)->second < left) 
//			++l;
//		if (l == r) 
//			return { left, right };
//		int i = min(left, l->first), j = max(right, (--r)->second);
//		m.erase(l, ++r);
//		return { i, j };
//	}
//};
////my
//class RangeModule2 {
//public:
//	RangeModule2() {
//
//	}
//
//	void addRange(int left, int right) {
//		auto x = find(left, right);
//		m[x.first] = x.second;
//	}
//
//	bool queryRange(int left, int right) {
//		auto it = m.upper_bound(left);
//		return it != m.begin() && ((--it)->second >= right);
//	}
//
//	void removeRange(int left, int right) {
//		auto x = find(left, right);
//		if (x.first<left)
//			m[x.first] = left;
//		if (x.second>right)
//			m[right] = x.second;
//	}
//private:
//	map<int, int> m;
//	pair<int, int> find(int left, int right) {
//		auto l = m.upper_bound(left), r = m.upper_bound(right);
//		if (l != m.begin() && (--l)->second<left)
//			l++;
//		if (l == r)
//			return{ left,right };
//		//two
//		int i = min(left, l->first), j = max(right, (--r)->second);
//		m.erase(l, ++r);
//		return { i,j };
//	}
//};
//
//int main()
//{
//	std::map<char, int> mymap;
//	std::map<char, int>::iterator itlow, itup;
//
//	mymap['a'] = 20;
//	//mymap['b'] = 40;
//	mymap['c'] = 60;
//	//mymap['d'] = 80;
//	//mymap['e'] = 100;
//
//	itlow = mymap.lower_bound('b');  // itlow points to b
//	itup = mymap.upper_bound('d');   // itup points to e (not d!)
//
//
//	RangeModule2 ans1;
//	ans1.addRange(10, 20);
//	//ans1.addRange(30, 33);
//	//ans1.addRange(15, 25);
//	ans1.removeRange(14, 16);
//	//ans1.removeRange(11, 32);
//
//	auto a = ans1.queryRange(10, 14);// : true (Every number in[10, 14) is being tracked)
//	a = ans1.queryRange(13, 15);// : false (Numbers like 14, 14.03, 14.17 in[13, 15) are not being tracked)
//	a = ans1.queryRange(16, 17);// : true (The number 16 in[16, 17) is still being tracked, despite the remove operation)
//
//	getchar();
//	return 0;
//}
//
