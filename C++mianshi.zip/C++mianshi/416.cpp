//
//
//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//bool canPartition(vector<int>& nums) {
//	int sum = 0;
//	for (int i = 0; i<nums.size(); i++)
//		sum += nums[i];
//	if (sum & 1)
//		return false;
//	int target = sum >> 1;
//
//	vector<bool> ans(target + 1, false);
//	ans[0] = true;
//	for (auto num : nums)
//		for (int j = target; j >= num; j--) {
//			ans[j] = ans[j] || ans[j - num];
//			if (ans[target] == true)
//				return true;
//		}
//	return false;
//}
//
//
//
//int main()
//{
//
//
//	vector<int> aa = { 1, 9, 3, 3 };
//	bool ans = canPartition(aa);
//
//
//
//	getchar();
//	return 0;
//}