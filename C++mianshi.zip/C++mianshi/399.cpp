//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//#include <unordered_set>
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//////difficult one:
////vector<double> calcEquation(vector<pair<string, string>> equations, vector<double>& values, vector<pair<string, string>> queries) {
////	vector<double> res;
////	unordered_map<string, unordered_map<string, double>> g;
////	for (int i = 0; i < equations.size(); ++i) {
////		g[equations[i].first].emplace(equations[i].second, values[i]);
////		g[equations[i].first].emplace(equations[i].first, 1.0);
////		g[equations[i].second].emplace(equations[i].first, 1.0 / values[i]);
////		g[equations[i].second].emplace(equations[i].second, 1.0);
////
////	}
////	for (auto query : queries) {
////		if (!g.count(query.first) || !g.count(query.second)) 
////			res.push_back(-1.0);
////		else {
////			queue<pair<string, double>> q;
////			unordered_set<string> used{ query.first };
////			bool find = false;
////			q.push({ query.first, 1.0 });
////			while (!q.empty() && !find) {
////				queue<pair<string, double>> next;
////				while (!q.empty() && !find) {
////					pair<string, double> t = q.front(); 
////					q.pop();
////					if (t.first == query.second) {
////						find = true;
////						res.push_back(t.second);
////						break;
////					}
////					for (auto a : g[t.first]) {
////						if (!used.count(a.first)) {
////							a.second *= t.second;
////							next.push(a);
////							used.insert(a.first);
////						}
////					}
////				}
////				q = next;
////			}
////			if (!find) res.push_back(-1.0);
////		}
////	}
////	return res;
////}
//
//
//////huahua  graph+dfs
////// get result of A / B
////double divide(const string& A, const string& B,
////	unordered_map<string, unordered_map<string, double>>& g,
////	unordered_set<string>& visited) {
////	if (A == B) 
////		return 1.0;
////	visited.insert(A);
////	for (const auto& pair : g[A]) {
////		const string& C = pair.first;
////		if (visited.count(C)) 
////			continue;
////		double d = divide(C, B, g, visited); // d = C / B
////											 // A / B = C / B * A / C
////		if (d > 0) 
////			return d * g[A][C];
////	}
////	return -1.0;
////}
////vector<double> calcEquation(vector<pair<string, string>> equations, vector<double>& values, vector<pair<string, string>> queries) {
////	// g[A][B] = k -> A / B = k
////	unordered_map<string, unordered_map<string, double>> g;
////	for (int i = 0; i < equations.size(); ++i) {
////		const string& A = equations[i].first;
////		const string& B = equations[i].second;
////		const double k = values[i];
////		g[A][B] = k;
////		g[B][A] = 1.0 / k;
////	}
////
////	vector<double> ans;
////	for (const auto& pair : queries) {
////		const string& X = pair.first;
////		const string& Y = pair.second;
////		if (!g.count(X) || !g.count(Y)) {
////			ans.push_back(-1.0);
////			continue;
////		}
////		unordered_set<string> visited;
////		ans.push_back(divide(X, Y, g, visited));
////	}
////	return ans;
////}
////my
//double helper(string a, string b, unordered_map<string, unordered_map<string, double>>& g, unordered_set<string>& visit) {
//	if (a == b)
//		return 1.0;
//	visit.insert(a);
//	for (auto gg : g[a]) {
//		if (!visit.count(gg.first)) {
//			double ans = helper(gg.first, b, g, visit);
//			if (ans >= 0)
//				return ans * g[a][gg.first];
//		}
//	}
//	return -1.0;//must write this;
//}
//vector<double> calcEquation(vector<pair<string, string>> equations, vector<double>& values, vector<pair<string, string>> queries) {
//	unordered_map<string, unordered_map<string, double>> g;
//	for (int i = 0; i<equations.size(); i++) {
//		g[equations[i].first].emplace(equations[i].second, values[i]);
//		g[equations[i].second].emplace(equations[i].first, 1.0 / values[i]);
//	}
//	vector<double> ans;
//
//	for (auto que : queries) {
//		if (!g.count(que.first) || !g.count(que.second))
//			ans.push_back(-1.0);
//		else {
//			unordered_set<string> visit;
//			ans.push_back(helper(que.first, que.second, g, visit));
//		}
//	}
//	return ans;
//}
//int main()
//{
//	vector<pair<string, string>> equations = { {"a", "b"},{"b", "c"} };
//	vector<double> values = { 2.0, 3.0 };
//	vector<pair<string,string>>	queries = { { "a", "c" },{ "b", "a" },{ "a", "e" },{ "a", "a" },{ "x", "x" } };
//	auto ans = calcEquation(equations,values,queries);
//
//
//	getchar();
//	return 0;
//}