//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//#include <unordered_set>
//#include <map>
////* Definition for a binary tree node.
//struct TreeNode {
//	int val;
//	TreeNode *left;
//	TreeNode *right;
//	TreeNode(int x) : val(x), left(NULL), right(NULL) {}
//};
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//
//class NumMatrix {
//private:
//	vector<vector<int>> m;
//public:
//	NumMatrix(vector<vector<int>> matrix) {
//		m = matrix;
//	}
//
//	void update(int row, int col, int val) {
//		if (m.empty() || m[0].empty() || row >= m.size() || col >= m[0].size())
//			return;
//		m[row][col] = val;
//	}
//
//	int sumRegion(int row1, int col1, int row2, int col2) {
//		if (m.empty() || m[0].empty() || row1 >= m.size() || col1 >= m[0].size() || row2 >= m.size() || col2 >= m[0].size())
//			return 0;
//		int sum = 0;
//		for (int i = row1; i <= row2; i++) {
//			for (int j = col1; j <= col2; j++) {
//				sum += m[i][j];
//			}
//		}
//		return sum;
//	}
//};
//
///**
//* Your NumMatrix object will be instantiated and called as such:
//* NumMatrix obj = new NumMatrix(matrix);
//* obj.update(row,col,val);
//* int param_2 = obj.sumRegion(row1,col1,row2,col2);
//*/
//
//int main()
//{
//	vector<int> aa = { 100,4,200,1,3,2 };
//	auto ans = repeatedStringMatch(ss,4);
//
//	getchar();
//	return 0;
//}