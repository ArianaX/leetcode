//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//#include <unordered_set>
//class Robot {
//	public:
//	     // Returns true if the cell in front is open and robot moves into the cell.
//	     // Returns false if the cell in front is blocked and robot stays in the current cell.
//	     bool move();
//	
//	     // Robot will stay in the same cell after calling turnLeft/turnRight.
//	     // Each turn will be 90 degrees.
//	     void turnLeft();
//	void turnRight();
//	
//	     // Clean the current cell.
//	     void clean();
//	
//};
////correct:
//class Solution {
//private:
//	unordered_set<string> cleaned;
//	vector<pair<int, int>> neighbors{ { 0, 1 },{ 1, 0 },{ 0, -1 },{ -1, 0 } };
//
//public:
//	void cleanRoom(Robot& robot) {
//		clean(0, 0, robot, 0);
//	}
//
//	void come_back(Robot &r) {
//		r.turnLeft();
//		r.turnLeft();
//		r.move();
//	}
//
//	void clean(int i, int j, Robot &robot, int d) {
//		string room = to_string(i) + " " + to_string(j);
//		if (cleaned.count(room))
//			return;
//		robot.clean();
//		cleaned.insert(room);
//		for (int k = 0; k < 4; k++, d++) {//must have d
//			pair<int, int> p = neighbors[d % 4];
//			if (robot.move()) {
//				clean(i + p.first, j + p.second, robot, d % 4);
//				come_back(robot);
//				robot.turnRight();
//			}
//			else {
//				robot.turnLeft();
//			}
//		}
//	}
//};
////my wrong 1. pair of cleaned. 2, it need to clean all room
