//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
//#include <set>
//#include <unordered_set>
//
//
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//int wordsTyping(vector<string>& sentence, int rows, int cols) {
//	string all = "";
//	for (string word : sentence) 
//		all += (word + " ");
//	int start = 0, len = all.size();
//	for (int i = 0; i < rows; ++i) {
//		start += cols;
//		if (all[start % len] == ' ') {
//			++start;
//		}
//		else {
//			while (start > 0 && all[(start - 1) % len] != ' ') {
//				--start;
//			}
//		}
//	}
//	return start / len;
//}
////my
//int wordsTyping(vector<string>& sentence, int rows, int cols) {
//	string all = "";
//	for (auto a : sentence) {
//		all += a + ' ';
//	}
//	int len = all.size();
//	int start = 0;
//	for (int i = 0; i<rows; i++) {
//		start += cols;
//		if (all[start%len] == ' ')
//			start++;
//		else {
//			while (start>0 && (all[(start - 1) % len] != ' '))
//				start--;
//		}
//	}
//	return start / len;
//}
//int main()
//{
//	vector<string> aa = { "I", "had", "apple", "pie" };
//	auto ans = wordsTyping(aa,4,5);
//
//	getchar();
//	return 0;
//}