//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//
//int maxProfit(vector<int>& prices) {
//	if (prices.size() == 0) return 0;
//	int len = prices.size();
//	vector<int> buy(len + 1, 0), sell(len + 1, 0);
//	buy[1] = -prices[0];
//	for (int i = 2; i <= len; i++)
//	{
//		buy[i] = max(sell[i - 2] - prices[i - 1], buy[i - 1]);
//		sell[i] = max(sell[i - 1], buy[i - 1] + prices[i - 1]);
//	}
//	return sell[len];
//}
////64
//int minPathSum(vector<vector<int>>& grid) {
//	int m = grid.size();
//	int n = grid[0].size();
//	vector<vector<int>> dp;
//	for (int i = 0; i < m; i++) {
//			vector<int> temp(n);
//			dp.push_back(temp);
//		
//	}
//
//	dp[0][0] = grid[0][0];
//	for (int i = 1; i<m; i++) {
//		dp[i][0] = dp[i - 1][0] + grid[i][0];
//	}
//	for (int i = 1; i<n; i++) {
//		dp[0][i] = dp[0][i - 1] + grid[0][i];
//	}
//	for (int i = 1; i < m; i++) {
//		for (int j = 1; j<n; j++) {
//			dp[i][j] = min((grid[i][j] + dp[i - 1][j]), (grid[i][j] + dp[i][j - 1]));
//		}
//	}
//	return dp[m - 1][n - 1];
//}
//int main()
//{
//	vector<int> nums = {1,2,3,0,2};
//	int qq = maxProfit(nums);
//
//	vector<vector<int>> ans = { {1,3,1},{1,5,1} ,{4,2,1} };
//	minPathSum(ans);
//	getchar();
//	return 0;
//}