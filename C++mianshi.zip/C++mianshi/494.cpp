//#include<iostream>
//using namespace std;
//#include<vector>
////��һ�ַ��� �ݹ� ���Ǵ𰸲��� ��֪�����������
////extern int count1;
////int count1 = 0;
////void DFS(vector<int>& nums, int s, int sum, int start) {
////	if (sum == s && start == nums.size()) {
////		count1++;
////		return;
////	}
////	if (start >= nums.size())
////		return;
////	for (int i = start; i<nums.size(); i++) {
////		sum = sum + nums[i];
////		DFS(nums, s, sum, i + 1);
////		sum = sum - nums[i];
////
////		sum = sum - nums[i];
////		DFS(nums, s, sum, i + 1);
////		sum = sum + nums[i];
////	}
////}
////int findTargetSumWays(vector<int>& nums, int S) {
////	DFS(nums, S, 0, 0);
////	return count1;
////}
////
////int main()
////{
////	vector<int> nums = { 1,1,1,1,1};
////	int q=findTargetSumWays(nums, 3);
////
////	getchar();
////	return 0;
////}
//
//
//
////�ڶ��ַ���
//int help(vector<int>& nums, int S, int first) {
//	/*if (first == nums.size()) {
//		return 0;
//	}
//	if (first == nums.size() - 1) {
//		if (S == 0 && nums[first] == 0) {
//			return 2;
//		}
//		if (S == nums[first] || (-1) * S == nums[first]) {
//			return 1;
//		}
//		return 0;
//	}*/
//
//	if (first == nums.size() && S == 0)
//		return 1;
//	if (first >= nums.size())
//		return 0;
//	return help(nums, S - nums[first], first + 1) + help(nums, S + nums[first], first + 1);
//}
//int findTargetSumWays(vector<int>& nums, int S) {
//	return help(nums, S, 0);
//}
//
//
//int main()
//{
//	vector<int> nums = { 1,1,1,1,1};
//	int q= findTargetSumWays(nums, 3);
//
//	getchar();
//	return 0;
//}