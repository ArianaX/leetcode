//#include<iostream>
//using namespace std;
//#include<vector>
//#include<algorithm>
//#include<unordered_map>
//#include<queue>
//#include<stack>
//#include<string>
////Definition for singly-linked list.
//struct ListNode {
//     int val;
//     ListNode *next;
//     ListNode(int x) : val(x), next(NULL) {}
// };
//
//vector<vector<int>> imageSmoother(vector<vector<int>>& M) {
//	if (M.empty() || M[0].empty()) 
//		return {};
//	int m = M.size(), n = M[0].size();
//	vector<vector<int>> res = M, dirs{ { 0,-1 },{ -1,-1 },{ -1,0 },{ -1,1 },{ 0,1 },{ 1,1 },{ 1,0 },{ 1,-1 } };
//	for (int i = 0; i < m; ++i) {
//		for (int j = 0; j < n; ++j) {
//			int cnt = M[i][j], all = 1;
//			for (auto dir : dirs) {
//				int x = i + dir[0], y = j + dir[1];
//				if (x < 0 || x >= m || y < 0 || y >= n) continue;
//				++all;
//				cnt += M[x][y];
//			}
//			res[i][j] = cnt / all;
//		}
//	}
//	return res;
//}
////my
//vector<vector<int>> imageSmoother(vector<vector<int>>& M) {
//	if (M.empty()||M[0].empty())
//		return {};
//	int m = M.size();
//	int n = M[0].size();
//	vector<vector<int>> ans = M;
//	vector<vector<int>> dd = { { 0,-1 },{ -1,-1 },{ -1,0 },{ -1,1 },{ 0,1 },{ 1,1 },{ 1,0 },{ 1,-1 } };
//
//	for (int i = 0; i<m; i++) {
//		for (int j = 0; j<n; j++) {
//			int all = 1;
//			int count = M[i][j];
//			for (auto d : dd) {
//				int x = i + d[0], y = j + d[1];
//				if (x<0 || x>m || y<0 || y>n)
//					continue;
//				all++;
//				count += M[x][y];
//			}
//			ans[i][j] = count / all;
//		}
//	}
//	return ans;
//}
//
//int main()
//{
//	vector<vector<int>> aa = { {1,1,1},
//								{1,0,1},
//								{1,1,1}
//};
//	auto ans = imageSmoother(aa);
//
//
//	getchar();
//	return 0;
//}